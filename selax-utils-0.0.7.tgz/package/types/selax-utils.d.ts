import * as _selax_utils from '@selax/utils';
import { Observable } from 'rxjs';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import * as i0 from '@angular/core';
import { InjectionToken, Provider } from '@angular/core';

declare abstract class SUDBBase<T extends {
    id: number;
}> {
    protected abstract tableName: string;
    protected readonly dbParams: _selax_utils.ISelaxUtilsParamsType;
    protected readonly dbVersion: number;
    protected readonly dbName: string;
    protected readonly dbTables: string[];
    removeByFilter(filter: (item: T) => boolean): Observable<void>;
    getListByFilter(filter: (item: T) => boolean): Observable<T[]>;
    getByFilter(filter: (item: T) => boolean): Observable<T | null>;
    batchUpdate(ids: number[], data: Partial<T>): Observable<void>;
    update(id: number, data: Partial<T>): Observable<T>;
    get(id: number): Observable<T>;
    batchRemove(ids: number[]): Observable<void>;
    remove(id: number): Observable<void>;
    insert(data: Partial<T>): Observable<T>;
    getList(): Observable<T[]>;
    protected openDB(): Observable<IDBDatabase>;
    updateData(data: T): Observable<void>;
    private insertDB;
}

/**
 * Благодарность https://github.com/mapbox/pixelmatch
 */
declare class SUPixelmatch {
    private data1;
    private data2;
    private width;
    private height;
    constructor(data1: ImageData, data2: ImageData, width: number, height: number);
    compare(): number;
    private antialiased;
    private hasManySiblings;
    private colorDelta;
    private rgb2y;
    private rgb2i;
    private rgb2q;
    private blend;
}

interface ISUCoords {
    x: number;
    y: number;
}
interface ISUWidthHeight {
    width: number;
    height: number;
}
interface ISURect extends ISUCoords, ISUWidthHeight {
}

/**
 * Packing Lightmaps
 * desc https://gamedev.ru/pages/coriolis/articles/Packing_Lightmaps
 * see https://github.com/jakesgordon/bin-packing
 */

declare const TEXTURE_PACKER_WIDTH = 6000;
declare const TEXTURE_PACKER_HEIGHT = 6000;
interface ISUPackerNode {
    w: number;
    h: number;
    x?: number;
    y?: number;
    id?: number;
    right?: ISUPackerNode;
    down?: ISUPackerNode;
    fit?: ISUPackerNode;
    used?: boolean;
}
declare class SUTexturePacker {
    private readonly width;
    private readonly height;
    root: ISUPackerNode;
    private blocks;
    constructor(width: number, height: number);
    fit(blocks: ISUPackerNode[]): void;
    getDimesion(): ISUWidthHeight;
    private findNode;
    private splitNode;
}

interface ISUCalcScaleImage {
    width: number;
    height: number;
    left: number;
    top: number;
    scaleTotargetWidth: boolean;
}
declare class SUCanvasHelper {
    static cropFileToFile(fileName: string, file: File, rect: ISURect): Promise<File | null>;
    static canvasFlipHorizontal(source: HTMLCanvasElement): HTMLCanvasElement;
    static canvasFlipVertical(source: HTMLCanvasElement): HTMLCanvasElement;
    static cropCanvasToFile(fileName: string, canvasSource: HTMLCanvasElement, rect: ISURect): Promise<File | null>;
    static canvasToBlob(canvas: HTMLCanvasElement): Promise<Blob>;
    static objectURLToCanvas(objectURL: string): Promise<HTMLCanvasElement>;
    static fileToCanvas(file: File, width?: number, height?: number): Promise<HTMLCanvasElement>;
    static strechCanvas(sourceCanvas: HTMLCanvasElement, width: number, height: number): Promise<HTMLCanvasElement>;
    static scaleCanvas(sourceCanvas: HTMLCanvasElement, width?: number, height?: number): Promise<HTMLCanvasElement>;
    static calcScaleImage(srcWidth: number, srcHeight: number, targetWidth: number, targetHeight: number, mode?: 'fitted' | 'zoom'): ISUCalcScaleImage;
    static drawFileOnCanvas(canvas: HTMLCanvasElement, x: number, y: number, width: number, height: number, file: File): Promise<void>;
    static arrayBufferToCanvas(buffer: ArrayBuffer): Promise<HTMLCanvasElement>;
}

declare class SUColorHelper {
    static rgb2hex(value: string): string;
    static hex2hexadecimal(val: string): number;
    static hex2rgba(val: string): string;
}

declare const DATE_SEPARATOR = ".";
declare class SUDateHelper {
    static correctMinMaxDate(date: Date, minDate: Date | null, maxDate: Date | null): boolean;
    static addDays(days: number, date?: Date): Date;
    static correctDate(value: string | Date | null): boolean;
    static valueToDate(value: string | Date | null): Date | null;
    static dateToString(date: Date): string;
    static normalizeStringToDate(value: string | null): Date | null;
}

interface ISUDimensions {
    width: number;
    height: number;
}
interface ISUJsonFile {
    filename: string;
    json: unknown;
}
declare class SUFileHelper {
    static downloadJson(json: object, filename: string): void;
    static downloadFile(filename: string, base64Bytes: string): void;
    static downloadBlob(filename: string, fileBlob: Blob): void;
    static downloadByLink(filename: string, linkUrl: string): void;
    static openFile(base64Bytes: string, mimeType?: string): void;
    static uploadFile<T extends File | FileList>(accept?: string, multiple?: boolean): Observable<T>;
    static uploadJson(): Observable<unknown>;
    static uploadJsonWithFilename(): Observable<ISUJsonFile>;
    static getImageFileExtension(file: File): string;
    static scaleFile(file: File, width?: number, height?: number): Promise<File>;
    static cropFileToFile(fileName: string, file: File, rect: ISURect): Promise<File | null>;
    static fileToImageData(file: File): Promise<ImageData>;
    static compareFiles(file1: File, file2: File): Promise<boolean>;
    static blobToFile(blob: Blob, filename: string): File;
    static getFileDimensions(file: File): Promise<ISUDimensions>;
    static flipFile(file: File, flipHorizontal: boolean, flipVertical: boolean): Promise<File>;
    static generateFrameFile(file: File, width: number, height: number, frameX: number, frameY: number, layerX: number, layerY: number, flipHorizontal: boolean, flipVertical: boolean): Promise<File | null>;
}

declare class SUJsonHelper {
    static clone(obj: any): any;
    static compareObjects(obj1: any, obj2: any): boolean;
}

declare class SUNumberHelper {
    static strToNumber(value: string | null, valueOnError?: number | null): number | null;
    static isNumber(n: unknown): boolean;
    static getRandomInt(min: number, max: number): number;
}

declare class SUStringHelper {
    static uuidv4(): string;
    static string2number(value: string | null): number | null;
    static base64ToUint8(base64str: string): Uint8Array;
    static replaceHyphen(hyphen: string): string;
    static lowerCaseFirstLetter(str: string): string;
    static upperCaseFirstLetter(str: string): string;
    static calculateCRC(value: string | object): number;
    static numberFormat(value: number, decimals?: number, decPoint?: string, thousandsSep?: string): string;
    static num2string(num: number): string;
    /**
     * Склонение числительных окончаний
     * @param string[] titles Список правильных слов с окончаниями для [1, 2, 5]
     * @param number amount Кол-во
     * Пример, (["Яблоко","Яблока","Яблок"], 0); -> Яблок
     */
    static declinationOfNumerals(titles: string[], amount: number): string;
}

declare class SUValidatorsHelper {
    static notEmptyValue(control: AbstractControl): ValidationErrors | null;
}

/**
  Класс-хелпер для работы с семантическими версиями (SemVer)
  Поддерживает формат major.minor.patch

  Примеры использования:

  // Основные методы
  console.log(SUVersionHelper.isValid("1.0.0")); // true
  console.log(SUVersionHelper.isValid("invalid")); // false

  const parsed = SUVersionHelper.parse("2.5.1");
  console.log(parsed); // { major: 2, minor: 5, patch: 1, original: "2.5.1" }

  console.log(SUVersionHelper.compare("1.0.0", "2.0.0")); // -1
  console.log(SUVersionHelper.satisfies("1.2.3", "^1.0.0")); // true

  // Утилитарные методы
  console.log(SUVersionHelper.nextPatch("1.2.3")); // "1.2.4"
  console.log(SUVersionHelper.nextMinor("1.2.3")); // "1.3.0"
  console.log(SUVersionHelper.nextMajor("1.2.3")); // "2.0.0"

  console.log(SUVersionHelper.format(1, 2, 3)); // "1.2.3"

  const versions = ["1.0.0", "2.0.0", "1.5.0", "1.0.1"];
  console.log(SUVersionHelper.sort(versions)); // ["1.0.0", "1.0.1", "1.5.0", "2.0.0"]
  console.log(SUVersionHelper.max(versions)); // "2.0.0"
  console.log(SUVersionHelper.min(versions)); // "1.0.0"

  console.log(SUVersionHelper.filterByRange(versions, ">=1.0.1")); // ["1.5.0", "2.0.0", "1.0.1"]

  // Проверки диапазонов
  console.log(SUVersionHelper.isAtLeast("1.2.3", "1.0.0")); // true
  console.log(SUVersionHelper.isAtMost("1.2.3", "2.0.0")); // true
  console.log(SUVersionHelper.isInRange("1.2.3", "1.0.0", "2.0.0")); // true
**/
declare class SUVersionHelper {
    private static readonly VERSION_REGEX;
    private static readonly MAX_VERSION_VALUE;
    private static readonly SIMPLE_OPERATOR_REGEX;
    private static readonly RANGE_REGEX;
    /**
     * Проверяет строку версии на соответствие формату major.minor.patch
     * и допустимость значений компонентов
     */
    static isValid(version: string): boolean;
    /**
     * Проверяет строку версии и возвращает разобранные компоненты
     * @throws {VersionError} Если версия невалидна
     */
    static parse(version: string): ISUVersionComponents;
    /**
     * Сравнивает две версии
     * @returns -1 если version1 < version2, 0 если равны, 1 если version1 > version2
     * @throws {VersionError} Если любая из версий невалидна
     */
    static compare(version1: string, version2: string): SComparisonResultType;
    /**
     * Проверяет, удовлетворяет ли версия заданному диапазону
     * Поддерживает операторы: >, >=, <, <=, =, ~, ^
     */
    static satisfies(version: string, range: string): boolean;
    /**
     * Проверяет, является ли версия больше или равна минимальной
     */
    static isAtLeast(version: string, minVersion: string): boolean;
    /**
     * Проверяет, является ли версия меньше или равна максимальной
     */
    static isAtMost(version: string, maxVersion: string): boolean;
    /**
     * Проверяет, находится ли версия в диапазоне (включительно)
     */
    static isInRange(version: string, minVersion: string, maxVersion: string): boolean;
    /**
     * Возвращает следующую major версию
     */
    static nextMajor(version: string): string;
    /**
     * Возвращает следующую minor версию
     */
    static nextMinor(version: string): string;
    /**
     * Возвращает следующую patch версию
     */
    static nextPatch(version: string): string;
    /**
     * Форматирует компоненты версии в строку
     */
    static format(major: number, minor: number, patch: number): string;
    /**
     * Сортирует массив версий по возрастанию
     */
    static sort(versions: string[]): string[];
    /**
     * Сортирует массив версий по убыванию
     */
    static sortDesc(versions: string[]): string[];
    /**
     * Возвращает максимальную версию из массива
     */
    static max(versions: string[]): string | null;
    /**
     * Возвращает минимальную версию из массива
     */
    static min(versions: string[]): string | null;
    /**
     * Фильтрует версии, удовлетворяющие заданному диапазону
     */
    static filterByRange(versions: string[], range: string): string[];
    /**
     * Проверяет карет-диапазон (^)
     * @private
     */
    private static satisfiesCaretRange;
    /**
     * Валидирует и нормализует версию (убирает пробелы)
     */
    static normalize(version: string): string;
    /**
     * Проверяет, является ли версия релизной (не pre-release)
     * В текущей реализации все версии считаются релизными
     * Можно расширить для поддержки pre-release версий
     */
    static isRelease(version: string): boolean;
}
/**
 * Типы для работы с версиями
 */
interface ISUVersionComponents {
    major: number;
    minor: number;
    patch: number;
    original: string;
}
type SComparisonResultType = -1 | 0 | 1;
/**
 * Кастомная ошибка для работы с версиями
 */
declare class VersionError extends Error {
    constructor(message: string);
}

interface ISelaxUtilsDBParamsType {
    dbVersion: number;
    dbName: string;
    dbTables: string[];
}
interface ISelaxUtilsParamsType {
    dbParams: ISelaxUtilsDBParamsType;
}
declare const SELAX_UTILS_PARAMS: InjectionToken<ISelaxUtilsParamsType>;
declare const provideSelaxUtilsEmptySettings: () => Provider;
/**
 * Предоставить конфигурацию для `@selax/utils`
 *
 * @param config - Конфигурация библиотеки
 * @returns Заданная конфигурация для токена `SELAX_UTILS_PARAMS`
 */
declare const provideSelaxUtilsSettings: (config: ISelaxUtilsParamsType) => Provider;

declare class SUStorageService {
    protected readonly storage: Storage;
    constructor(storage: Storage);
    get<T>(key: string): T | null;
    set(key: string, value: unknown): void;
    remove(key: string): void;
    clear(): void;
    private getValue;
    private normalizeValue;
}
declare class SULocalStorageService extends SUStorageService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SULocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SULocalStorageService>;
}
declare class SUSessionStorageService extends SUStorageService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SUSessionStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SUSessionStorageService>;
}

export { DATE_SEPARATOR, SELAX_UTILS_PARAMS, SUCanvasHelper, SUColorHelper, SUDBBase, SUDateHelper, SUFileHelper, SUJsonHelper, SULocalStorageService, SUNumberHelper, SUPixelmatch, SUSessionStorageService, SUStorageService, SUStringHelper, SUTexturePacker, SUValidatorsHelper, SUVersionHelper, TEXTURE_PACKER_HEIGHT, TEXTURE_PACKER_WIDTH, VersionError, provideSelaxUtilsEmptySettings, provideSelaxUtilsSettings };
export type { ISUCalcScaleImage, ISUCoords, ISUDimensions, ISUJsonFile, ISUPackerNode, ISURect, ISUVersionComponents, ISUWidthHeight, ISelaxUtilsDBParamsType, ISelaxUtilsParamsType, SComparisonResultType };
