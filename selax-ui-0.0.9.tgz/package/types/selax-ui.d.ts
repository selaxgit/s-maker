import * as _angular_core from '@angular/core';
import { OnInit, Injector, DestroyRef, ChangeDetectorRef, WritableSignal, Type, AfterViewInit, ViewContainerRef, AfterViewChecked, ElementRef } from '@angular/core';
import * as _angular_forms from '@angular/forms';
import { AbstractControl, FormGroupDirective, NgForm, NgControl, FormControl } from '@angular/forms';
import { ErrorStateMatcher, ThemePalette } from '@angular/material/core';
import { MatFormFieldAppearance } from '@angular/material/form-field';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatDialogRef } from '@angular/material/dialog';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { Params } from '@angular/router';
import { MatMenu } from '@angular/material/menu';

type SKnownValidationErrorKeyType = 'required' | 'email' | 'minlength' | 'maxlength' | 'min' | 'max' | 'numericMin' | 'numericMax' | 'pattern';
declare class HostControlErrorStateMatcher implements ErrorStateMatcher {
    private readonly getControl;
    constructor(getControl: () => AbstractControl | null);
    isErrorState(_: AbstractControl | null, form: FormGroupDirective | NgForm | null): boolean;
}

declare abstract class BaseControlValueAccessor<TValue> implements OnInit {
    protected readonly injector: Injector;
    protected readonly cvaDestroyRef: DestroyRef;
    protected readonly cvaCdr: ChangeDetectorRef;
    protected readonly ngControl: _angular_core.WritableSignal<NgControl | null>;
    protected readonly controlStateVersion: _angular_core.WritableSignal<number>;
    protected readonly disabled: _angular_core.WritableSignal<boolean>;
    protected onChange: (value: TValue) => void;
    protected onTouched: () => void;
    ngOnInit(): void;
    registerOnChange(fn: (value: TValue) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BaseControlValueAccessor<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BaseControlValueAccessor<any>, never, never, {}, {}, never, never, true, never>;
}

declare abstract class BaseFormFieldControl<TValue> extends BaseControlValueAccessor<TValue> {
    readonly label: _angular_core.InputSignal<string>;
    readonly keydownEvent: _angular_core.OutputEmitterRef<KeyboardEvent>;
    readonly enterEvent: _angular_core.OutputEmitterRef<KeyboardEvent>;
    readonly appearance: _angular_core.InputSignal<MatFormFieldAppearance>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly prefixIcon: _angular_core.InputSignal<string>;
    readonly suffixIcon: _angular_core.InputSignal<string>;
    readonly disabledState: _angular_core.InputSignal<boolean>;
    readonly readonlyState: _angular_core.InputSignal<boolean>;
    readonly errorMessages: _angular_core.InputSignal<Partial<Record<SKnownValidationErrorKeyType, string>>>;
    protected readonly control: _angular_core.Signal<_angular_forms.AbstractControl<any, any, any> | null>;
    protected readonly isDisabled: _angular_core.Signal<boolean>;
    protected readonly isReadonly: _angular_core.Signal<boolean>;
    protected emitKeydownEvent(event: Event): void;
    protected emitEnterEvent(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BaseFormFieldControl<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BaseFormFieldControl<any>, never, never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; "isSignal": true; }; "suffixIcon": { "alias": "suffixIcon"; "required": false; "isSignal": true; }; "disabledState": { "alias": "disabledState"; "required": false; "isSignal": true; }; "readonlyState": { "alias": "readonlyState"; "required": false; "isSignal": true; }; "errorMessages": { "alias": "errorMessages"; "required": false; "isSignal": true; }; }, { "keydownEvent": "keydownEvent"; "enterEvent": "enterEvent"; }, never, never, true, never>;
}

declare abstract class BaseClearableFormFieldControl<TValue> extends BaseFormFieldControl<TValue> {
    readonly showClearButton: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BaseClearableFormFieldControl<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BaseClearableFormFieldControl<any>, never, never, { "showClearButton": { "alias": "showClearButton"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare abstract class BaseValidatedFormFieldControl<TValue> extends BaseClearableFormFieldControl<TValue> {
    readonly errorText: _angular_core.InputSignal<string>;
    protected readonly errorStateMatcher: HostControlErrorStateMatcher;
    protected readonly resolvedErrorText: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BaseValidatedFormFieldControl<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<BaseValidatedFormFieldControl<any>, never, never, { "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type SCheckboxControlType = 'checkbox' | 'button-toggle' | 'slide-toggle' | 'select';
type SCheckboxLabelPositionType = 'left' | 'right';
declare class SCheckboxComponent extends BaseValidatedFormFieldControl<boolean> implements OnInit {
    readonly value: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly valueChange: _angular_core.OutputEmitterRef<boolean>;
    readonly controlType: _angular_core.InputSignal<SCheckboxControlType>;
    readonly labelPosition: _angular_core.InputSignal<SCheckboxLabelPositionType>;
    readonly onText: _angular_core.InputSignal<string>;
    readonly offText: _angular_core.InputSignal<string>;
    readonly selectWidth: _angular_core.InputSignal<string>;
    private readonly internalValue;
    protected readonly currentValue: _angular_core.Signal<boolean>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly showLeftLabel: _angular_core.Signal<boolean>;
    protected readonly showRightLabel: _angular_core.Signal<boolean>;
    protected readonly matLabelPosition: _angular_core.Signal<"before" | "after">;
    constructor();
    writeValue(value: boolean | null): void;
    protected handleControlChange(value: boolean): void;
    protected handleBlur(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SCheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SCheckboxComponent, "s-checkbox", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "controlType": { "alias": "controlType"; "required": false; "isSignal": true; }; "labelPosition": { "alias": "labelPosition"; "required": false; "isSignal": true; }; "onText": { "alias": "onText"; "required": false; "isSignal": true; }; "offText": { "alias": "offText"; "required": false; "isSignal": true; }; "selectWidth": { "alias": "selectWidth"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

declare class SColorPickerComponent extends BaseValidatedFormFieldControl<string> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignalWithTransform<string, string | number | null | undefined>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    readonly emptySwatchBorder: _angular_core.InputSignal<string>;
    readonly errorText: _angular_core.InputSignal<string>;
    private readonly destroyRef;
    private validatorFn;
    private destroyPaletteListeners;
    private readonly internalValue;
    private readonly interacted;
    protected readonly currentValue: _angular_core.Signal<string>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly isValidHex: _angular_core.Signal<boolean>;
    protected readonly showStandaloneError: _angular_core.Signal<boolean>;
    protected readonly swatchColor: _angular_core.Signal<string>;
    protected readonly swatchBorderColor: _angular_core.Signal<string>;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    protected readonly overlayOpen: _angular_core.WritableSignal<boolean>;
    protected readonly isPickingScreen: _angular_core.WritableSignal<boolean>;
    protected readonly copiedFeedback: _angular_core.WritableSignal<boolean>;
    protected readonly hue: _angular_core.WritableSignal<number>;
    private readonly saturation;
    private readonly valueLevel;
    private readonly markerX;
    private readonly markerY;
    protected readonly paletteBackground: _angular_core.Signal<string>;
    protected readonly markerStyle: _angular_core.Signal<{
        left: string;
        top: string;
    }>;
    private readonly eyeDropperConstructor;
    protected readonly eyedropperSupported: _angular_core.Signal<boolean>;
    private copyFeedbackTimeoutId;
    private readonly inputElement;
    constructor();
    ngOnInit(): void;
    writeValue(value: string | null): void;
    protected handleInput(event: Event): void;
    protected handleBlur(): void;
    protected clearValue(): void;
    protected toggleOverlay(): void;
    protected handleEscape(event: Event): void;
    protected closeOverlay(): void;
    protected pickFromScreen(): Promise<void>;
    protected handleHueInput(event: Event): void;
    protected beginPaletteDrag(event: PointerEvent, palette: HTMLElement): void;
    protected handlePaletteKeydown(event: KeyboardEvent): void;
    private pickColorFromPalette;
    private updateMarkerAndColor;
    private applyCurrentHsvColor;
    private setHsvFromHex;
    private destroyPaletteDrag;
    private createHexValidator;
    private copyToClipboard;
    private updateCopiedFeedback;
    private clearCopyFeedbackTimer;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SColorPickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SColorPickerComponent, "s-color-picker", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "emptySwatchBorder": { "alias": "emptySwatchBorder"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

declare class SDatepickerComponent extends BaseValidatedFormFieldControl<Date | null> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignalWithTransform<Date | null, string | Date | null | undefined>;
    readonly valueChange: _angular_core.OutputEmitterRef<Date | null>;
    private readonly internalValue;
    protected readonly currentValue: _angular_core.Signal<Date | null>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    private readonly inputElement;
    constructor();
    focus(): void;
    writeValue(value: Date | string | null): void;
    protected handleDateEvent(event: MatDatepickerInputEvent<Date>): void;
    protected handleBlur(): void;
    protected clearValue(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDatepickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SDatepickerComponent, "s-datepicker", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

declare enum SConfirmAlignButtonsEnum {
    Horizontal = "horizontal",
    Vertical = "vertical"
}

interface ISConfirmButton {
    title: string;
    color: ThemePalette;
    value: unknown;
}

declare class ConfirmDialogComponent {
    readonly message: _angular_core.InputSignal<string>;
    readonly alignButtons: _angular_core.InputSignal<SConfirmAlignButtonsEnum>;
    readonly buttons: _angular_core.InputSignal<ISConfirmButton[]>;
    readonly dialogRef: MatDialogRef<ConfirmDialogComponent>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConfirmDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConfirmDialogComponent, "ng-component", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "alignButtons": { "alias": "alignButtons"; "required": false; "isSignal": true; }; "buttons": { "alias": "buttons"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare enum SToastTypeEnum {
    Warning = "warning",
    Info = "info",
    Success = "success",
    Error = "error"
}

interface ISToastData {
    type?: SToastTypeEnum;
    message?: string;
    title?: string;
    iconName?: string;
    duration?: number;
    clickCallback?: (closeToast: () => void) => void;
}

declare class SToastService {
    private readonly document;
    private readonly injector;
    private readonly applicationRef;
    private readonly platformId;
    private readonly destroyRef;
    private toastList;
    private bodyPortalOutlet;
    constructor();
    showToastWarning(message: string, title?: string, duration?: number): void;
    showToastInfo(message: string, title?: string, duration?: number): void;
    showToastSuccess(message: string, title?: string, duration?: number): void;
    showToastError(message: string, title?: string, duration?: number): void;
    showToast(data: ISToastData): void;
    hideToast(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SToastService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SToastService>;
}

interface ISToast {
    id: number;
    isClosing: WritableSignal<boolean>;
    className: SToastTypeEnum;
    iconName: string;
    title: string | undefined;
    message: string;
    timeoutId?: ReturnType<typeof setTimeout>;
    closeTimeoutId?: ReturnType<typeof setTimeout>;
    clickCallback?: (closeToast: () => void) => void;
}
declare class SToastListComponent {
    readonly toastList: WritableSignal<ISToast[]>;
    readonly fadeInDurationMs = 300;
    readonly fadeOutDurationMs = 2500;
    private nextToastId;
    showToast(data: ISToastData): void;
    onFadeOutFinished(event: TransitionEvent, id: number): void;
    close(id: number): void;
    toastClick(id: number): void;
    hideAll(): void;
    private beginClose;
    private getIcon;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SToastListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SToastListComponent, "s-toast-list", never, {}, {}, never, never, true, never>;
}

declare class SDialogService {
    private bodyPortalOutlet;
    private readonly waitComponentPortal;
    private waitComponentRef;
    private readonly document;
    private readonly injector;
    private readonly applicationRef;
    private readonly platformId;
    private readonly destroyRef;
    private readonly dialog;
    private readonly toastService;
    constructor();
    showWait(message?: string | null): void;
    hideWait(): void;
    showToast(message: string, title?: string, typeToast?: SToastTypeEnum, duration?: number): void;
    showToast(message: ISToastData): void;
    showToastError(message: string, title?: string, duration?: number): void;
    showToastWarning(message: string, title?: string, duration?: number): void;
    showToastSuccess(message: string, title?: string, duration?: number): void;
    showToastInfo(message: string, title?: string, duration?: number): void;
    hideToast(): void;
    showModal<R = void, P extends object = object>(title: string, childComponent: Type<object>, childData?: P | null, disableClose?: boolean, autoFocus?: boolean, panelClass?: string | null): Observable<R | undefined>;
    showConfirm(message: string, title?: string, okButtonCaption?: string, cancelButtonCaption?: string): Observable<boolean>;
    showCustomConfirm<T>(message: string | null, title?: string, buttons?: ISConfirmButton[], alignButtons?: SConfirmAlignButtonsEnum): Observable<T | undefined>;
    showMessage(message: string, title?: string): Observable<void | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SDialogService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SDialogService>;
}

interface IModalData<T extends object> {
    title: string;
    childComponent: Type<object>;
    childData: T | null;
}
declare class ModalDialogComponent implements AfterViewInit {
    titleWindow: string;
    modalBodyRef: ViewContainerRef;
    private componentInstance;
    data: IModalData<Record<string, unknown>>;
    readonly dialogRef: MatDialogRef<any, any>;
    constructor();
    ngAfterViewInit(): void;
    onCloseModal(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

declare class WaitDialogComponent {
    readonly message: WritableSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<WaitDialogComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<WaitDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}

/**
 * Directive that restricts `s-input` to numeric-only input.
 *
 * Features:
 * - Blocks all non-numeric keyboard input (including paste)
 * - ArrowUp / ArrowDown increment / decrement by `step`
 * - Holding the arrow key accelerates: multiplier grows proportionally every 500 ms
 * - Optional decimal support with configurable decimal-places limit
 * - Optional min / max bounds
 *   - Arrow keys and paste clamp the value to [min, max]
 *   - Values set programmatically that fall outside the range trigger a validation error
 *
 * Usage:
 * ```html
 * <s-input label="Qty" [formControl]="ctrl" sNumeric [sNumericMin]="0" [sNumericMax]="999" />
 * ```
 */
declare class SNumericDirective implements OnInit {
    /** Base increment / decrement step for arrow keys. Default: 1. */
    readonly sNumericStep: _angular_core.InputSignal<number>;
    /** Allow decimal (fractional) numbers. Default: false. */
    readonly sNumericDecimal: _angular_core.InputSignal<boolean>;
    /**
     * Maximum number of digits after the decimal point.
     * Only relevant when `sNumericDecimal` is true. Default: 2.
     */
    readonly sNumericDecimalPlaces: _angular_core.InputSignal<number>;
    /** Minimum allowed value. Omit to disable lower bound. */
    readonly sNumericMin: _angular_core.InputSignal<number | undefined>;
    /** Maximum allowed value. Omit to disable upper bound. */
    readonly sNumericMax: _angular_core.InputSignal<number | undefined>;
    private readonly el;
    private readonly injector;
    private readonly destroyRef;
    private ngControl;
    private rangeValidatorFn;
    /** Timestamp of first arrow-key press in current hold sequence. */
    private holdStart;
    /** Interval that keeps ticking while arrow key is held. */
    private holdInterval;
    /** Direction of current arrow-key hold: +1 or -1. */
    private holdDirection;
    /** Programmatically increments current value by step × multiplier. */
    stepUp(multiplier?: number): void;
    /** Programmatically decrements current value by step × multiplier. */
    stepDown(multiplier?: number): void;
    ngOnInit(): void;
    onKeyDown(event: KeyboardEvent): void;
    onKeyUp(event: KeyboardEvent): void;
    onPaste(event: ClipboardEvent): void;
    private startHoldInterval;
    private clearHold;
    private applyStep;
    private clamp;
    private setValue;
    private parseCurrentValue;
    private parseValue;
    /**
     * Strips all characters that are not legal for the current configuration.
     * Returns null if the result is empty (nothing usable to insert).
     */
    private sanitize;
    private buildRangeValidator;
    /**
     * Returns true if typing the given digit at the current cursor position
     * would result in more decimal digits than `sNumericDecimalPlaces` allows.
     */
    private wouldExceedDecimalPlaces;
    private isSafeKey;
    private isNegativeAllowed;
    private getNativeInput;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SNumericDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SNumericDirective, "[sNumeric]", never, { "sNumericStep": { "alias": "sNumericStep"; "required": false; "isSignal": true; }; "sNumericDecimal": { "alias": "sNumericDecimal"; "required": false; "isSignal": true; }; "sNumericDecimalPlaces": { "alias": "sNumericDecimalPlaces"; "required": false; "isSignal": true; }; "sNumericMin": { "alias": "sNumericMin"; "required": false; "isSignal": true; }; "sNumericMax": { "alias": "sNumericMax"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SInputComponent extends BaseValidatedFormFieldControl<string> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignalWithTransform<string, string | number | null | undefined>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    private readonly internalValue;
    protected readonly currentValue: _angular_core.Signal<string>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    private readonly inputElement;
    constructor();
    focus(): void;
    writeValue(value: string | null): void;
    protected handleInput(event: Event): void;
    protected handleBlur(): void;
    protected clearValue(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SInputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SInputComponent, "s-input", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

type SInputNumberButtonsPositionType = 'left' | 'right' | 'sides';
declare class SInputNumberComponent extends BaseValidatedFormFieldControl<number | null> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<number | null>;
    readonly valueChange: _angular_core.OutputEmitterRef<number | null>;
    readonly step: _angular_core.InputSignal<number>;
    readonly decimal: _angular_core.InputSignal<boolean>;
    readonly decimalPlaces: _angular_core.InputSignal<number>;
    readonly min: _angular_core.InputSignal<number | undefined>;
    readonly max: _angular_core.InputSignal<number | undefined>;
    readonly buttonsPosition: _angular_core.InputSignal<SInputNumberButtonsPositionType>;
    private readonly destroyRef;
    protected readonly internalControl: FormControl<string>;
    private readonly currentDisplayValue;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    private readonly prefixSlot;
    protected readonly showPrefixContainer: _angular_core.Signal<boolean>;
    private readonly numericDirective;
    private readonly inputElement;
    private holdStart;
    private holdStartTimeout;
    private holdInterval;
    private holdDirection;
    constructor();
    writeValue(value: number | null): void;
    protected handleFocusIn(): void;
    protected handleFocusOut(): void;
    protected clearValue(): void;
    protected handleButtonPress(direction: 1 | -1): void;
    protected handleButtonRelease(): void;
    private formatDisplay;
    private parseToNumber;
    private applyStep;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SInputNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SInputNumberComponent, "s-input-number", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "decimal": { "alias": "decimal"; "required": false; "isSignal": true; }; "decimalPlaces": { "alias": "decimalPlaces"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "buttonsPosition": { "alias": "buttonsPosition"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, ["prefixSlot"], ["[sPrefix]", "[sSuffix]"], true, never>;
}

declare class SInputPasswordComponent extends BaseValidatedFormFieldControl<string> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly prefixIcon: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignalWithTransform<string, string | number | null | undefined>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    private readonly internalValue;
    protected readonly revealed: _angular_core.WritableSignal<boolean>;
    protected readonly currentValue: _angular_core.Signal<string>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly inputType: _angular_core.Signal<"text" | "password">;
    protected readonly toggleIcon: _angular_core.Signal<"visibility_off" | "visibility">;
    protected readonly toggleLabel: _angular_core.Signal<"Скрыть пароль" | "Показать пароль">;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    private readonly inputElement;
    constructor();
    focus(): void;
    writeValue(value: string | null): void;
    protected handleInput(event: Event): void;
    protected handleBlur(): void;
    protected toggleVisibility(): void;
    protected clearValue(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SInputPasswordComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SInputPasswordComponent, "s-input-password", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "prefixIcon": { "alias": "prefixIcon"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

interface ISelectOption {
    title: string;
    value: string | number | null;
    disabled?: boolean;
    data?: unknown;
}
declare class SSelectComponent extends BaseValidatedFormFieldControl<string | number | null> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string | number | null>;
    readonly valueChange: _angular_core.OutputEmitterRef<string | number | null>;
    readonly options: _angular_core.InputSignal<ISelectOption[]>;
    private readonly internalValue;
    protected readonly currentValue: _angular_core.Signal<string | number | null>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    private readonly selectElement;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    constructor();
    writeValue(value: string | number | null): void;
    protected handleSelectionChange(value: string | number | null): void;
    protected handleBlur(): void;
    protected clearValue(): void;
    focus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSelectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSelectComponent, "s-select", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

interface ISSlidePanelParams {
    disabledClose: boolean;
}
declare abstract class SSlidePanelExtendClass {
    closePanel(closeData: unknown): void;
}

declare const DEF_SLIDE_PANEL_PARAMS: ISSlidePanelParams;
declare class SSlidePanelComponent implements AfterViewInit {
    readonly params: _angular_core.InputSignal<Partial<ISSlidePanelParams>>;
    readonly component: _angular_core.InputSignal<Type<unknown>>;
    readonly data: _angular_core.InputSignal<Record<string, unknown> | undefined>;
    private componentRef;
    readonly isOpen: _angular_core.WritableSignal<boolean>;
    private readonly afterClosedSubject;
    readonly afterClosed$: rxjs.Observable<unknown>;
    private readonly elementRef;
    private closeData;
    private panelRef;
    private contentRef;
    ngAfterViewInit(): void;
    onHostClick(e: MouseEvent): void;
    onPanelTransitionEnd(e: TransitionEvent): void;
    doDestroy(): void;
    protected closePanel(closeData?: unknown): void;
    private clearComponent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSlidePanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSlidePanelComponent, "s-slide-panel", never, { "params": { "alias": "params"; "required": false; "isSignal": true; }; "component": { "alias": "component"; "required": true; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class SSlidePanelService {
    private readonly document;
    private readonly appRef;
    showPanel$<R>(component: Type<object>, data?: Record<string, unknown>, params?: Partial<ISSlidePanelParams>): Observable<R>;
    showPanel(component: Type<object>, data?: Record<string, unknown>, params?: Partial<ISSlidePanelParams>): SSlidePanelComponent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSlidePanelService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SSlidePanelService>;
}

declare class SSlidePanelContainerComponent implements AfterViewChecked {
    readonly panelTitle: _angular_core.InputSignal<string>;
    readonly applyButtonTitle: _angular_core.InputSignal<string>;
    readonly cancelButtonTitle: _angular_core.InputSignal<string>;
    readonly disabledApplyButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabledCancelButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visibleFooter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visibleFooterButtons: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visibleApplyButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visibleCancelButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closeEvent: _angular_core.OutputEmitterRef<void>;
    readonly applyEvent: _angular_core.OutputEmitterRef<void>;
    protected readonly prefixSlot: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    protected readonly suffixSlot: _angular_core.Signal<ElementRef<HTMLElement> | undefined>;
    protected readonly hasPrefixContent: _angular_core.WritableSignal<boolean>;
    protected readonly hasSuffixContent: _angular_core.WritableSignal<boolean>;
    ngAfterViewChecked(): void;
    onClosePanel(): void;
    onApplyPanel(): void;
    private slotHasContent;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SSlidePanelContainerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SSlidePanelContainerComponent, "s-slide-panel-container", never, { "panelTitle": { "alias": "panelTitle"; "required": false; "isSignal": true; }; "applyButtonTitle": { "alias": "applyButtonTitle"; "required": false; "isSignal": true; }; "cancelButtonTitle": { "alias": "cancelButtonTitle"; "required": false; "isSignal": true; }; "disabledApplyButton": { "alias": "disabledApplyButton"; "required": false; "isSignal": true; }; "disabledCancelButton": { "alias": "disabledCancelButton"; "required": false; "isSignal": true; }; "visibleFooter": { "alias": "visibleFooter"; "required": false; "isSignal": true; }; "visibleFooterButtons": { "alias": "visibleFooterButtons"; "required": false; "isSignal": true; }; "visibleApplyButton": { "alias": "visibleApplyButton"; "required": false; "isSignal": true; }; "visibleCancelButton": { "alias": "visibleCancelButton"; "required": false; "isSignal": true; }; }, { "closeEvent": "closeEvent"; "applyEvent": "applyEvent"; }, never, ["*", "[sPrefix]", "[sSuffix]"], true, never>;
}

declare class STextareaComponent extends BaseValidatedFormFieldControl<string> implements OnInit {
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly rows: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly value: _angular_core.InputSignalWithTransform<string, string | number | null | undefined>;
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    private readonly internalValue;
    protected readonly currentValue: _angular_core.Signal<string>;
    protected readonly hasValue: _angular_core.Signal<boolean>;
    protected readonly prefixSlot: _angular_core.Signal<unknown>;
    protected readonly showPrefixContainer: _angular_core.Signal<string | boolean>;
    private readonly textareaElement;
    constructor();
    focus(): void;
    writeValue(value: string | null): void;
    protected handleInput(event: Event): void;
    protected handleBlur(): void;
    protected clearValue(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STextareaComponent, "s-textarea", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, ["[sPrefix]", "[sSuffix]"], true, never>;
}

interface ISNavItem {
    displayName: string;
    route?: string;
    queryParams?: Params;
    badgeValue?: string;
    badgeColor?: ThemePalette;
    attrStyle?: string | null;
    children?: ISNavItem[];
    data?: unknown;
}

declare class STreeMenuComponent {
    readonly items: _angular_core.InputSignal<ISNavItem[]>;
    readonly useRouterLink: _angular_core.InputSignal<boolean>;
    readonly itemClickEvent: _angular_core.OutputEmitterRef<ISNavItem>;
    childMenu: MatMenu;
    trackByItem(_index: number, item: ISNavItem): string;
    onItemClick(item: ISNavItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<STreeMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<STreeMenuComponent, "s-tree-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "useRouterLink": { "alias": "useRouterLink"; "required": false; "isSignal": true; }; }, { "itemClickEvent": "itemClickEvent"; }, never, never, true, never>;
}

export { ConfirmDialogComponent, DEF_SLIDE_PANEL_PARAMS, ModalDialogComponent, SCheckboxComponent, SColorPickerComponent, SConfirmAlignButtonsEnum, SDatepickerComponent, SDialogService, SInputComponent, SInputNumberComponent, SInputPasswordComponent, SNumericDirective, SSelectComponent, SSlidePanelComponent, SSlidePanelContainerComponent, SSlidePanelExtendClass, SSlidePanelService, STextareaComponent, SToastListComponent, SToastService, SToastTypeEnum, STreeMenuComponent, WaitDialogComponent };
export type { IModalData, ISConfirmButton, ISNavItem, ISSlidePanelParams, ISToastData, ISelectOption, SCheckboxControlType, SCheckboxLabelPositionType, SInputNumberButtonsPositionType };
