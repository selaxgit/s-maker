import * as i0 from '@angular/core';
import { inject, Injector, DestroyRef, ChangeDetectorRef, signal, Directive, input, output, computed, effect, forwardRef, ChangeDetectionStrategy, Component, viewChild, DOCUMENT, ApplicationRef, PLATFORM_ID, Injectable, ViewContainerRef, ViewChild, ElementRef, HostListener, contentChild, createComponent, booleanAttribute, numberAttribute } from '@angular/core';
import * as i1$1 from '@angular/forms';
import { NgControl, NG_VALUE_ACCESSOR, FormControl, ReactiveFormsModule } from '@angular/forms';
import * as i4$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i4 from '@angular/material/button-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import * as i2$1 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i6 from '@angular/material/select';
import { MatSelectModule, MatSelect } from '@angular/material/select';
import * as i3 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { CdkOverlayOrigin, CdkConnectedOverlay } from '@angular/cdk/overlay';
import * as i3$1 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import * as i4$2 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { DomPortalOutlet, ComponentPortal } from '@angular/cdk/portal';
import { isPlatformBrowser } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { map, Subject } from 'rxjs';
import * as i2$2 from '@angular/material/badge';
import { MatBadgeModule } from '@angular/material/badge';
import * as i1$2 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i3$2 from '@angular/router';
import { RouterModule } from '@angular/router';

/* eslint-disable @typescript-eslint/no-empty-function */
class BaseControlValueAccessor {
    injector = inject(Injector);
    cvaDestroyRef = inject(DestroyRef);
    cvaCdr = inject(ChangeDetectorRef);
    ngControl = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "ngControl" }] : /* istanbul ignore next */ []));
    controlStateVersion = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlStateVersion" }] : /* istanbul ignore next */ []));
    disabled = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabled" }] : /* istanbul ignore next */ []));
    onChange = () => { };
    onTouched = () => { };
    ngOnInit() {
        this.ngControl.set(this.injector.get(NgControl, null, { self: true, optional: true }));
        this.ngControl()
            ?.control?.events.pipe(takeUntilDestroyed(this.cvaDestroyRef))
            .subscribe(() => {
            this.controlStateVersion.update((value) => value + 1);
            this.cvaCdr.markForCheck();
        });
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseControlValueAccessor, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.0", type: BaseControlValueAccessor, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseControlValueAccessor, decorators: [{
            type: Directive
        }] });

class BaseFormFieldControl extends BaseControlValueAccessor {
    label = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    keydownEvent = output();
    enterEvent = output();
    appearance = input('outline', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "appearance" }] : /* istanbul ignore next */ []));
    hint = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hint" }] : /* istanbul ignore next */ []));
    prefixIcon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixIcon" }] : /* istanbul ignore next */ []));
    suffixIcon = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffixIcon" }] : /* istanbul ignore next */ []));
    disabledState = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "disabledState" }] : /* istanbul ignore next */ []));
    readonlyState = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "readonlyState" }] : /* istanbul ignore next */ []));
    errorMessages = input({}, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorMessages" }] : /* istanbul ignore next */ []));
    control = computed(() => {
        this.controlStateVersion();
        return this.ngControl()?.control ?? null;
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "control" }] : /* istanbul ignore next */ []));
    isDisabled = computed(() => this.disabled() || this.disabledState(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isDisabled" }] : /* istanbul ignore next */ []));
    isReadonly = computed(() => this.readonlyState(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isReadonly" }] : /* istanbul ignore next */ []));
    emitKeydownEvent(event) {
        this.keydownEvent.emit(event);
    }
    emitEnterEvent(event) {
        this.enterEvent.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseFormFieldControl, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.0.0", type: BaseFormFieldControl, isStandalone: true, inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: true, transformFunction: null }, appearance: { classPropertyName: "appearance", publicName: "appearance", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, prefixIcon: { classPropertyName: "prefixIcon", publicName: "prefixIcon", isSignal: true, isRequired: false, transformFunction: null }, suffixIcon: { classPropertyName: "suffixIcon", publicName: "suffixIcon", isSignal: true, isRequired: false, transformFunction: null }, disabledState: { classPropertyName: "disabledState", publicName: "disabledState", isSignal: true, isRequired: false, transformFunction: null }, readonlyState: { classPropertyName: "readonlyState", publicName: "readonlyState", isSignal: true, isRequired: false, transformFunction: null }, errorMessages: { classPropertyName: "errorMessages", publicName: "errorMessages", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { keydownEvent: "keydownEvent", enterEvent: "enterEvent" }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseFormFieldControl, decorators: [{
            type: Directive
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: true }] }], keydownEvent: [{ type: i0.Output, args: ["keydownEvent"] }], enterEvent: [{ type: i0.Output, args: ["enterEvent"] }], appearance: [{ type: i0.Input, args: [{ isSignal: true, alias: "appearance", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], prefixIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefixIcon", required: false }] }], suffixIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "suffixIcon", required: false }] }], disabledState: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledState", required: false }] }], readonlyState: [{ type: i0.Input, args: [{ isSignal: true, alias: "readonlyState", required: false }] }], errorMessages: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorMessages", required: false }] }] } });

class BaseClearableFormFieldControl extends BaseFormFieldControl {
    showClearButton = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showClearButton" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseClearableFormFieldControl, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.0.0", type: BaseClearableFormFieldControl, isStandalone: true, inputs: { showClearButton: { classPropertyName: "showClearButton", publicName: "showClearButton", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseClearableFormFieldControl, decorators: [{
            type: Directive
        }], propDecorators: { showClearButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "showClearButton", required: false }] }] } });

function toStringValue(value) {
    return value == null ? '' : String(value);
}
class HostControlErrorStateMatcher {
    getControl;
    constructor(getControl) {
        this.getControl = getControl;
    }
    isErrorState(_, form) {
        const control = this.getControl();
        if (!control) {
            return false;
        }
        const formSubmitted = Boolean(form?.submitted);
        return control.invalid && (control.touched || control.dirty || formSubmitted);
    }
}
function getFormFieldErrorText(errors, messages, fallbackMessage) {
    if (!errors) {
        return fallbackMessage;
    }
    if (errors['required']) {
        return messages.required ?? 'Поле обязательно для заполнения';
    }
    if (errors['email']) {
        return messages.email ?? 'Введите корректный email';
    }
    const minLengthError = errors['minlength'];
    if (minLengthError) {
        return messages.minlength ?? `Минимальная длина: ${minLengthError.requiredLength}`;
    }
    const maxLengthError = errors['maxlength'];
    if (maxLengthError) {
        return messages.maxlength ?? `Максимальная длина: ${maxLengthError.requiredLength}`;
    }
    const minError = errors['min'];
    if (minError) {
        return messages.min ?? `Минимальное значение: ${minError.min}`;
    }
    const maxError = errors['max'];
    if (maxError) {
        return messages.max ?? `Максимальное значение: ${maxError.max}`;
    }
    const numericMinError = errors['numericMin'];
    if (numericMinError) {
        return messages.numericMin ?? `Минимальное значение: ${numericMinError.min}`;
    }
    const numericMaxError = errors['numericMax'];
    if (numericMaxError) {
        return messages.numericMax ?? `Максимальное значение: ${numericMaxError.max}`;
    }
    if (errors['pattern']) {
        return messages.pattern ?? 'Значение не соответствует требуемому формату';
    }
    return fallbackMessage;
}

class BaseValidatedFormFieldControl extends BaseClearableFormFieldControl {
    errorText = input('Поле заполнено некорректно', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorText" }] : /* istanbul ignore next */ []));
    errorStateMatcher = new HostControlErrorStateMatcher(() => this.control());
    resolvedErrorText = computed(() => getFormFieldErrorText(this.control()?.errors, this.errorMessages(), this.errorText()), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "resolvedErrorText" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseValidatedFormFieldControl, deps: null, target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.0.0", type: BaseValidatedFormFieldControl, isStandalone: true, inputs: { errorText: { classPropertyName: "errorText", publicName: "errorText", isSignal: true, isRequired: false, transformFunction: null } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: BaseValidatedFormFieldControl, decorators: [{
            type: Directive
        }], propDecorators: { errorText: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorText", required: false }] }] } });

function toBooleanValue(value) {
    if (typeof value === 'boolean') {
        return value;
    }
    if (typeof value === 'string') {
        const normalized = value.trim().toLowerCase();
        if (normalized === 'true') {
            return true;
        }
        if (normalized === 'false') {
            return false;
        }
    }
    return Boolean(value);
}
class SCheckboxComponent extends BaseValidatedFormFieldControl {
    value = input(false, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toBooleanValue });
    valueChange = output();
    controlType = input('checkbox', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "controlType" }] : /* istanbul ignore next */ []));
    labelPosition = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "labelPosition" }] : /* istanbul ignore next */ []));
    onText = input('Да', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "onText" }] : /* istanbul ignore next */ []));
    offText = input('Нет', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "offText" }] : /* istanbul ignore next */ []));
    selectWidth = input('80px', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectWidth" }] : /* istanbul ignore next */ []));
    internalValue = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    showLeftLabel = computed(() => this.labelPosition() === 'left', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showLeftLabel" }] : /* istanbul ignore next */ []));
    showRightLabel = computed(() => this.labelPosition() === 'right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showRightLabel" }] : /* istanbul ignore next */ []));
    matLabelPosition = computed(() => (this.labelPosition() === 'left' ? 'before' : 'after'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "matLabelPosition" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    writeValue(value) {
        this.internalValue.set(toBooleanValue(value));
    }
    handleControlChange(value) {
        this.internalValue.set(value);
        this.onChange(value);
        this.valueChange.emit(value);
        this.onTouched();
    }
    handleBlur() {
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SCheckboxComponent, isStandalone: true, selector: "s-checkbox", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, controlType: { classPropertyName: "controlType", publicName: "controlType", isSignal: true, isRequired: false, transformFunction: null }, labelPosition: { classPropertyName: "labelPosition", publicName: "labelPosition", isSignal: true, isRequired: false, transformFunction: null }, onText: { classPropertyName: "onText", publicName: "onText", isSignal: true, isRequired: false, transformFunction: null }, offText: { classPropertyName: "offText", publicName: "offText", isSignal: true, isRequired: false, transformFunction: null }, selectWidth: { classPropertyName: "selectWidth", publicName: "selectWidth", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SCheckboxComponent),
                multi: true,
            },
        ], usesInheritance: true, ngImport: i0, template: "<div class=\"s-checkbox\" [class.s-checkbox--disabled]=\"isDisabled() || isReadonly()\">\n  <span class=\"s-checkbox__prefix\">\n    @if (prefixIcon()) {\n      <mat-icon>{{ prefixIcon() }}</mat-icon>\n    }\n    <ng-content select=\"[sPrefix]\" />\n  </span>\n\n  <div class=\"s-checkbox__control\">\n    @switch (controlType()) {\n      @case ('checkbox') {\n        <mat-checkbox\n          [checked]=\"currentValue()\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          [labelPosition]=\"matLabelPosition()\"\n          (change)=\"handleControlChange($event.checked)\"\n          (blur)=\"handleBlur()\"\n        >\n          {{ label() }}\n        </mat-checkbox>\n      }\n\n      @case ('slide-toggle') {\n        <mat-slide-toggle\n          [checked]=\"currentValue()\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          [labelPosition]=\"matLabelPosition()\"\n          (change)=\"handleControlChange($event.checked)\"\n          (blur)=\"handleBlur()\"\n        >\n          {{ label() }}\n        </mat-slide-toggle>\n      }\n\n      @case ('button-toggle') {\n        <div class=\"s-checkbox__row\">\n          @if (showLeftLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n\n          <mat-button-toggle-group\n            [value]=\"currentValue()\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (change)=\"handleControlChange($event.value)\"\n            (blur)=\"handleBlur()\"\n          >\n            <mat-button-toggle [value]=\"false\">{{ offText() }}</mat-button-toggle>\n            <mat-button-toggle [value]=\"true\">{{ onText() }}</mat-button-toggle>\n          </mat-button-toggle-group>\n\n          @if (showRightLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n        </div>\n      }\n\n      @case ('select') {\n        <div class=\"s-checkbox__row\">\n          @if (showLeftLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n\n          <mat-form-field class=\"s-checkbox__select\" [appearance]=\"appearance()\" [style.width]=\"selectWidth()\">\n            <mat-select\n              [value]=\"currentValue()\"\n              [disabled]=\"isDisabled() || isReadonly()\"\n              (selectionChange)=\"handleControlChange($event.value)\"\n              (blur)=\"handleBlur()\"\n            >\n              <mat-option [value]=\"false\">{{ offText() }}</mat-option>\n              <mat-option [value]=\"true\">{{ onText() }}</mat-option>\n            </mat-select>\n          </mat-form-field>\n\n          @if (showRightLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n        </div>\n      }\n    }\n  </div>\n\n  <span class=\"s-checkbox__suffix\">\n    <ng-content select=\"[sSuffix]\" />\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </span>\n</div>\n@if (hint()) {\n  <div class=\"s-checkbox__hint\">{{ hint() }}</div>\n}\n\n@if (control(); as currentControl) {\n  @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n    <div class=\"s-checkbox__error\">{{ resolvedErrorText() }}</div>\n  }\n}\n", styles: [".s-checkbox{display:grid;align-items:center;width:100%;grid-template-columns:auto minmax(0,1fr) auto;gap:8px}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-checkbox__prefix,.s-checkbox__suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap;gap:6px}.s-checkbox__prefix:empty,.s-checkbox__suffix:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}.s-checkbox__control{display:grid;gap:6px}.s-checkbox__row{display:inline-flex;align-items:center;gap:10px}.s-checkbox__row ::ng-deep .mat-mdc-form-field-subscript-wrapper,.s-checkbox__row ::ng-deep .mat-mdc-form-field-bottom-align{display:none}.s-checkbox__label{color:#0f172a;font-size:14px;font-weight:500}.s-checkbox__hint{color:#516172;font-size:12px}.s-checkbox__error{color:#c62828;font-size:12px}.s-checkbox--disabled{opacity:.72}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2$1.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatSlideToggleModule }, { kind: "component", type: i3.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "ngmodule", type: MatButtonToggleModule }, { kind: "directive", type: i4.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i4.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatButtonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-checkbox', imports: [
                        MatIconModule,
                        MatCheckboxModule,
                        MatSlideToggleModule,
                        MatButtonToggleModule,
                        MatFormFieldModule,
                        MatSelectModule,
                        MatButtonModule,
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SCheckboxComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"s-checkbox\" [class.s-checkbox--disabled]=\"isDisabled() || isReadonly()\">\n  <span class=\"s-checkbox__prefix\">\n    @if (prefixIcon()) {\n      <mat-icon>{{ prefixIcon() }}</mat-icon>\n    }\n    <ng-content select=\"[sPrefix]\" />\n  </span>\n\n  <div class=\"s-checkbox__control\">\n    @switch (controlType()) {\n      @case ('checkbox') {\n        <mat-checkbox\n          [checked]=\"currentValue()\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          [labelPosition]=\"matLabelPosition()\"\n          (change)=\"handleControlChange($event.checked)\"\n          (blur)=\"handleBlur()\"\n        >\n          {{ label() }}\n        </mat-checkbox>\n      }\n\n      @case ('slide-toggle') {\n        <mat-slide-toggle\n          [checked]=\"currentValue()\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          [labelPosition]=\"matLabelPosition()\"\n          (change)=\"handleControlChange($event.checked)\"\n          (blur)=\"handleBlur()\"\n        >\n          {{ label() }}\n        </mat-slide-toggle>\n      }\n\n      @case ('button-toggle') {\n        <div class=\"s-checkbox__row\">\n          @if (showLeftLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n\n          <mat-button-toggle-group\n            [value]=\"currentValue()\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (change)=\"handleControlChange($event.value)\"\n            (blur)=\"handleBlur()\"\n          >\n            <mat-button-toggle [value]=\"false\">{{ offText() }}</mat-button-toggle>\n            <mat-button-toggle [value]=\"true\">{{ onText() }}</mat-button-toggle>\n          </mat-button-toggle-group>\n\n          @if (showRightLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n        </div>\n      }\n\n      @case ('select') {\n        <div class=\"s-checkbox__row\">\n          @if (showLeftLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n\n          <mat-form-field class=\"s-checkbox__select\" [appearance]=\"appearance()\" [style.width]=\"selectWidth()\">\n            <mat-select\n              [value]=\"currentValue()\"\n              [disabled]=\"isDisabled() || isReadonly()\"\n              (selectionChange)=\"handleControlChange($event.value)\"\n              (blur)=\"handleBlur()\"\n            >\n              <mat-option [value]=\"false\">{{ offText() }}</mat-option>\n              <mat-option [value]=\"true\">{{ onText() }}</mat-option>\n            </mat-select>\n          </mat-form-field>\n\n          @if (showRightLabel()) {\n            <span class=\"s-checkbox__label\">{{ label() }}</span>\n          }\n        </div>\n      }\n    }\n  </div>\n\n  <span class=\"s-checkbox__suffix\">\n    <ng-content select=\"[sSuffix]\" />\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </span>\n</div>\n@if (hint()) {\n  <div class=\"s-checkbox__hint\">{{ hint() }}</div>\n}\n\n@if (control(); as currentControl) {\n  @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n    <div class=\"s-checkbox__error\">{{ resolvedErrorText() }}</div>\n  }\n}\n", styles: [".s-checkbox{display:grid;align-items:center;width:100%;grid-template-columns:auto minmax(0,1fr) auto;gap:8px}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-checkbox__prefix,.s-checkbox__suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap;gap:6px}.s-checkbox__prefix:empty,.s-checkbox__suffix:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}.s-checkbox__control{display:grid;gap:6px}.s-checkbox__row{display:inline-flex;align-items:center;gap:10px}.s-checkbox__row ::ng-deep .mat-mdc-form-field-subscript-wrapper,.s-checkbox__row ::ng-deep .mat-mdc-form-field-bottom-align{display:none}.s-checkbox__label{color:#0f172a;font-size:14px;font-weight:500}.s-checkbox__hint{color:#516172;font-size:12px}.s-checkbox__error{color:#c62828;font-size:12px}.s-checkbox--disabled{opacity:.72}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], controlType: [{ type: i0.Input, args: [{ isSignal: true, alias: "controlType", required: false }] }], labelPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "labelPosition", required: false }] }], onText: [{ type: i0.Input, args: [{ isSignal: true, alias: "onText", required: false }] }], offText: [{ type: i0.Input, args: [{ isSignal: true, alias: "offText", required: false }] }], selectWidth: [{ type: i0.Input, args: [{ isSignal: true, alias: "selectWidth", required: false }] }] } });

/* eslint-disable @typescript-eslint/no-magic-numbers */
const HEX_PATTERN = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
function normalizeHexInput(value) {
    const raw = value.trim();
    if (!raw) {
        return '';
    }
    const hexChars = raw
        .replace(/#/g, '')
        .replace(/[^0-9a-fA-F]/g, '')
        .slice(0, 6);
    if (!hexChars) {
        return '';
    }
    return `#${hexChars}`;
}
class SColorPickerComponent extends BaseValidatedFormFieldControl {
    placeholder = input('Цвет не выбран', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = input('', { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toStringValue });
    valueChange = output();
    emptySwatchBorder = input('#c6c6c6', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "emptySwatchBorder" }] : /* istanbul ignore next */ []));
    errorText = input('Некорректный HEX-формат', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "errorText" }] : /* istanbul ignore next */ []));
    destroyRef = inject(DestroyRef);
    validatorFn = null;
    destroyPaletteListeners = null;
    internalValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    interacted = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "interacted" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    isValidHex = computed(() => {
        const value = this.currentValue();
        if (!value) {
            return true;
        }
        return HEX_PATTERN.test(value);
    }, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isValidHex" }] : /* istanbul ignore next */ []));
    showStandaloneError = computed(() => !this.control() && this.interacted() && this.hasValue() && !this.isValidHex(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showStandaloneError" }] : /* istanbul ignore next */ []));
    swatchColor = computed(() => this.isValidHex() && this.hasValue() ? this.currentValue() : 'transparent', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "swatchColor" }] : /* istanbul ignore next */ []));
    swatchBorderColor = computed(() => this.isValidHex() && this.hasValue() ? this.currentValue() : this.emptySwatchBorder(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "swatchBorderColor" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    overlayOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "overlayOpen" }] : /* istanbul ignore next */ []));
    isPickingScreen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isPickingScreen" }] : /* istanbul ignore next */ []));
    copiedFeedback = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "copiedFeedback" }] : /* istanbul ignore next */ []));
    hue = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hue" }] : /* istanbul ignore next */ []));
    saturation = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "saturation" }] : /* istanbul ignore next */ []));
    valueLevel = signal(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "valueLevel" }] : /* istanbul ignore next */ []));
    markerX = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "markerX" }] : /* istanbul ignore next */ []));
    markerY = signal(0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "markerY" }] : /* istanbul ignore next */ []));
    paletteBackground = computed(() => `linear-gradient(to bottom, rgba(255,255,255,0) 0%, rgba(0,0,0,1) 100%), linear-gradient(to right, #ffffff 0%, hsl(${this.hue()}, 100%, 50%) 100%)`, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "paletteBackground" }] : /* istanbul ignore next */ []));
    markerStyle = computed(() => ({
        left: `${this.markerX()}px`,
        top: `${this.markerY()}px`,
    }), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "markerStyle" }] : /* istanbul ignore next */ []));
    eyeDropperConstructor = getEyeDropperConstructor();
    eyedropperSupported = computed(() => !!this.eyeDropperConstructor, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "eyedropperSupported" }] : /* istanbul ignore next */ []));
    copyFeedbackTimeoutId = null;
    inputElement = viewChild('inputElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(normalizeHexInput(this.value()));
            }
        });
        effect(() => {
            const value = this.currentValue();
            if (value && HEX_PATTERN.test(value)) {
                this.setHsvFromHex(value);
            }
        });
        this.destroyRef.onDestroy(() => {
            this.destroyPaletteDrag();
            this.clearCopyFeedbackTimer();
            if (this.validatorFn && this.ngControl()?.control) {
                this.ngControl()?.control?.removeValidators(this.validatorFn);
                this.ngControl()?.control?.updateValueAndValidity({ emitEvent: false });
            }
        });
    }
    ngOnInit() {
        super.ngOnInit();
        const control = this.ngControl()?.control;
        if (control) {
            this.validatorFn = this.createHexValidator();
            control.addValidators(this.validatorFn);
            control.updateValueAndValidity({ emitEvent: false });
        }
    }
    writeValue(value) {
        this.internalValue.set(normalizeHexInput(toStringValue(value)));
    }
    handleInput(event) {
        const nextValue = normalizeHexInput(event.target.value);
        this.interacted.set(true);
        this.internalValue.set(nextValue);
        this.onChange(nextValue);
        this.valueChange.emit(nextValue);
    }
    handleBlur() {
        this.interacted.set(true);
        this.onTouched();
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.interacted.set(true);
        this.internalValue.set('');
        this.onChange('');
        this.valueChange.emit('');
        this.onTouched();
    }
    toggleOverlay() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.overlayOpen.update((state) => !state);
    }
    handleEscape(event) {
        if (!this.overlayOpen()) {
            return;
        }
        event.preventDefault();
        this.closeOverlay();
    }
    closeOverlay() {
        this.overlayOpen.set(false);
        this.destroyPaletteDrag();
    }
    async pickFromScreen() {
        if (this.isDisabled() || this.isReadonly() || this.isPickingScreen()) {
            return;
        }
        if (!this.eyeDropperConstructor) {
            return;
        }
        this.isPickingScreen.set(true);
        try {
            const eyedropper = new this.eyeDropperConstructor();
            const result = await eyedropper.open();
            const nextValue = normalizeHexInput(result.sRGBHex);
            if (!HEX_PATTERN.test(nextValue)) {
                return;
            }
            this.interacted.set(true);
            this.internalValue.set(nextValue);
            this.onChange(nextValue);
            this.valueChange.emit(nextValue);
            this.onTouched();
            this.setHsvFromHex(nextValue);
            const copied = await this.copyToClipboard(nextValue);
            this.updateCopiedFeedback(copied);
            this.closeOverlay();
        }
        catch {
            this.updateCopiedFeedback(false);
        }
        finally {
            this.isPickingScreen.set(false);
        }
    }
    handleHueInput(event) {
        const nextHue = Number(event.target.value);
        if (!Number.isFinite(nextHue)) {
            return;
        }
        this.hue.set(clamp(nextHue, 0, 360));
        this.applyCurrentHsvColor();
    }
    beginPaletteDrag(event, palette) {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        event.preventDefault();
        this.pickColorFromPalette(event, palette);
        const onMove = (moveEvent) => {
            this.pickColorFromPalette(moveEvent, palette);
        };
        const onUp = () => {
            this.destroyPaletteDrag();
        };
        window.addEventListener('pointermove', onMove);
        window.addEventListener('pointerup', onUp);
        window.addEventListener('pointercancel', onUp);
        this.destroyPaletteListeners = () => {
            window.removeEventListener('pointermove', onMove);
            window.removeEventListener('pointerup', onUp);
            window.removeEventListener('pointercancel', onUp);
            this.destroyPaletteListeners = null;
        };
    }
    handlePaletteKeydown(event) {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        const step = event.shiftKey ? 8 : 2;
        let nextX = this.markerX();
        let nextY = this.markerY();
        switch (event.key) {
            case 'ArrowLeft':
                nextX -= step;
                break;
            case 'ArrowRight':
                nextX += step;
                break;
            case 'ArrowUp':
                nextY -= step;
                break;
            case 'ArrowDown':
                nextY += step;
                break;
            default:
                return;
        }
        event.preventDefault();
        this.updateMarkerAndColor(nextX, nextY, 200, 200);
    }
    pickColorFromPalette(event, palette) {
        const rect = palette.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;
        this.updateMarkerAndColor(event.clientX - rect.left, event.clientY - rect.top, width, height);
    }
    updateMarkerAndColor(rawX, rawY, width, height) {
        const markerX = clamp(rawX, 0, width);
        const markerY = clamp(rawY, 0, height);
        this.markerX.set(markerX);
        this.markerY.set(markerY);
        this.saturation.set(clamp(markerX / width, 0, 1));
        this.valueLevel.set(clamp(1 - markerY / height, 0, 1));
        this.applyCurrentHsvColor();
    }
    applyCurrentHsvColor() {
        const next = hsvToHex(this.hue(), this.saturation(), this.valueLevel());
        this.interacted.set(true);
        this.internalValue.set(next);
        this.onChange(next);
        this.valueChange.emit(next);
    }
    setHsvFromHex(hex) {
        const rgb = hexToRgb(hex);
        if (!rgb) {
            return;
        }
        const hsv = rgbToHsv(rgb.r, rgb.g, rgb.b);
        this.hue.set(hsv.h);
        this.saturation.set(hsv.s);
        this.valueLevel.set(hsv.v);
        const size = 200;
        this.markerX.set(hsv.s * size);
        this.markerY.set((1 - hsv.v) * size);
    }
    destroyPaletteDrag() {
        this.destroyPaletteListeners?.();
    }
    createHexValidator() {
        return (control) => {
            const normalized = normalizeHexInput(toStringValue(control.value));
            if (!normalized) {
                return null;
            }
            if (HEX_PATTERN.test(normalized)) {
                return null;
            }
            return {
                pattern: {
                    requiredPattern: HEX_PATTERN.source,
                    actualValue: control.value,
                },
            };
        };
    }
    async copyToClipboard(value) {
        const clipboard = globalThis.navigator?.clipboard;
        if (!clipboard) {
            return false;
        }
        try {
            await clipboard.writeText(value);
            return true;
        }
        catch {
            return false;
        }
    }
    updateCopiedFeedback(copied) {
        this.clearCopyFeedbackTimer();
        this.copiedFeedback.set(copied);
        if (!copied) {
            return;
        }
        this.copyFeedbackTimeoutId = setTimeout(() => {
            this.copiedFeedback.set(false);
            this.copyFeedbackTimeoutId = null;
        }, 1600);
    }
    clearCopyFeedbackTimer() {
        if (!this.copyFeedbackTimeoutId) {
            return;
        }
        clearTimeout(this.copyFeedbackTimeoutId);
        this.copyFeedbackTimeoutId = null;
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SColorPickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SColorPickerComponent, isStandalone: true, selector: "s-color-picker", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, emptySwatchBorder: { classPropertyName: "emptySwatchBorder", publicName: "emptySwatchBorder", isSignal: true, isRequired: false, transformFunction: null }, errorText: { classPropertyName: "errorText", publicName: "errorText", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:keydown.escape": "handleEscape($event)" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SColorPickerComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-color-picker\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    type=\"text\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    <button\n      #swatchOrigin=\"cdkOverlayOrigin\"\n      cdkOverlayOrigin\n      type=\"button\"\n      mat-icon-button\n      aria-label=\"\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0446\u0432\u0435\u0442\"\n      [disabled]=\"isDisabled() || isReadonly()\"\n      (click)=\"toggleOverlay()\"\n    >\n      <span\n        class=\"s-color-picker__swatch\"\n        [style.background-color]=\"swatchColor()\"\n        [style.border-color]=\"swatchBorderColor()\"\n      ></span>\n    </button>\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    [cdkConnectedOverlayOrigin]=\"swatchOrigin\"\n    [cdkConnectedOverlayOpen]=\"overlayOpen()\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    [cdkConnectedOverlayOffsetY]=\"8\"\n    (backdropClick)=\"closeOverlay()\"\n    (detach)=\"closeOverlay()\"\n  >\n    <div\n      class=\"s-color-picker-overlay\"\n      tabindex=\"0\"\n      aria-label=\"Color picker overlay\"\n      (click)=\"$event.stopPropagation()\"\n      (keydown)=\"$event.stopPropagation()\"\n      (keyup)=\"$event.stopPropagation()\"\n    >\n      <div\n        #palette\n        class=\"s-color-picker-overlay__palette\"\n        tabindex=\"0\"\n        role=\"slider\"\n        aria-label=\"\u041F\u0430\u043B\u0438\u0442\u0440\u0430 \u0446\u0432\u0435\u0442\u0430\"\n        [attr.aria-valuetext]=\"currentValue() || '\u0446\u0432\u0435\u0442 \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D'\"\n        [attr.aria-valuenow]=\"currentValue()\"\n        [style.background]=\"paletteBackground()\"\n        (pointerdown)=\"beginPaletteDrag($event, palette)\"\n        (keydown)=\"handlePaletteKeydown($event)\"\n      >\n        <span\n          class=\"s-color-picker-overlay__marker\"\n          [style.left]=\"markerStyle().left\"\n          [style.top]=\"markerStyle().top\"\n        ></span>\n      </div>\n\n      <input\n        class=\"s-color-picker-overlay__slider\"\n        type=\"range\"\n        min=\"0\"\n        max=\"360\"\n        step=\"1\"\n        [value]=\"hue()\"\n        (input)=\"handleHueInput($event)\"\n      />\n\n      @if (eyedropperSupported()) {\n        <button\n          class=\"s-color-picker-overlay__eyedropper\"\n          type=\"button\"\n          mat-stroked-button\n          [disabled]=\"isDisabled() || isReadonly() || isPickingScreen()\"\n          (click)=\"pickFromScreen()\"\n        >\n          <mat-icon>{{ copiedFeedback() ? 'check' : 'colorize' }}</mat-icon>\n          {{ copiedFeedback() ? 'HEX \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D' : '\u041F\u0438\u043F\u0435\u0442\u043A\u0430' }}\n        </button>\n      }\n    </div>\n  </ng-template>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (showStandaloneError()) {\n    <mat-error>{{ errorMessages().pattern ?? errorText() }}</mat-error>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-color-picker{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}.s-color-picker__swatch{display:inline-block;width:24px;height:24px;border:1px solid;border-radius:50%}.s-color-picker-overlay{display:grid;width:232px;padding:12px;border:1px solid #dbe5ee;border-radius:12px;background:#fff;box-shadow:0 10px 30px #0f172a33;gap:10px}.s-color-picker-overlay__palette{position:relative;overflow:hidden;width:200px;height:200px;cursor:crosshair;border:1px solid rgba(15,23,42,.18);border-radius:8px}.s-color-picker-overlay__palette:focus-visible{outline:2px solid #2563eb;outline-offset:2px}.s-color-picker-overlay__marker{position:absolute;width:12px;height:12px;transform:translate(-50%,-50%);pointer-events:none;border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 1px #0f172a99}.s-color-picker-overlay__slider{width:100%;height:10px;margin:0;border:1px solid rgba(15,23,42,.16);border-radius:999px;background:linear-gradient(to right,red,#ff0 17%,#0f0 33%,#0ff,#00f 67%,#f0f 83%,red);appearance:none}.s-color-picker-overlay__slider::-webkit-slider-thumb{width:14px;height:14px;cursor:pointer;border:2px solid #fff;border-radius:50%;background:#111827;box-shadow:0 0 0 1px #0f172a80;appearance:none}.s-color-picker-overlay__slider::-moz-range-thumb{width:14px;height:14px;cursor:pointer;border:2px solid #fff;border-radius:50%;background:#111827;box-shadow:0 0 0 1px #0f172a80}.s-color-picker-overlay__eyedropper{justify-content:center;width:100%;min-height:36px}.s-color-picker-overlay__eyedropper .mat-icon{margin-right:6px}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "directive", type: CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation", "cdkConnectedOverlayUsePopover", "cdkConnectedOverlayMatchWidth", "cdkConnectedOverlay"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SColorPickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-color-picker', imports: [MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule, CdkOverlayOrigin, CdkConnectedOverlay], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SColorPickerComponent),
                            multi: true,
                        },
                    ], host: {
                        '(document:keydown.escape)': 'handleEscape($event)',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-color-picker\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    type=\"text\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    <button\n      #swatchOrigin=\"cdkOverlayOrigin\"\n      cdkOverlayOrigin\n      type=\"button\"\n      mat-icon-button\n      aria-label=\"\u0422\u0435\u043A\u0443\u0449\u0438\u0439 \u0446\u0432\u0435\u0442\"\n      [disabled]=\"isDisabled() || isReadonly()\"\n      (click)=\"toggleOverlay()\"\n    >\n      <span\n        class=\"s-color-picker__swatch\"\n        [style.background-color]=\"swatchColor()\"\n        [style.border-color]=\"swatchBorderColor()\"\n      ></span>\n    </button>\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  <ng-template\n    cdkConnectedOverlay\n    cdkConnectedOverlayBackdropClass=\"cdk-overlay-transparent-backdrop\"\n    [cdkConnectedOverlayOrigin]=\"swatchOrigin\"\n    [cdkConnectedOverlayOpen]=\"overlayOpen()\"\n    [cdkConnectedOverlayHasBackdrop]=\"true\"\n    [cdkConnectedOverlayOffsetY]=\"8\"\n    (backdropClick)=\"closeOverlay()\"\n    (detach)=\"closeOverlay()\"\n  >\n    <div\n      class=\"s-color-picker-overlay\"\n      tabindex=\"0\"\n      aria-label=\"Color picker overlay\"\n      (click)=\"$event.stopPropagation()\"\n      (keydown)=\"$event.stopPropagation()\"\n      (keyup)=\"$event.stopPropagation()\"\n    >\n      <div\n        #palette\n        class=\"s-color-picker-overlay__palette\"\n        tabindex=\"0\"\n        role=\"slider\"\n        aria-label=\"\u041F\u0430\u043B\u0438\u0442\u0440\u0430 \u0446\u0432\u0435\u0442\u0430\"\n        [attr.aria-valuetext]=\"currentValue() || '\u0446\u0432\u0435\u0442 \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D'\"\n        [attr.aria-valuenow]=\"currentValue()\"\n        [style.background]=\"paletteBackground()\"\n        (pointerdown)=\"beginPaletteDrag($event, palette)\"\n        (keydown)=\"handlePaletteKeydown($event)\"\n      >\n        <span\n          class=\"s-color-picker-overlay__marker\"\n          [style.left]=\"markerStyle().left\"\n          [style.top]=\"markerStyle().top\"\n        ></span>\n      </div>\n\n      <input\n        class=\"s-color-picker-overlay__slider\"\n        type=\"range\"\n        min=\"0\"\n        max=\"360\"\n        step=\"1\"\n        [value]=\"hue()\"\n        (input)=\"handleHueInput($event)\"\n      />\n\n      @if (eyedropperSupported()) {\n        <button\n          class=\"s-color-picker-overlay__eyedropper\"\n          type=\"button\"\n          mat-stroked-button\n          [disabled]=\"isDisabled() || isReadonly() || isPickingScreen()\"\n          (click)=\"pickFromScreen()\"\n        >\n          <mat-icon>{{ copiedFeedback() ? 'check' : 'colorize' }}</mat-icon>\n          {{ copiedFeedback() ? 'HEX \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D' : '\u041F\u0438\u043F\u0435\u0442\u043A\u0430' }}\n        </button>\n      }\n    </div>\n  </ng-template>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (showStandaloneError()) {\n    <mat-error>{{ errorMessages().pattern ?? errorText() }}</mat-error>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-color-picker{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}.s-color-picker__swatch{display:inline-block;width:24px;height:24px;border:1px solid;border-radius:50%}.s-color-picker-overlay{display:grid;width:232px;padding:12px;border:1px solid #dbe5ee;border-radius:12px;background:#fff;box-shadow:0 10px 30px #0f172a33;gap:10px}.s-color-picker-overlay__palette{position:relative;overflow:hidden;width:200px;height:200px;cursor:crosshair;border:1px solid rgba(15,23,42,.18);border-radius:8px}.s-color-picker-overlay__palette:focus-visible{outline:2px solid #2563eb;outline-offset:2px}.s-color-picker-overlay__marker{position:absolute;width:12px;height:12px;transform:translate(-50%,-50%);pointer-events:none;border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 1px #0f172a99}.s-color-picker-overlay__slider{width:100%;height:10px;margin:0;border:1px solid rgba(15,23,42,.16);border-radius:999px;background:linear-gradient(to right,red,#ff0 17%,#0f0 33%,#0ff,#00f 67%,#f0f 83%,red);appearance:none}.s-color-picker-overlay__slider::-webkit-slider-thumb{width:14px;height:14px;cursor:pointer;border:2px solid #fff;border-radius:50%;background:#111827;box-shadow:0 0 0 1px #0f172a80;appearance:none}.s-color-picker-overlay__slider::-moz-range-thumb{width:14px;height:14px;cursor:pointer;border:2px solid #fff;border-radius:50%;background:#111827;box-shadow:0 0 0 1px #0f172a80}.s-color-picker-overlay__eyedropper{justify-content:center;width:100%;min-height:36px}.s-color-picker-overlay__eyedropper .mat-icon{margin-right:6px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], emptySwatchBorder: [{ type: i0.Input, args: [{ isSignal: true, alias: "emptySwatchBorder", required: false }] }], errorText: [{ type: i0.Input, args: [{ isSignal: true, alias: "errorText", required: false }] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], inputElement: [{ type: i0.ViewChild, args: ['inputElement', { isSignal: true }] }] } });
function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
function hexToRgb(hex) {
    const value = normalizeHexInput(hex);
    if (!HEX_PATTERN.test(value)) {
        return null;
    }
    const raw = value.slice(1);
    const expanded = raw.length === 3
        ? raw
            .split('')
            .map((item) => item + item)
            .join('')
        : raw;
    const r = Number.parseInt(expanded.slice(0, 2), 16);
    const g = Number.parseInt(expanded.slice(2, 4), 16);
    const b = Number.parseInt(expanded.slice(4, 6), 16);
    return { r, g, b };
}
function rgbToHsv(r, g, b) {
    const red = r / 255;
    const green = g / 255;
    const blue = b / 255;
    const max = Math.max(red, green, blue);
    const min = Math.min(red, green, blue);
    const delta = max - min;
    let h = 0;
    const s = max === 0 ? 0 : delta / max;
    const v = max;
    if (delta !== 0) {
        if (max === red) {
            h = 60 * (((green - blue) / delta) % 6);
        }
        else if (max === green) {
            h = 60 * ((blue - red) / delta + 2);
        }
        else {
            h = 60 * ((red - green) / delta + 4);
        }
    }
    if (h < 0) {
        h += 360;
    }
    return { h, s, v };
}
function hsvToHex(h, s, v) {
    const normalizedH = ((h % 360) + 360) % 360;
    const normalizedS = clamp(s, 0, 1);
    const normalizedV = clamp(v, 0, 1);
    const c = normalizedV * normalizedS;
    const x = c * (1 - Math.abs(((normalizedH / 60) % 2) - 1));
    const m = normalizedV - c;
    let rPrime = 0;
    let gPrime = 0;
    let bPrime = 0;
    if (normalizedH < 60) {
        rPrime = c;
        gPrime = x;
    }
    else if (normalizedH < 120) {
        rPrime = x;
        gPrime = c;
    }
    else if (normalizedH < 180) {
        gPrime = c;
        bPrime = x;
    }
    else if (normalizedH < 240) {
        gPrime = x;
        bPrime = c;
    }
    else if (normalizedH < 300) {
        rPrime = x;
        bPrime = c;
    }
    else {
        rPrime = c;
        bPrime = x;
    }
    const r = Math.round((rPrime + m) * 255);
    const g = Math.round((gPrime + m) * 255);
    const b = Math.round((bPrime + m) * 255);
    return `#${[r, g, b].map((channel) => channel.toString(16).padStart(2, '0')).join('')}`;
}
function getEyeDropperConstructor() {
    const maybeCtor = globalThis.EyeDropper;
    return typeof maybeCtor === 'function' ? maybeCtor : null;
}

function toDateValue(value) {
    if (value == null) {
        return null;
    }
    if (value instanceof Date) {
        return Number.isNaN(value.getTime()) ? null : value;
    }
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
}
class SDatepickerComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = input(null, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toDateValue });
    valueChange = output();
    internalValue = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue() !== null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    inputElement = viewChild('inputElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    writeValue(value) {
        this.internalValue.set(toDateValue(value));
    }
    handleDateEvent(event) {
        const nextValue = event.value ?? null;
        this.internalValue.set(nextValue);
        this.onChange(nextValue);
        this.valueChange.emit(nextValue);
    }
    handleBlur() {
        this.onTouched();
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalValue.set(null);
        this.onChange(null);
        this.valueChange.emit(null);
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SDatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SDatepickerComponent, isStandalone: true, selector: "s-datepicker", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SDatepickerComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-datepicker\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [matDatepicker]=\"picker\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (dateInput)=\"handleDateEvent($event)\"\n    (dateChange)=\"handleDateEvent($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n\n    <mat-datepicker-toggle [for]=\"picker\" [disabled]=\"isDisabled() || isReadonly()\" />\n  </div>\n  <mat-datepicker #picker [disabled]=\"isDisabled() || isReadonly()\" />\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-datepicker{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i4$2.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i4$2.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i4$2.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SDatepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-datepicker', imports: [
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatDatepickerModule,
                        MatNativeDateModule,
                        MatButtonModule,
                    ], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SDatepickerComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-datepicker\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [matDatepicker]=\"picker\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (dateInput)=\"handleDateEvent($event)\"\n    (dateChange)=\"handleDateEvent($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n\n    <mat-datepicker-toggle [for]=\"picker\" [disabled]=\"isDisabled() || isReadonly()\" />\n  </div>\n  <mat-datepicker #picker [disabled]=\"isDisabled() || isReadonly()\" />\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-datepicker{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], inputElement: [{ type: i0.ViewChild, args: ['inputElement', { isSignal: true }] }] } });

var SConfirmAlignButtonsEnum;
(function (SConfirmAlignButtonsEnum) {
    SConfirmAlignButtonsEnum["Horizontal"] = "horizontal";
    SConfirmAlignButtonsEnum["Vertical"] = "vertical";
})(SConfirmAlignButtonsEnum || (SConfirmAlignButtonsEnum = {}));

class ConfirmDialogComponent {
    message = input('Сообщение', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    alignButtons = input(SConfirmAlignButtonsEnum.Horizontal, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "alignButtons" }] : /* istanbul ignore next */ []));
    buttons = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "buttons" }] : /* istanbul ignore next */ []));
    dialogRef;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: ConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: ConfirmDialogComponent, isStandalone: true, selector: "ng-component", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null }, alignButtons: { classPropertyName: "alignButtons", publicName: "alignButtons", isSignal: true, isRequired: false, transformFunction: null }, buttons: { classPropertyName: "buttons", publicName: "buttons", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="s-modal-container">
      <div class="s-message" [innerHTML]="message()"></div>
      <div
        class="s-modal-footer-buttons"
        [class.s-without-border]="!message()"
        [class.s-vertical-buttons]="alignButtons() === 'vertical'"
      >
        @for (button of buttons(); track button) {
          <button matButton="elevated" [color]="button.color" (click)="dialogRef.close(button.value)">
            {{ button.title }}
          </button>
        }
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: ConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{
                    imports: [MatButtonModule],
                    template: `
    <div class="s-modal-container">
      <div class="s-message" [innerHTML]="message()"></div>
      <div
        class="s-modal-footer-buttons"
        [class.s-without-border]="!message()"
        [class.s-vertical-buttons]="alignButtons() === 'vertical'"
      >
        @for (button of buttons(); track button) {
          <button matButton="elevated" [color]="button.color" (click)="dialogRef.close(button.value)">
            {{ button.title }}
          </button>
        }
      </div>
    </div>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }], alignButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "alignButtons", required: false }] }], buttons: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttons", required: false }] }] } });

var SToastTypeEnum;
(function (SToastTypeEnum) {
    SToastTypeEnum["Warning"] = "warning";
    SToastTypeEnum["Info"] = "info";
    SToastTypeEnum["Success"] = "success";
    SToastTypeEnum["Error"] = "error";
})(SToastTypeEnum || (SToastTypeEnum = {}));

class SToastListComponent {
    toastList = signal([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toastList" }] : /* istanbul ignore next */ []));
    fadeInDurationMs = 300;
    fadeOutDurationMs = 2500;
    nextToastId = 0;
    showToast(data) {
        const toast = {
            id: this.nextToastId,
            isClosing: signal(false),
            className: data.type ?? SToastTypeEnum.Info,
            iconName: this.getIcon(data),
            title: data.title,
            message: data.message ?? '',
        };
        this.nextToastId += 1;
        if (typeof data.clickCallback === 'function') {
            toast.clickCallback = data.clickCallback;
        }
        this.toastList.update((list) => [...list, toast]);
        if (data.duration && data.duration > 0) {
            toast.timeoutId = setTimeout(() => {
                this.beginClose(toast.id);
            }, data.duration);
        }
    }
    onFadeOutFinished(event, id) {
        if (event.propertyName !== 'opacity') {
            return;
        }
        const toast = this.toastList().find((item) => item.id === id);
        if (!toast || !toast.isClosing()) {
            return;
        }
        this.close(id);
    }
    close(id) {
        this.toastList.update((list) => {
            const index = list.findIndex((item) => item.id === id);
            if (index === -1) {
                return list;
            }
            if (list[index].timeoutId) {
                clearTimeout(list[index].timeoutId);
            }
            if (list[index].closeTimeoutId) {
                clearTimeout(list[index].closeTimeoutId);
            }
            return [...list.slice(0, index), ...list.slice(index + 1)];
        });
    }
    toastClick(id) {
        const toast = this.toastList().find((item) => item.id === id);
        if (!toast?.clickCallback) {
            return;
        }
        const { clickCallback } = toast;
        if (typeof clickCallback === 'function') {
            clickCallback(() => this.close(id));
        }
    }
    hideAll() {
        this.toastList().forEach((item) => {
            if (item.timeoutId) {
                clearTimeout(item.timeoutId);
            }
            if (item.closeTimeoutId) {
                clearTimeout(item.closeTimeoutId);
            }
        });
        this.toastList.set([]);
    }
    beginClose(id) {
        const toast = this.toastList().find((item) => item.id === id);
        if (!toast || toast.isClosing()) {
            return;
        }
        toast.isClosing.set(true);
        toast.closeTimeoutId = setTimeout(() => {
            this.close(id);
        }, this.fadeOutDurationMs);
    }
    getIcon(data) {
        if (typeof data.iconName === 'undefined') {
            switch (data.type) {
                case SToastTypeEnum.Warning:
                    return 'error_outline';
                case SToastTypeEnum.Info:
                    return 'help_outline';
                case SToastTypeEnum.Success:
                    return 'check_circle_outline';
                case SToastTypeEnum.Error:
                    return 'report_problem';
                default:
                    return 'help_outline';
            }
        }
        return data.iconName ?? '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SToastListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SToastListComponent, isStandalone: true, selector: "s-toast-list", ngImport: i0, template: "@for (toast of toastList(); track toast.id) {\n  <div\n    class=\"s-toast\"\n    [class.is-closing]=\"toast.isClosing()\"\n    [class]=\"toast.className\"\n    [style.--s-toast-fade-in-duration]=\"fadeInDurationMs + 'ms'\"\n    [style.--s-toast-fade-out-duration]=\"fadeOutDurationMs + 'ms'\"\n    (transitionend)=\"onFadeOutFinished($event, toast.id)\"\n  >\n    @if (toast.iconName) {\n      <div class=\"icon\">\n        <mat-icon [inline]=\"true\">{{ toast.iconName }}</mat-icon>\n      </div>\n    }\n    <div\n      class=\"body\"\n      [attr.tabindex]=\"toast.clickCallback ? '0' : null\"\n      [attr.role]=\"toast.clickCallback ? 'button' : null\"\n      (click)=\"toastClick(toast.id)\"\n      (keydown.enter)=\"toastClick(toast.id)\"\n    >\n      @if (toast.title) {\n        <div class=\"title\">{{ toast.title }}</div>\n      }\n      <div class=\"message\" [class.cursor-pointer]=\"toast.clickCallback\">\n        <div class=\"message-text\" [innerHTML]=\"toast.message\"></div>\n      </div>\n    </div>\n    <div class=\"close\" role=\"button\" tabindex=\"0\" (click)=\"close(toast.id)\" (keydown.enter)=\"close(toast.id)\">\n      <mat-icon [inline]=\"true\">highlight_off</mat-icon>\n    </div>\n  </div>\n}\n", styles: [":host{position:fixed;z-index:1100;top:0;left:0;display:flex;align-items:flex-end;flex-direction:column;justify-content:flex-end;width:100%;height:100%;pointer-events:none}@keyframes s-toast-fade-in{0%{transform:translateY(6px);opacity:0}to{transform:translateY(0);opacity:.9}}.s-toast{position:relative;display:flex;box-sizing:border-box;min-width:344px;max-width:33vw;margin:5px 10px;padding:10px 0;transition:opacity var(--s-toast-fade-out-duration, 2.5s) ease;transform:translateY(0);animation:s-toast-fade-in var(--s-toast-fade-in-duration, .3s) ease;pointer-events:all;opacity:.9;color:#fff;border:1px solid #c6c6c6;border-radius:4px;background-color:#0275d8;box-shadow:0 3px 5px -1px #0003,0 6px 10px #00000024,0 1px 18px #0000001f}.s-toast.error{opacity:.9;color:#fff;border:1px solid #801811;background-color:#da291c}.s-toast.success{opacity:.9;color:#fff;border:1px solid #00943b;background-color:#00c851}.s-toast.warning{opacity:.9;color:#fff;border:1px solid #ff5500;background-color:#f73}.s-toast.is-closing,.s-toast.error.is-closing,.s-toast.success.is-closing,.s-toast.warning.is-closing{opacity:0}.s-toast .icon{padding:10px 0 10px 10px;font-size:42px;line-height:32px}.s-toast .close{position:absolute;top:3px;right:3px;cursor:pointer;font-size:22px}.s-toast .body{display:flex;flex:auto;flex-direction:column;padding-right:35px;padding-left:10px}.s-toast .body .title{margin-bottom:5px;cursor:default;border-bottom:1px solid #fff;font-weight:700}.s-toast .body .message{display:flex;flex:auto;flex-direction:column;justify-content:center;cursor:default}.s-toast .body .message .message-text{white-space:pre-line}.s-toast .body .message.cursor-pointer{cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SToastListComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-toast-list', imports: [MatIconModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "@for (toast of toastList(); track toast.id) {\n  <div\n    class=\"s-toast\"\n    [class.is-closing]=\"toast.isClosing()\"\n    [class]=\"toast.className\"\n    [style.--s-toast-fade-in-duration]=\"fadeInDurationMs + 'ms'\"\n    [style.--s-toast-fade-out-duration]=\"fadeOutDurationMs + 'ms'\"\n    (transitionend)=\"onFadeOutFinished($event, toast.id)\"\n  >\n    @if (toast.iconName) {\n      <div class=\"icon\">\n        <mat-icon [inline]=\"true\">{{ toast.iconName }}</mat-icon>\n      </div>\n    }\n    <div\n      class=\"body\"\n      [attr.tabindex]=\"toast.clickCallback ? '0' : null\"\n      [attr.role]=\"toast.clickCallback ? 'button' : null\"\n      (click)=\"toastClick(toast.id)\"\n      (keydown.enter)=\"toastClick(toast.id)\"\n    >\n      @if (toast.title) {\n        <div class=\"title\">{{ toast.title }}</div>\n      }\n      <div class=\"message\" [class.cursor-pointer]=\"toast.clickCallback\">\n        <div class=\"message-text\" [innerHTML]=\"toast.message\"></div>\n      </div>\n    </div>\n    <div class=\"close\" role=\"button\" tabindex=\"0\" (click)=\"close(toast.id)\" (keydown.enter)=\"close(toast.id)\">\n      <mat-icon [inline]=\"true\">highlight_off</mat-icon>\n    </div>\n  </div>\n}\n", styles: [":host{position:fixed;z-index:1100;top:0;left:0;display:flex;align-items:flex-end;flex-direction:column;justify-content:flex-end;width:100%;height:100%;pointer-events:none}@keyframes s-toast-fade-in{0%{transform:translateY(6px);opacity:0}to{transform:translateY(0);opacity:.9}}.s-toast{position:relative;display:flex;box-sizing:border-box;min-width:344px;max-width:33vw;margin:5px 10px;padding:10px 0;transition:opacity var(--s-toast-fade-out-duration, 2.5s) ease;transform:translateY(0);animation:s-toast-fade-in var(--s-toast-fade-in-duration, .3s) ease;pointer-events:all;opacity:.9;color:#fff;border:1px solid #c6c6c6;border-radius:4px;background-color:#0275d8;box-shadow:0 3px 5px -1px #0003,0 6px 10px #00000024,0 1px 18px #0000001f}.s-toast.error{opacity:.9;color:#fff;border:1px solid #801811;background-color:#da291c}.s-toast.success{opacity:.9;color:#fff;border:1px solid #00943b;background-color:#00c851}.s-toast.warning{opacity:.9;color:#fff;border:1px solid #ff5500;background-color:#f73}.s-toast.is-closing,.s-toast.error.is-closing,.s-toast.success.is-closing,.s-toast.warning.is-closing{opacity:0}.s-toast .icon{padding:10px 0 10px 10px;font-size:42px;line-height:32px}.s-toast .close{position:absolute;top:3px;right:3px;cursor:pointer;font-size:22px}.s-toast .body{display:flex;flex:auto;flex-direction:column;padding-right:35px;padding-left:10px}.s-toast .body .title{margin-bottom:5px;cursor:default;border-bottom:1px solid #fff;font-weight:700}.s-toast .body .message{display:flex;flex:auto;flex-direction:column;justify-content:center;cursor:default}.s-toast .body .message .message-text{white-space:pre-line}.s-toast .body .message.cursor-pointer{cursor:pointer}\n"] }]
        }] });

class SToastService {
    document = inject(DOCUMENT);
    injector = inject(Injector);
    applicationRef = inject(ApplicationRef);
    platformId = inject(PLATFORM_ID);
    destroyRef = inject(DestroyRef);
    toastList = null;
    bodyPortalOutlet = null;
    constructor() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        const bodyPortalOutlet = new DomPortalOutlet(this.document.body, this.applicationRef, this.injector);
        const componentPortal = new ComponentPortal(SToastListComponent);
        const componentRef = bodyPortalOutlet.attach(componentPortal);
        this.bodyPortalOutlet = bodyPortalOutlet;
        this.toastList = componentRef.instance;
        this.destroyRef.onDestroy(() => {
            if (this.bodyPortalOutlet?.hasAttached()) {
                this.bodyPortalOutlet.detach();
            }
            this.bodyPortalOutlet?.dispose();
            this.bodyPortalOutlet = null;
            this.toastList = null;
        });
    }
    showToastWarning(message, title, duration = 3000) {
        this.showToast({
            message,
            type: SToastTypeEnum.Warning,
            title,
            duration,
        });
    }
    showToastInfo(message, title, duration = 3000) {
        this.showToast({
            message,
            type: SToastTypeEnum.Info,
            title,
            duration,
        });
    }
    showToastSuccess(message, title, duration = 3000) {
        this.showToast({
            message,
            type: SToastTypeEnum.Success,
            title,
            duration,
        });
    }
    showToastError(message, title, duration) {
        this.showToast({
            message,
            type: SToastTypeEnum.Error,
            title,
            duration,
        });
    }
    showToast(data) {
        this.toastList?.showToast(data);
    }
    hideToast() {
        this.toastList?.hideAll();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class MessageDialogComponent {
    message = input('Сообщение', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    dialogRef;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: MessageDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.0", type: MessageDialogComponent, isStandalone: true, selector: "ng-component", inputs: { message: { classPropertyName: "message", publicName: "message", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <div class="s-modal-container">
      <div class="s-message" [innerHTML]="message()"></div>
      <div class="s-modal-footer-buttons">
        <button matButton="elevated" color="accent" (click)="dialogRef.close()">Закрыть</button>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: MessageDialogComponent, decorators: [{
            type: Component,
            args: [{
                    imports: [MatButtonModule],
                    template: `
    <div class="s-modal-container">
      <div class="s-message" [innerHTML]="message()"></div>
      <div class="s-modal-footer-buttons">
        <button matButton="elevated" color="accent" (click)="dialogRef.close()">Закрыть</button>
      </div>
    </div>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { message: [{ type: i0.Input, args: [{ isSignal: true, alias: "message", required: false }] }] } });

class ModalDialogComponent {
    titleWindow = '';
    modalBodyRef;
    componentInstance = null;
    data = inject(MAT_DIALOG_DATA);
    dialogRef = inject((MatDialogRef));
    constructor() {
        this.titleWindow = this.data?.title ?? '';
    }
    ngAfterViewInit() {
        if (this.modalBodyRef) {
            const modalComponentRef = this.modalBodyRef.createComponent(this.data.childComponent);
            this.componentInstance = modalComponentRef.instance;
            this.componentInstance.dialogRef = this.dialogRef;
            if (this.data.childData) {
                Object.keys(this.data.childData).forEach((key) => {
                    const value = this.data.childData?.[key];
                    modalComponentRef.setInput(key, value);
                });
            }
        }
    }
    onCloseModal() {
        if (this.componentInstance && typeof this.componentInstance.onCloseModal === 'function') {
            this.componentInstance.onCloseModal();
        }
        else {
            this.dialogRef.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: ModalDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.0", type: ModalDialogComponent, isStandalone: true, selector: "ng-component", viewQueries: [{ propertyName: "modalBodyRef", first: true, predicate: ["modalBody"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: `
    <div class="s-modal-window" role="document">
      <div class="s-modal-title">
        <h2 class="s-modal-title-text">{{ titleWindow }}</h2>
        <div
          class="s-modal-window-close"
          role="button"
          aria-label="Закрыть диалог"
          [attr.tabindex]="'0'"
          (keydown.enter)="onCloseModal()"
          (click)="onCloseModal()"
        >
          <mat-icon>highlight_off</mat-icon>
        </div>
      </div>
      <div class="s-modal-body">
        <ng-template #modalBody></ng-template>
      </div>
    </div>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;width:100%;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: ModalDialogComponent, decorators: [{
            type: Component,
            args: [{ imports: [MatIconModule, MatButtonModule], template: `
    <div class="s-modal-window" role="document">
      <div class="s-modal-title">
        <h2 class="s-modal-title-text">{{ titleWindow }}</h2>
        <div
          class="s-modal-window-close"
          role="button"
          aria-label="Закрыть диалог"
          [attr.tabindex]="'0'"
          (keydown.enter)="onCloseModal()"
          (click)="onCloseModal()"
        >
          <mat-icon>highlight_off</mat-icon>
        </div>
      </div>
      <div class="s-modal-body">
        <ng-template #modalBody></ng-template>
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:flex;flex-direction:column;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [], propDecorators: { modalBodyRef: [{
                type: ViewChild,
                args: ['modalBody', { read: ViewContainerRef }]
            }] } });

class WaitDialogComponent {
    message = signal('Подождите, пожалуйста....', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: WaitDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.0", type: WaitDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: `
    <div class="wait-ui-container">
      <div class="wait-ui">
        <svg
          xmlns:svg="http://www.w3.org/2000/svg"
          xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink"
          version="1.0"
          width="211px"
          height="32px"
          viewBox="0 0 158 24"
          xml:space="preserve"
        >
          <rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF" />
          <path
            fill="#0054e6"
            fill-opacity="0.9"
            d="M64 4h10v10H64V4zm20 0h10v10H84V4zm20 0h10v10h-10V4zm20 0h10v10h-10V4zm20 0h10v10h-10V4zM4 4h10v10H4V4zm20 0h10v10H24V4zm20 0h10v10H44V4z"
          />
          <path
            fill="#0054e6"
            fill-opacity="0.6"
            d="M144 14V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10H84zm9-9h-8v8h8V5zm-29 9V4h10v10H64zm9-9h-8v8h8V5zm-29 9V4h10v10H44zm9-9h-8v8h8V5zm-29 9V4h10v10H24zm9-9h-8v8h8V5zM4 14V4h10v10H4zm9-9H5v8h8V5z"
          />
          <g class="wait-ui__track">
            <path fill="#0054e6" fill-opacity="0.15" d="M-58 16V2h14v14h-14zm13-13h-12v12h12V3z" />
            <path fill="#0054e6" fill-opacity="0.39" d="M-40 0h18v18h-18z" />
            <path fill="#0054e6" fill-opacity="0.3" d="M-40 18V0h18v18h-18zm17-17h-16v16h16V1z" />
            <path fill="#0054e6" fill-opacity="0.39" d="M-20 0h18v18h-18z" />
            <path fill="#0054e6" fill-opacity="0.7" d="M-20 18V0h18v18h-18zM-3 1h-16v16h16V1z" />
          </g>
        </svg>
        <div>{{ message() }}</div>
      </div>
    </div>
  `, isInline: true, styles: [":host{display:block;box-sizing:border-box;width:100%}.wait-ui-container{position:fixed;left:0;top:0;width:100%;height:100%;background-color:#00000080;z-index:1050;display:flex;align-items:center}.wait-ui{width:100%;max-width:330px;margin:auto;text-align:center;background-color:#fff;box-shadow:0 0 8px #000000bf;border-radius:5px;padding:20px}.wait-ui__track{animation:s-wait-ui-shift 1.8s steps(9,end) infinite}@keyframes s-wait-ui-shift{0%{transform:translate(20px)}to{transform:translate(200px)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: WaitDialogComponent, decorators: [{
            type: Component,
            args: [{ template: `
    <div class="wait-ui-container">
      <div class="wait-ui">
        <svg
          xmlns:svg="http://www.w3.org/2000/svg"
          xmlns="http://www.w3.org/2000/svg"
          xmlns:xlink="http://www.w3.org/1999/xlink"
          version="1.0"
          width="211px"
          height="32px"
          viewBox="0 0 158 24"
          xml:space="preserve"
        >
          <rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF" />
          <path
            fill="#0054e6"
            fill-opacity="0.9"
            d="M64 4h10v10H64V4zm20 0h10v10H84V4zm20 0h10v10h-10V4zm20 0h10v10h-10V4zm20 0h10v10h-10V4zM4 4h10v10H4V4zm20 0h10v10H24V4zm20 0h10v10H44V4z"
          />
          <path
            fill="#0054e6"
            fill-opacity="0.6"
            d="M144 14V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10h-10zm9-9h-8v8h8V5zm-29 9V4h10v10H84zm9-9h-8v8h8V5zm-29 9V4h10v10H64zm9-9h-8v8h8V5zm-29 9V4h10v10H44zm9-9h-8v8h8V5zm-29 9V4h10v10H24zm9-9h-8v8h8V5zM4 14V4h10v10H4zm9-9H5v8h8V5z"
          />
          <g class="wait-ui__track">
            <path fill="#0054e6" fill-opacity="0.15" d="M-58 16V2h14v14h-14zm13-13h-12v12h12V3z" />
            <path fill="#0054e6" fill-opacity="0.39" d="M-40 0h18v18h-18z" />
            <path fill="#0054e6" fill-opacity="0.3" d="M-40 18V0h18v18h-18zm17-17h-16v16h16V1z" />
            <path fill="#0054e6" fill-opacity="0.39" d="M-20 0h18v18h-18z" />
            <path fill="#0054e6" fill-opacity="0.7" d="M-20 18V0h18v18h-18zM-3 1h-16v16h16V1z" />
          </g>
        </svg>
        <div>{{ message() }}</div>
      </div>
    </div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;box-sizing:border-box;width:100%}.wait-ui-container{position:fixed;left:0;top:0;width:100%;height:100%;background-color:#00000080;z-index:1050;display:flex;align-items:center}.wait-ui{width:100%;max-width:330px;margin:auto;text-align:center;background-color:#fff;box-shadow:0 0 8px #000000bf;border-radius:5px;padding:20px}.wait-ui__track{animation:s-wait-ui-shift 1.8s steps(9,end) infinite}@keyframes s-wait-ui-shift{0%{transform:translate(20px)}to{transform:translate(200px)}}\n"] }]
        }] });

class SDialogService {
    bodyPortalOutlet = null;
    waitComponentPortal = new ComponentPortal(WaitDialogComponent);
    waitComponentRef = null;
    document = inject(DOCUMENT);
    injector = inject(Injector);
    applicationRef = inject(ApplicationRef);
    platformId = inject(PLATFORM_ID);
    destroyRef = inject(DestroyRef);
    dialog = inject(MatDialog);
    toastService = inject(SToastService);
    constructor() {
        if (!isPlatformBrowser(this.platformId)) {
            return;
        }
        this.bodyPortalOutlet = new DomPortalOutlet(this.document.body, this.applicationRef, this.injector);
        this.destroyRef.onDestroy(() => {
            this.hideWait();
            this.bodyPortalOutlet?.dispose();
            this.bodyPortalOutlet = null;
        });
    }
    showWait(message = null) {
        if (!this.bodyPortalOutlet) {
            return;
        }
        if (!this.waitComponentRef) {
            this.waitComponentRef = this.bodyPortalOutlet.attach(this.waitComponentPortal);
        }
        if (message !== null) {
            this.waitComponentRef.instance.message.set(message);
        }
    }
    hideWait() {
        if (this.bodyPortalOutlet?.hasAttached()) {
            this.bodyPortalOutlet.detach();
        }
        this.waitComponentRef = null;
    }
    showToast(message, title, typeToast, duration) {
        if (typeof message === 'string') {
            this.toastService.showToast({
                message,
                title,
                type: typeToast ?? SToastTypeEnum.Info,
                duration,
            });
        }
        else {
            this.toastService.showToast(message);
        }
    }
    showToastError(message, title, duration) {
        this.showToast(message, title, SToastTypeEnum.Error, duration);
    }
    showToastWarning(message, title, duration = 3000) {
        this.showToast(message, title, SToastTypeEnum.Warning, duration);
    }
    showToastSuccess(message, title, duration = 3000) {
        this.showToast(message, title, SToastTypeEnum.Success, duration);
    }
    showToastInfo(message, title, duration = 3000) {
        this.showToast(message, title, SToastTypeEnum.Info, duration);
    }
    hideToast() {
        this.toastService.hideToast();
    }
    showModal(title, childComponent, childData = null, disableClose = false, autoFocus = true, panelClass = null) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = disableClose;
        dialogConfig.autoFocus = autoFocus;
        dialogConfig.restoreFocus = true;
        dialogConfig.ariaModal = true;
        dialogConfig.maxHeight = '95vh';
        dialogConfig.maxWidth = '95vw';
        dialogConfig.panelClass = panelClass ?? 's-modal-dialog-container';
        dialogConfig.data = {
            title,
            childComponent,
            childData,
        };
        const dialogRef = this.dialog.open(ModalDialogComponent, dialogConfig);
        return dialogRef.afterClosed();
    }
    showConfirm(message, title = 'Подтверждение', okButtonCaption = 'Да', cancelButtonCaption = 'Нет') {
        return this.showCustomConfirm(message, title, [
            {
                title: okButtonCaption,
                color: 'primary',
                value: true,
            },
            {
                title: cancelButtonCaption,
                color: 'accent',
                value: false,
            },
        ], SConfirmAlignButtonsEnum.Horizontal).pipe(map((value) => value === true));
    }
    showCustomConfirm(message, title = 'Подтверждение', buttons = [], alignButtons = SConfirmAlignButtonsEnum.Horizontal) {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose = true;
        dialogConfig.autoFocus = true;
        dialogConfig.restoreFocus = true;
        dialogConfig.ariaModal = true;
        dialogConfig.panelClass = 's-modal-dialog-container';
        dialogConfig.data = {
            title,
            childComponent: ConfirmDialogComponent,
            childData: {
                message,
                buttons,
                alignButtons,
            },
        };
        const dialogRef = this.dialog.open(ModalDialogComponent, dialogConfig);
        return dialogRef.afterClosed();
    }
    showMessage(message, title = 'Сообщение') {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.autoFocus = false;
        dialogConfig.restoreFocus = true;
        dialogConfig.ariaModal = true;
        dialogConfig.panelClass = 's-modal-dialog-container';
        dialogConfig.data = {
            title,
            childComponent: MessageDialogComponent,
            childData: {
                message,
            },
        };
        const dialogRef = this.dialog.open(ModalDialogComponent, dialogConfig);
        return dialogRef.afterClosed();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SDialogService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/* eslint-disable no-useless-escape */
/** Interval between each step tick while arrow key is held, ms */
const HOLD_TICK_MS$1 = 80;
/** Step multiplier grows by +1 every this many ms while key is held */
const ACCELERATION_INTERVAL_MS$1 = 500;
/** Maximum step multiplier */
const MAX_MULTIPLIER$1 = 20;
/**
 * Directive that restricts `s-input` to numeric-only input.
 *
 * Features:
 * - Blocks all non-numeric keyboard input (including paste)
 * - ArrowUp / ArrowDown increment / decrement by `step`
 * - Holding the arrow key accelerates: multiplier grows proportionally every 500 ms
 * - Optional decimal support with configurable decimal-places limit
 * - Optional min / max bounds
 *   - Arrow keys and paste clamp the value to [min, max]
 *   - Values set programmatically that fall outside the range trigger a validation error
 *
 * Usage:
 * ```html
 * <s-input label="Qty" [formControl]="ctrl" sNumeric [sNumericMin]="0" [sNumericMax]="999" />
 * ```
 */
class SNumericDirective {
    /** Base increment / decrement step for arrow keys. Default: 1. */
    sNumericStep = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sNumericStep" }] : /* istanbul ignore next */ []));
    /** Allow decimal (fractional) numbers. Default: false. */
    sNumericDecimal = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sNumericDecimal" }] : /* istanbul ignore next */ []));
    /**
     * Maximum number of digits after the decimal point.
     * Only relevant when `sNumericDecimal` is true. Default: 2.
     */
    sNumericDecimalPlaces = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sNumericDecimalPlaces" }] : /* istanbul ignore next */ []));
    /** Minimum allowed value. Omit to disable lower bound. */
    sNumericMin = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sNumericMin" }] : /* istanbul ignore next */ []));
    /** Maximum allowed value. Omit to disable upper bound. */
    sNumericMax = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "sNumericMax" }] : /* istanbul ignore next */ []));
    el = inject((ElementRef));
    injector = inject(Injector);
    destroyRef = inject(DestroyRef);
    ngControl = null;
    rangeValidatorFn = null;
    /** Timestamp of first arrow-key press in current hold sequence. */
    holdStart = null;
    /** Interval that keeps ticking while arrow key is held. */
    holdInterval = null;
    /** Direction of current arrow-key hold: +1 or -1. */
    holdDirection = 0;
    /** Programmatically increments current value by step × multiplier. */
    stepUp(multiplier = 1) {
        this.applyStep(1, multiplier);
    }
    /** Programmatically decrements current value by step × multiplier. */
    stepDown(multiplier = 1) {
        this.applyStep(-1, multiplier);
    }
    // ─── Lifecycle ────────────────────────────────────────────────────────────
    ngOnInit() {
        this.ngControl = this.injector.get(NgControl, null, { self: true, optional: true });
        if (this.ngControl?.control) {
            this.rangeValidatorFn = this.buildRangeValidator();
            this.ngControl.control.addValidators(this.rangeValidatorFn);
            this.ngControl.control.updateValueAndValidity({ emitEvent: false });
            // Re-run validation when min / max inputs change
            effect(() => {
                this.sNumericMin();
                this.sNumericMax();
                this.ngControl?.control?.updateValueAndValidity({ emitEvent: false });
            }, { injector: this.injector });
        }
        this.destroyRef.onDestroy(() => {
            this.clearHold();
            if (this.ngControl?.control && this.rangeValidatorFn) {
                this.ngControl.control.removeValidators(this.rangeValidatorFn);
                this.ngControl.control.updateValueAndValidity({ emitEvent: false });
            }
        });
    }
    // ─── Event Handlers ───────────────────────────────────────────────────────
    onKeyDown(event) {
        // Pass through all Ctrl / Cmd shortcuts (copy, paste, select-all, undo …)
        if (event.ctrlKey || event.metaKey) {
            return;
        }
        // Arrow Up / Down: increment / decrement with acceleration
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            event.preventDefault();
            if (!event.repeat) {
                this.holdDirection = event.key === 'ArrowUp' ? 1 : -1;
                this.holdStart = Date.now();
                this.applyStep(this.holdDirection, 1);
                this.startHoldInterval();
            }
            return;
        }
        // Safe navigation / editing keys
        if (this.isSafeKey(event.key)) {
            return;
        }
        // Digits 0-9
        if (/^\d$/.test(event.key)) {
            if (this.wouldExceedDecimalPlaces(event.key)) {
                event.preventDefault();
            }
            return;
        }
        // Decimal separator (only when decimals are allowed)
        if (this.sNumericDecimal() && (event.key === '.' || event.key === ',')) {
            const nativeInput = this.getNativeInput();
            const currentVal = nativeInput?.value ?? '';
            if (currentVal.includes('.') || currentVal.includes(',')) {
                event.preventDefault(); // already has a decimal separator
            }
            return;
        }
        // Leading minus for negative numbers (when range allows negatives)
        if (event.key === '-' && this.isNegativeAllowed()) {
            const nativeInput = this.getNativeInput();
            if (nativeInput) {
                const selStart = nativeInput.selectionStart ?? 0;
                const selEnd = nativeInput.selectionEnd ?? 0;
                const val = nativeInput.value;
                const replacingAll = selStart === 0 && selEnd === val.length;
                const atStartNoSign = selStart === 0 && !val.startsWith('-');
                if (atStartNoSign || replacingAll) {
                    return;
                }
            }
        }
        // Block everything else
        event.preventDefault();
    }
    onKeyUp(event) {
        if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
            this.clearHold();
        }
    }
    onPaste(event) {
        event.preventDefault();
        const clipText = event.clipboardData?.getData('text') ?? '';
        const nativeInput = this.getNativeInput();
        if (!nativeInput)
            return;
        const selStart = nativeInput.selectionStart ?? 0;
        const selEnd = nativeInput.selectionEnd ?? nativeInput.value.length;
        const combined = nativeInput.value.slice(0, selStart) + clipText + nativeInput.value.slice(selEnd);
        const sanitized = this.sanitize(combined);
        if (sanitized === null)
            return;
        const num = this.parseValue(sanitized);
        const displayText = num !== null ? String(this.clamp(num)) : sanitized;
        this.setValue(displayText);
    }
    // ─── Hold / Acceleration ─────────────────────────────────────────────────
    startHoldInterval() {
        this.holdInterval = setInterval(() => {
            if (this.holdStart === null)
                return;
            const elapsed = Date.now() - this.holdStart;
            const multiplier = Math.min(1 + Math.floor(elapsed / ACCELERATION_INTERVAL_MS$1), MAX_MULTIPLIER$1);
            this.applyStep(this.holdDirection, multiplier);
        }, HOLD_TICK_MS$1);
    }
    clearHold() {
        if (this.holdInterval !== null) {
            clearInterval(this.holdInterval);
            this.holdInterval = null;
        }
        this.holdStart = null;
        this.holdDirection = 0;
    }
    // ─── Value Manipulation ───────────────────────────────────────────────────
    applyStep(direction, multiplier) {
        const current = this.parseCurrentValue() ?? 0;
        const delta = direction * this.sNumericStep() * multiplier;
        let next = current + delta;
        if (!this.sNumericDecimal()) {
            next = Math.round(next);
        }
        else {
            const places = this.sNumericDecimalPlaces();
            next = Math.round(next * 10 ** places) / 10 ** places;
        }
        this.setValue(String(this.clamp(next)));
    }
    clamp(value) {
        const min = this.sNumericMin();
        const max = this.sNumericMax();
        if (min !== undefined && value < min)
            return min;
        if (max !== undefined && value > max)
            return max;
        return value;
    }
    setValue(text) {
        const control = this.ngControl?.control;
        if (control) {
            control.setValue(text);
            control.markAsDirty();
        }
        else {
            const nativeInput = this.getNativeInput();
            if (nativeInput) {
                nativeInput.value = text;
                nativeInput.dispatchEvent(new Event('input', { bubbles: true }));
            }
        }
    }
    parseCurrentValue() {
        const control = this.ngControl?.control;
        const text = control ? String(control.value ?? '') : (this.getNativeInput()?.value ?? '');
        return this.parseValue(text);
    }
    parseValue(text) {
        const normalized = text
            .replace(/[\s\u00A0]/g, '')
            .replace(',', '.')
            .trim();
        if (!normalized || normalized === '-')
            return null;
        const num = Number(normalized);
        return isNaN(num) ? null : num;
    }
    /**
     * Strips all characters that are not legal for the current configuration.
     * Returns null if the result is empty (nothing usable to insert).
     */
    sanitize(raw) {
        let result = raw.replace(',', '.');
        if (this.sNumericDecimal()) {
            result = result.replace(/[^0-9.\-]/g, '');
            // Keep only the first decimal point
            const parts = result.split('.');
            if (parts.length > 2) {
                result = parts[0] + '.' + parts.slice(1).join('');
            }
            // Trim to allowed decimal places
            if (result.includes('.')) {
                const [intPart, decPart] = result.split('.');
                result = intPart + '.' + decPart.slice(0, this.sNumericDecimalPlaces());
            }
        }
        else {
            result = result.replace(/[^0-9\-]/g, '');
        }
        if (!this.isNegativeAllowed()) {
            result = result.replace(/-/g, '');
        }
        else {
            // Keep minus only at the start
            const hasLeadingMinus = result.startsWith('-');
            result = result.replace(/-/g, '');
            if (hasLeadingMinus)
                result = '-' + result;
        }
        return result || null;
    }
    // ─── Validator ────────────────────────────────────────────────────────────
    buildRangeValidator() {
        return (control) => {
            const value = this.parseValue(String(control.value ?? ''));
            if (value === null)
                return null;
            const min = this.sNumericMin();
            const max = this.sNumericMax();
            if (min !== undefined && value < min) {
                return { numericMin: { min, actual: value } };
            }
            if (max !== undefined && value > max) {
                return { numericMax: { max, actual: value } };
            }
            return null;
        };
    }
    // ─── Helpers ─────────────────────────────────────────────────────────────
    /**
     * Returns true if typing the given digit at the current cursor position
     * would result in more decimal digits than `sNumericDecimalPlaces` allows.
     */
    wouldExceedDecimalPlaces(digit) {
        if (!this.sNumericDecimal())
            return false;
        const nativeInput = this.getNativeInput();
        if (!nativeInput)
            return false;
        const val = nativeInput.value;
        const selStart = nativeInput.selectionStart ?? val.length;
        const selEnd = nativeInput.selectionEnd ?? selStart;
        // Simulate resulting string
        const newVal = val.slice(0, selStart) + digit + val.slice(selEnd);
        const dotIndex = newVal.indexOf('.');
        if (dotIndex === -1)
            return false;
        return newVal.slice(dotIndex + 1).length > this.sNumericDecimalPlaces();
    }
    isSafeKey(key) {
        return [
            'Backspace',
            'Delete',
            'Tab',
            'Enter',
            'ArrowLeft',
            'ArrowRight',
            'Home',
            'End',
            'Escape',
            'F1',
            'F2',
            'F3',
            'F4',
            'F5',
            'F6',
            'F7',
            'F8',
            'F9',
            'F10',
            'F11',
            'F12',
        ].includes(key);
    }
    isNegativeAllowed() {
        const min = this.sNumericMin();
        return min === undefined || min < 0;
    }
    getNativeInput() {
        const el = this.el.nativeElement;
        if (el instanceof HTMLInputElement) {
            return el;
        }
        return el.querySelector('input');
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SNumericDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "22.0.0", type: SNumericDirective, isStandalone: true, selector: "[sNumeric]", inputs: { sNumericStep: { classPropertyName: "sNumericStep", publicName: "sNumericStep", isSignal: true, isRequired: false, transformFunction: null }, sNumericDecimal: { classPropertyName: "sNumericDecimal", publicName: "sNumericDecimal", isSignal: true, isRequired: false, transformFunction: null }, sNumericDecimalPlaces: { classPropertyName: "sNumericDecimalPlaces", publicName: "sNumericDecimalPlaces", isSignal: true, isRequired: false, transformFunction: null }, sNumericMin: { classPropertyName: "sNumericMin", publicName: "sNumericMin", isSignal: true, isRequired: false, transformFunction: null }, sNumericMax: { classPropertyName: "sNumericMax", publicName: "sNumericMax", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "keydown": "onKeyDown($event)", "keyup": "onKeyUp($event)", "paste": "onPaste($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SNumericDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sNumeric]',
                    standalone: true,
                }]
        }], propDecorators: { sNumericStep: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNumericStep", required: false }] }], sNumericDecimal: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNumericDecimal", required: false }] }], sNumericDecimalPlaces: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNumericDecimalPlaces", required: false }] }], sNumericMin: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNumericMin", required: false }] }], sNumericMax: [{ type: i0.Input, args: [{ isSignal: true, alias: "sNumericMax", required: false }] }], onKeyDown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], onKeyUp: [{
                type: HostListener,
                args: ['keyup', ['$event']]
            }], onPaste: [{
                type: HostListener,
                args: ['paste', ['$event']]
            }] } });

class SInputComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    type = input('text', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []));
    value = input('', { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toStringValue });
    valueChange = output();
    internalValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    inputElement = viewChild('inputElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    writeValue(value) {
        this.internalValue.set(toStringValue(value));
    }
    handleInput(event) {
        const nextValue = event.target.value;
        this.internalValue.set(nextValue);
        this.onChange(nextValue);
        this.valueChange.emit(nextValue);
    }
    handleBlur() {
        this.onTouched();
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalValue.set('');
        this.onChange('');
        this.valueChange.emit('');
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SInputComponent, isStandalone: true, selector: "s-input", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, type: { classPropertyName: "type", publicName: "type", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SInputComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-input\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [type]=\"type()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-input', imports: [MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SInputComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-input\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [type]=\"type()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], type: [{ type: i0.Input, args: [{ isSignal: true, alias: "type", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], inputElement: [{ type: i0.ViewChild, args: ['inputElement', { isSignal: true }] }] } });

const HOLD_TICK_MS = 80;
const HOLD_START_DELAY_MS = 500;
const ACCELERATION_INTERVAL_MS = 700;
const MAX_MULTIPLIER = 20;
class SInputNumberComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    valueChange = output();
    step = input(1, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "step" }] : /* istanbul ignore next */ []));
    decimal = input(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "decimal" }] : /* istanbul ignore next */ []));
    decimalPlaces = input(2, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "decimalPlaces" }] : /* istanbul ignore next */ []));
    min = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    max = input(undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    buttonsPosition = input('right', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "buttonsPosition" }] : /* istanbul ignore next */ []));
    destroyRef = inject(DestroyRef);
    internalControl = new FormControl('', { nonNullable: true });
    currentDisplayValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentDisplayValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentDisplayValue().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    prefixSlot = contentChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => !!this.prefixIcon() ||
        this.buttonsPosition() === 'left' ||
        this.buttonsPosition() === 'sides' ||
        this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    numericDirective = viewChild(SNumericDirective, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "numericDirective" }] : /* istanbul ignore next */ []));
    inputElement = viewChild('inputElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    holdStart = null;
    holdStartTimeout = null;
    holdInterval = null;
    holdDirection = 0;
    constructor() {
        super();
        this.internalControl.valueChanges.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((nextValue) => {
            this.currentDisplayValue.set(nextValue);
            const num = this.parseToNumber(nextValue);
            this.onChange(num);
            this.valueChange.emit(num);
        });
        effect(() => {
            if (!this.ngControl()) {
                const raw = this.value() == null ? '' : String(this.value());
                const formatted = this.formatDisplay(raw);
                this.internalControl.setValue(formatted, { emitEvent: false });
                this.currentDisplayValue.set(formatted);
            }
        });
        effect(() => {
            if (this.isDisabled()) {
                this.internalControl.disable({ emitEvent: false });
                return;
            }
            this.internalControl.enable({ emitEvent: false });
        });
        this.destroyRef.onDestroy(() => {
            this.handleButtonRelease();
        });
    }
    writeValue(value) {
        const raw = value == null ? '' : String(value);
        const formatted = this.formatDisplay(raw);
        this.internalControl.setValue(formatted, { emitEvent: false });
        this.currentDisplayValue.set(formatted);
    }
    handleFocusIn() {
        const stripped = this.internalControl.value.replace(/[\s\u00A0]/g, '');
        if (stripped !== this.internalControl.value) {
            this.internalControl.setValue(stripped, { emitEvent: false });
            this.currentDisplayValue.set(stripped);
        }
    }
    handleFocusOut() {
        this.onTouched();
        const formatted = this.formatDisplay(this.internalControl.value);
        if (formatted !== this.internalControl.value) {
            this.internalControl.setValue(formatted, { emitEvent: false });
            this.currentDisplayValue.set(formatted);
        }
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalControl.setValue('');
        this.onTouched();
    }
    handleButtonPress(direction) {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.handleButtonRelease();
        this.holdDirection = direction;
        this.holdStart = Date.now();
        this.applyStep(1);
        this.holdStartTimeout = setTimeout(() => {
            this.holdInterval = setInterval(() => {
                if (this.holdStart === null) {
                    return;
                }
                const elapsed = Date.now() - this.holdStart;
                const multiplier = Math.min(1 + Math.floor(elapsed / ACCELERATION_INTERVAL_MS), MAX_MULTIPLIER);
                this.applyStep(multiplier);
            }, HOLD_TICK_MS);
        }, HOLD_START_DELAY_MS);
    }
    handleButtonRelease() {
        if (this.holdStartTimeout !== null) {
            clearTimeout(this.holdStartTimeout);
            this.holdStartTimeout = null;
        }
        if (this.holdInterval !== null) {
            clearInterval(this.holdInterval);
            this.holdInterval = null;
        }
        this.holdStart = null;
        this.holdDirection = 0;
    }
    formatDisplay(raw) {
        const stripped = raw.replace(/[\s\u00A0]/g, '');
        if (!stripped || stripped === '-')
            return stripped;
        const isNeg = stripped.startsWith('-');
        const withoutSign = isNeg ? stripped.slice(1) : stripped;
        const [intPart, decPart] = withoutSign.split('.');
        const formattedInt = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '\u00a0');
        return (isNeg ? '-' : '') + formattedInt + (decPart !== undefined ? '.' + decPart : '');
    }
    parseToNumber(raw) {
        const stripped = raw.replace(/[\s\u00A0]/g, '').replace(',', '.');
        if (!stripped || stripped === '-')
            return null;
        const num = Number(stripped);
        return isNaN(num) ? null : num;
    }
    applyStep(multiplier) {
        const numeric = this.numericDirective();
        if (!numeric || this.holdDirection === 0) {
            return;
        }
        if (this.holdDirection > 0) {
            numeric.stepUp(multiplier);
        }
        else {
            numeric.stepDown(multiplier);
        }
        this.onTouched();
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputNumberComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SInputNumberComponent, isStandalone: true, selector: "s-input-number", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, step: { classPropertyName: "step", publicName: "step", isSignal: true, isRequired: false, transformFunction: null }, decimal: { classPropertyName: "decimal", publicName: "decimal", isSignal: true, isRequired: false, transformFunction: null }, decimalPlaces: { classPropertyName: "decimalPlaces", publicName: "decimalPlaces", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, buttonsPosition: { classPropertyName: "buttonsPosition", publicName: "buttonsPosition", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, host: { listeners: { "document:pointerup": "handleButtonRelease()", "document:pointercancel": "handleButtonRelease()" } }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SInputNumberComponent),
                multi: true,
            },
        ], queries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }], viewQueries: [{ propertyName: "numericDirective", first: true, predicate: SNumericDirective, descendants: true, isSignal: true }, { propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-input\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      @if (buttonsPosition() === 'left') {\n        <div class=\"s-input-number__stack\">\n          <button\n            type=\"button\"\n            mat-icon-button\n            aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (pointerdown)=\"handleButtonPress(-1)\"\n            (pointerup)=\"handleButtonRelease()\"\n            (pointerleave)=\"handleButtonRelease()\"\n          >\n            <mat-icon>remove</mat-icon>\n          </button>\n\n          <button\n            type=\"button\"\n            mat-icon-button\n            aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (pointerdown)=\"handleButtonPress(1)\"\n            (pointerup)=\"handleButtonRelease()\"\n            (pointerleave)=\"handleButtonRelease()\"\n          >\n            <mat-icon>add</mat-icon>\n          </button>\n        </div>\n      }\n\n      @if (buttonsPosition() === 'sides') {\n        <button\n          class=\"s-input-number__side-button\"\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(-1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>remove</mat-icon>\n        </button>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    sNumeric\n    type=\"text\"\n    inputmode=\"numeric\"\n    [formControl]=\"internalControl\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    [sNumericStep]=\"step()\"\n    [sNumericDecimal]=\"decimal()\"\n    [sNumericDecimalPlaces]=\"decimalPlaces()\"\n    [sNumericMin]=\"min()\"\n    [sNumericMax]=\"max()\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (focus)=\"handleFocusIn()\"\n    (blur)=\"handleFocusOut()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (buttonsPosition() === 'right') {\n      <div class=\"s-input-number__stack\">\n        <button\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(-1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>remove</mat-icon>\n        </button>\n\n        <button\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>add</mat-icon>\n        </button>\n      </div>\n    }\n\n    @if (buttonsPosition() === 'sides') {\n      <button\n        class=\"s-input-number__side-button\"\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || isReadonly()\"\n        (pointerdown)=\"handleButtonPress(1)\"\n        (pointerup)=\"handleButtonRelease()\"\n        (pointerleave)=\"handleButtonRelease()\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n    }\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input{width:100%}.s-input-number__stack{display:flex;align-items:center}.s-input-number__side-button{align-self:center}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"], dependencies: [{ kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$1.DefaultValueAccessor, selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: SNumericDirective, selector: "[sNumeric]", inputs: ["sNumericStep", "sNumericDecimal", "sNumericDecimalPlaces", "sNumericMin", "sNumericMax"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputNumberComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-input-number', imports: [ReactiveFormsModule, MatButtonModule, MatIconModule, MatFormFieldModule, MatInputModule, SNumericDirective], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SInputNumberComponent),
                            multi: true,
                        },
                    ], host: {
                        '(document:pointerup)': 'handleButtonRelease()',
                        '(document:pointercancel)': 'handleButtonRelease()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-input\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      @if (buttonsPosition() === 'left') {\n        <div class=\"s-input-number__stack\">\n          <button\n            type=\"button\"\n            mat-icon-button\n            aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (pointerdown)=\"handleButtonPress(-1)\"\n            (pointerup)=\"handleButtonRelease()\"\n            (pointerleave)=\"handleButtonRelease()\"\n          >\n            <mat-icon>remove</mat-icon>\n          </button>\n\n          <button\n            type=\"button\"\n            mat-icon-button\n            aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n            [disabled]=\"isDisabled() || isReadonly()\"\n            (pointerdown)=\"handleButtonPress(1)\"\n            (pointerup)=\"handleButtonRelease()\"\n            (pointerleave)=\"handleButtonRelease()\"\n          >\n            <mat-icon>add</mat-icon>\n          </button>\n        </div>\n      }\n\n      @if (buttonsPosition() === 'sides') {\n        <button\n          class=\"s-input-number__side-button\"\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(-1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>remove</mat-icon>\n        </button>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    sNumeric\n    type=\"text\"\n    inputmode=\"numeric\"\n    [formControl]=\"internalControl\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    [sNumericStep]=\"step()\"\n    [sNumericDecimal]=\"decimal()\"\n    [sNumericDecimalPlaces]=\"decimalPlaces()\"\n    [sNumericMin]=\"min()\"\n    [sNumericMax]=\"max()\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (focus)=\"handleFocusIn()\"\n    (blur)=\"handleFocusOut()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (buttonsPosition() === 'right') {\n      <div class=\"s-input-number__stack\">\n        <button\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(-1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>remove</mat-icon>\n        </button>\n\n        <button\n          type=\"button\"\n          mat-icon-button\n          aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n          [disabled]=\"isDisabled() || isReadonly()\"\n          (pointerdown)=\"handleButtonPress(1)\"\n          (pointerup)=\"handleButtonRelease()\"\n          (pointerleave)=\"handleButtonRelease()\"\n        >\n          <mat-icon>add</mat-icon>\n        </button>\n      </div>\n    }\n\n    @if (buttonsPosition() === 'sides') {\n      <button\n        class=\"s-input-number__side-button\"\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || isReadonly()\"\n        (pointerdown)=\"handleButtonPress(1)\"\n        (pointerup)=\"handleButtonRelease()\"\n        (pointerleave)=\"handleButtonRelease()\"\n      >\n        <mat-icon>add</mat-icon>\n      </button>\n    }\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input{width:100%}.s-input-number__stack{display:flex;align-items:center}.s-input-number__side-button{align-self:center}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], step: [{ type: i0.Input, args: [{ isSignal: true, alias: "step", required: false }] }], decimal: [{ type: i0.Input, args: [{ isSignal: true, alias: "decimal", required: false }] }], decimalPlaces: [{ type: i0.Input, args: [{ isSignal: true, alias: "decimalPlaces", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], buttonsPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "buttonsPosition", required: false }] }], prefixSlot: [{ type: i0.ContentChild, args: ['[sPrefix]', { isSignal: true }] }], numericDirective: [{ type: i0.ViewChild, args: [i0.forwardRef(() => SNumericDirective), { isSignal: true }] }], inputElement: [{ type: i0.ViewChild, args: ['inputElement', { isSignal: true }] }] } });

class SInputPasswordComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    prefixIcon = input('lock', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixIcon" }] : /* istanbul ignore next */ []));
    value = input('', { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toStringValue });
    valueChange = output();
    internalValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    revealed = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "revealed" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    inputType = computed(() => (this.revealed() ? 'text' : 'password'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputType" }] : /* istanbul ignore next */ []));
    toggleIcon = computed(() => (this.revealed() ? 'visibility_off' : 'visibility'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toggleIcon" }] : /* istanbul ignore next */ []));
    toggleLabel = computed(() => (this.revealed() ? 'Скрыть пароль' : 'Показать пароль'), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "toggleLabel" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    inputElement = viewChild('inputElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "inputElement" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    focus() {
        this.inputElement()?.nativeElement.focus();
    }
    writeValue(value) {
        this.internalValue.set(toStringValue(value));
    }
    handleInput(event) {
        const nextValue = event.target.value;
        this.internalValue.set(nextValue);
        this.onChange(nextValue);
        this.valueChange.emit(nextValue);
    }
    handleBlur() {
        this.onTouched();
    }
    toggleVisibility() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.revealed.update((value) => !value);
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalValue.set('');
        this.onChange('');
        this.valueChange.emit('');
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputPasswordComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SInputPasswordComponent, isStandalone: true, selector: "s-input-password", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, prefixIcon: { classPropertyName: "prefixIcon", publicName: "prefixIcon", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SInputPasswordComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-input-password\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [type]=\"inputType()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n\n    <button\n      type=\"button\"\n      mat-icon-button\n      [attr.aria-label]=\"toggleLabel()\"\n      [disabled]=\"isDisabled() || isReadonly()\"\n      (click)=\"toggleVisibility()\"\n    >\n      <mat-icon>{{ toggleIcon() }}</mat-icon>\n    </button>\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input-password{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SInputPasswordComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-input-password', imports: [MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SInputPasswordComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-input-password\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <input\n    #inputElement\n    matInput\n    [type]=\"inputType()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  />\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n\n    <button\n      type=\"button\"\n      mat-icon-button\n      [attr.aria-label]=\"toggleLabel()\"\n      [disabled]=\"isDisabled() || isReadonly()\"\n      (click)=\"toggleVisibility()\"\n    >\n      <mat-icon>{{ toggleIcon() }}</mat-icon>\n    </button>\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-input-password{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], prefixIcon: [{ type: i0.Input, args: [{ isSignal: true, alias: "prefixIcon", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], inputElement: [{ type: i0.ViewChild, args: ['inputElement', { isSignal: true }] }] } });

class SSelectComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    value = input(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []));
    valueChange = output();
    options = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []));
    internalValue = signal(null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue() !== null, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    selectElement = viewChild(MatSelect, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "selectElement" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    writeValue(value) {
        this.internalValue.set(value ?? null);
    }
    handleSelectionChange(value) {
        this.internalValue.set(value ?? null);
        this.onChange(value ?? null);
        this.valueChange.emit(value ?? null);
    }
    handleBlur() {
        this.onTouched();
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalValue.set(null);
        this.onChange(null);
        this.valueChange.emit(null);
        this.onTouched();
    }
    focus() {
        this.selectElement()?.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SSelectComponent, isStandalone: true, selector: "s-select", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => SSelectComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "selectElement", first: true, predicate: MatSelect, descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-select\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <mat-select\n    [placeholder]=\"placeholder()\"\n    [disabled]=\"isDisabled() || isReadonly()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (selectionChange)=\"handleSelectionChange($event.value)\"\n    (blur)=\"handleBlur()\"\n  >\n    @for (option of options(); track option.title + '-' + $index) {\n      <mat-option [value]=\"option.value\" [disabled]=\"option.disabled ?? false\">\n        {{ option.title }}\n      </mat-option>\n    }\n  </mat-select>\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-select{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-select', imports: [MatFormFieldModule, MatIconModule, MatSelectModule, MatButtonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => SSelectComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-select\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <mat-select\n    [placeholder]=\"placeholder()\"\n    [disabled]=\"isDisabled() || isReadonly()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (selectionChange)=\"handleSelectionChange($event.value)\"\n    (blur)=\"handleBlur()\"\n  >\n    @for (option of options(); track option.title + '-' + $index) {\n      <mat-option [value]=\"option.value\" [disabled]=\"option.disabled ?? false\">\n        {{ option.title }}\n      </mat-option>\n    }\n  </mat-select>\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-select{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], options: [{ type: i0.Input, args: [{ isSignal: true, alias: "options", required: false }] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], selectElement: [{ type: i0.ViewChild, args: [i0.forwardRef(() => MatSelect), { isSignal: true }] }] } });

class SSlidePanelExtendClass {
    // eslint-disable-next-line unused-imports/no-unused-vars, @typescript-eslint/no-empty-function
    closePanel(closeData) { }
}

const DEF_SLIDE_PANEL_PARAMS = {
    disabledClose: false,
};
class SSlidePanelComponent {
    params = input(DEF_SLIDE_PANEL_PARAMS, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "params" }] : /* istanbul ignore next */ []));
    component = input.required(/* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "component" }] : /* istanbul ignore next */ []));
    data = input(/* @ts-ignore */
    ...(ngDevMode ? [undefined, { debugName: "data" }] : /* istanbul ignore next */ []));
    componentRef = null;
    isOpen = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    afterClosedSubject = new Subject();
    afterClosed$ = this.afterClosedSubject.asObservable();
    elementRef = inject(ElementRef);
    closeData = null;
    panelRef;
    contentRef;
    ngAfterViewInit() {
        this.contentRef.clear();
        this.componentRef = this.contentRef.createComponent(this.component());
        const data = this.data();
        if (data) {
            Object.keys(data).forEach((key) => this.componentRef?.setInput(key, data[key]));
        }
        this.componentRef.instance['closePanel'] = (closeData = null) => this.closePanel(closeData);
        setTimeout(() => {
            this.panelRef.nativeElement.getBoundingClientRect();
            this.isOpen.set(true);
        });
    }
    onHostClick(e) {
        if (e.target === this.elementRef.nativeElement && !this.params()?.disabledClose) {
            this.closePanel();
        }
    }
    onPanelTransitionEnd(e) {
        if (!this.isOpen() && e.propertyName === 'transform') {
            this.clearComponent();
        }
    }
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    doDestroy() { }
    closePanel(closeData = null) {
        this.closeData = closeData;
        this.isOpen.set(false);
    }
    clearComponent() {
        this.contentRef.clear();
        this.componentRef = null;
        this.afterClosedSubject.next(this.closeData);
        this.afterClosedSubject.complete();
        this.doDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "22.0.0", type: SSlidePanelComponent, isStandalone: true, selector: "s-slide-panel", inputs: { params: { classPropertyName: "params", publicName: "params", isSignal: true, isRequired: false, transformFunction: null }, component: { classPropertyName: "component", publicName: "component", isSignal: true, isRequired: true, transformFunction: null }, data: { classPropertyName: "data", publicName: "data", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "onHostClick($event)" }, classAttribute: "show" }, viewQueries: [{ propertyName: "panelRef", first: true, predicate: ["panel"], descendants: true, read: ElementRef }, { propertyName: "contentRef", first: true, predicate: ["content"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div #panel class=\"sliding-panel\" [class.is-open]=\"isOpen()\" (transitionend)=\"onPanelTransitionEnd($event)\">\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{position:fixed;z-index:1;top:0;left:0;display:block;width:100vw;height:100vh;background:#0003}.sliding-panel{position:absolute;top:0;right:0;bottom:0;display:flex;flex-direction:column;transition:transform .3s ease-in-out;transform:translate(100%);background:#fff;box-shadow:-2px 0 5px #0003}.sliding-panel.is-open{transform:translate(0)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-slide-panel', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'show',
                        '(click)': 'onHostClick($event)',
                    }, template: "<div #panel class=\"sliding-panel\" [class.is-open]=\"isOpen()\" (transitionend)=\"onPanelTransitionEnd($event)\">\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{position:fixed;z-index:1;top:0;left:0;display:block;width:100vw;height:100vh;background:#0003}.sliding-panel{position:absolute;top:0;right:0;bottom:0;display:flex;flex-direction:column;transition:transform .3s ease-in-out;transform:translate(100%);background:#fff;box-shadow:-2px 0 5px #0003}.sliding-panel.is-open{transform:translate(0)}\n"] }]
        }], propDecorators: { params: [{ type: i0.Input, args: [{ isSignal: true, alias: "params", required: false }] }], component: [{ type: i0.Input, args: [{ isSignal: true, alias: "component", required: true }] }], data: [{ type: i0.Input, args: [{ isSignal: true, alias: "data", required: false }] }], panelRef: [{
                type: ViewChild,
                args: ['panel', { read: ElementRef }]
            }], contentRef: [{
                type: ViewChild,
                args: ['content', { read: ViewContainerRef }]
            }] } });

class SSlidePanelService {
    document = inject(DOCUMENT);
    appRef = inject(ApplicationRef);
    showPanel$(component, data, params = DEF_SLIDE_PANEL_PARAMS) {
        return this.showPanel(component, data, params).afterClosed$;
    }
    showPanel(component, data, params = DEF_SLIDE_PANEL_PARAMS) {
        const panelRef = createComponent(SSlidePanelComponent, { environmentInjector: this.appRef.injector });
        panelRef.setInput('params', params);
        panelRef.setInput('data', data);
        panelRef.setInput('component', component);
        panelRef.instance.doDestroy = () => {
            this.appRef.detachView(panelRef.hostView);
            panelRef.destroy();
        };
        this.document.body.appendChild(panelRef.location.nativeElement);
        this.appRef.attachView(panelRef.hostView);
        return panelRef.instance;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class SSlidePanelContainerComponent {
    panelTitle = input('Панель', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "panelTitle" }] : /* istanbul ignore next */ []));
    applyButtonTitle = input('Применить', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "applyButtonTitle" }] : /* istanbul ignore next */ []));
    cancelButtonTitle = input('Отмена', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "cancelButtonTitle" }] : /* istanbul ignore next */ []));
    disabledApplyButton = input(false, { ...(ngDevMode ? { debugName: "disabledApplyButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    disabledCancelButton = input(false, { ...(ngDevMode ? { debugName: "disabledCancelButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visibleFooter = input(true, { ...(ngDevMode ? { debugName: "visibleFooter" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visibleFooterButtons = input(true, { ...(ngDevMode ? { debugName: "visibleFooterButtons" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visibleApplyButton = input(true, { ...(ngDevMode ? { debugName: "visibleApplyButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    visibleCancelButton = input(true, { ...(ngDevMode ? { debugName: "visibleCancelButton" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    closeEvent = output();
    applyEvent = output();
    prefixSlot = viewChild('prefixSlot', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    suffixSlot = viewChild('suffixSlot', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "suffixSlot" }] : /* istanbul ignore next */ []));
    hasPrefixContent = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasPrefixContent" }] : /* istanbul ignore next */ []));
    hasSuffixContent = signal(false, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasSuffixContent" }] : /* istanbul ignore next */ []));
    ngAfterViewChecked() {
        this.hasPrefixContent.set(this.slotHasContent(this.prefixSlot()));
        this.hasSuffixContent.set(this.slotHasContent(this.suffixSlot()));
    }
    onClosePanel() {
        this.closeEvent.emit();
    }
    onApplyPanel() {
        this.applyEvent.emit();
    }
    slotHasContent(slot) {
        if (!slot) {
            return false;
        }
        return Array.from(slot.nativeElement.childNodes).some((node) => {
            if (node.nodeType === 1) {
                return true;
            }
            return node.nodeType === 3 && Boolean(node.textContent?.trim());
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: SSlidePanelContainerComponent, isStandalone: true, selector: "s-slide-panel-container", inputs: { panelTitle: { classPropertyName: "panelTitle", publicName: "panelTitle", isSignal: true, isRequired: false, transformFunction: null }, applyButtonTitle: { classPropertyName: "applyButtonTitle", publicName: "applyButtonTitle", isSignal: true, isRequired: false, transformFunction: null }, cancelButtonTitle: { classPropertyName: "cancelButtonTitle", publicName: "cancelButtonTitle", isSignal: true, isRequired: false, transformFunction: null }, disabledApplyButton: { classPropertyName: "disabledApplyButton", publicName: "disabledApplyButton", isSignal: true, isRequired: false, transformFunction: null }, disabledCancelButton: { classPropertyName: "disabledCancelButton", publicName: "disabledCancelButton", isSignal: true, isRequired: false, transformFunction: null }, visibleFooter: { classPropertyName: "visibleFooter", publicName: "visibleFooter", isSignal: true, isRequired: false, transformFunction: null }, visibleFooterButtons: { classPropertyName: "visibleFooterButtons", publicName: "visibleFooterButtons", isSignal: true, isRequired: false, transformFunction: null }, visibleApplyButton: { classPropertyName: "visibleApplyButton", publicName: "visibleApplyButton", isSignal: true, isRequired: false, transformFunction: null }, visibleCancelButton: { classPropertyName: "visibleCancelButton", publicName: "visibleCancelButton", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closeEvent: "closeEvent", applyEvent: "applyEvent" }, viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["prefixSlot"], descendants: true, isSignal: true }, { propertyName: "suffixSlot", first: true, predicate: ["suffixSlot"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"head\">\n  <div class=\"head-title\">{{ panelTitle() }}</div>\n  <button type=\"button\" mat-icon-button aria-label=\"\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0430\u043D\u0435\u043B\u044C\" color=\"accent\" (click)=\"onClosePanel()\">\n    <mat-icon>close</mat-icon>\n  </button>\n</div>\n<div class=\"content\">\n  <ng-content></ng-content>\n</div>\n@if (visibleFooter()) {\n  <div class=\"footer\">\n    <div #prefixSlot class=\"flex-auto\" [class.slot-hidden]=\"!hasPrefixContent()\">\n      <ng-content select=\"[sPrefix]\"></ng-content>\n    </div>\n\n    @if (visibleFooterButtons()) {\n      <div class=\"footer-buttons\">\n        @if (visibleCancelButton()) {\n          <button type=\"button\" mat-button color=\"accent\" [disabled]=\"disabledCancelButton()\" (click)=\"onClosePanel()\">\n            {{ cancelButtonTitle() }}\n          </button>\n        }\n        @if (visibleApplyButton()) {\n          <button\n            class=\"apply-button\"\n            type=\"button\"\n            mat-flat-button\n            color=\"primary\"\n            [disabled]=\"disabledApplyButton()\"\n            (click)=\"onApplyPanel()\"\n          >\n            {{ applyButtonTitle() }}\n          </button>\n        }\n      </div>\n    }\n\n    <div #suffixSlot class=\"flex-auto\" [class.slot-hidden]=\"!hasSuffixContent()\">\n      <ng-content select=\"[sSuffix]\"></ng-content>\n    </div>\n  </div>\n}\n", styles: [":host{display:flex;flex-direction:column;box-sizing:border-box;background-color:#fff}.head{display:flex;align-items:center;box-sizing:border-box;padding:5px 10px;border-bottom:1px solid #c6c6c6}.head-title{flex:auto;font-size:18px;font-weight:700}.content{display:flex;flex:auto;flex-direction:column}.footer{display:flex;align-items:center;box-sizing:border-box;padding:10px;border-top:1px solid #c6c6c6}.footer-buttons{display:flex;align-items:center;flex:auto;justify-content:flex-end}.apply-button{margin-left:10px}.flex-auto{flex:auto}.slot-hidden{display:none}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: SSlidePanelContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-slide-panel-container', imports: [MatIconModule, MatButtonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"head\">\n  <div class=\"head-title\">{{ panelTitle() }}</div>\n  <button type=\"button\" mat-icon-button aria-label=\"\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0430\u043D\u0435\u043B\u044C\" color=\"accent\" (click)=\"onClosePanel()\">\n    <mat-icon>close</mat-icon>\n  </button>\n</div>\n<div class=\"content\">\n  <ng-content></ng-content>\n</div>\n@if (visibleFooter()) {\n  <div class=\"footer\">\n    <div #prefixSlot class=\"flex-auto\" [class.slot-hidden]=\"!hasPrefixContent()\">\n      <ng-content select=\"[sPrefix]\"></ng-content>\n    </div>\n\n    @if (visibleFooterButtons()) {\n      <div class=\"footer-buttons\">\n        @if (visibleCancelButton()) {\n          <button type=\"button\" mat-button color=\"accent\" [disabled]=\"disabledCancelButton()\" (click)=\"onClosePanel()\">\n            {{ cancelButtonTitle() }}\n          </button>\n        }\n        @if (visibleApplyButton()) {\n          <button\n            class=\"apply-button\"\n            type=\"button\"\n            mat-flat-button\n            color=\"primary\"\n            [disabled]=\"disabledApplyButton()\"\n            (click)=\"onApplyPanel()\"\n          >\n            {{ applyButtonTitle() }}\n          </button>\n        }\n      </div>\n    }\n\n    <div #suffixSlot class=\"flex-auto\" [class.slot-hidden]=\"!hasSuffixContent()\">\n      <ng-content select=\"[sSuffix]\"></ng-content>\n    </div>\n  </div>\n}\n", styles: [":host{display:flex;flex-direction:column;box-sizing:border-box;background-color:#fff}.head{display:flex;align-items:center;box-sizing:border-box;padding:5px 10px;border-bottom:1px solid #c6c6c6}.head-title{flex:auto;font-size:18px;font-weight:700}.content{display:flex;flex:auto;flex-direction:column}.footer{display:flex;align-items:center;box-sizing:border-box;padding:10px;border-top:1px solid #c6c6c6}.footer-buttons{display:flex;align-items:center;flex:auto;justify-content:flex-end}.apply-button{margin-left:10px}.flex-auto{flex:auto}.slot-hidden{display:none}\n"] }]
        }], propDecorators: { panelTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "panelTitle", required: false }] }], applyButtonTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "applyButtonTitle", required: false }] }], cancelButtonTitle: [{ type: i0.Input, args: [{ isSignal: true, alias: "cancelButtonTitle", required: false }] }], disabledApplyButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledApplyButton", required: false }] }], disabledCancelButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabledCancelButton", required: false }] }], visibleFooter: [{ type: i0.Input, args: [{ isSignal: true, alias: "visibleFooter", required: false }] }], visibleFooterButtons: [{ type: i0.Input, args: [{ isSignal: true, alias: "visibleFooterButtons", required: false }] }], visibleApplyButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "visibleApplyButton", required: false }] }], visibleCancelButton: [{ type: i0.Input, args: [{ isSignal: true, alias: "visibleCancelButton", required: false }] }], closeEvent: [{ type: i0.Output, args: ["closeEvent"] }], applyEvent: [{ type: i0.Output, args: ["applyEvent"] }], prefixSlot: [{ type: i0.ViewChild, args: ['prefixSlot', { isSignal: true }] }], suffixSlot: [{ type: i0.ViewChild, args: ['suffixSlot', { isSignal: true }] }] } });

/* eslint-disable @typescript-eslint/no-magic-numbers */
class STextareaComponent extends BaseValidatedFormFieldControl {
    placeholder = input('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    rows = input(4, { ...(ngDevMode ? { debugName: "rows" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    value = input('', { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: toStringValue });
    valueChange = output();
    internalValue = signal('', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "internalValue" }] : /* istanbul ignore next */ []));
    currentValue = computed(() => this.internalValue(), /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []));
    hasValue = computed(() => this.currentValue().length > 0, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "hasValue" }] : /* istanbul ignore next */ []));
    prefixSlot = viewChild('[sPrefix]', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "prefixSlot" }] : /* istanbul ignore next */ []));
    showPrefixContainer = computed(() => this.prefixIcon() || this.prefixSlot() !== undefined, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "showPrefixContainer" }] : /* istanbul ignore next */ []));
    textareaElement = viewChild('textareaElement', /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "textareaElement" }] : /* istanbul ignore next */ []));
    constructor() {
        super();
        effect(() => {
            if (!this.ngControl()) {
                this.internalValue.set(this.value());
            }
        });
    }
    focus() {
        this.textareaElement()?.nativeElement.focus();
    }
    writeValue(value) {
        this.internalValue.set(toStringValue(value));
    }
    handleInput(event) {
        const nextValue = event.target.value;
        this.internalValue.set(nextValue);
        this.onChange(nextValue);
        this.valueChange.emit(nextValue);
    }
    handleBlur() {
        this.onTouched();
    }
    clearValue() {
        if (this.isDisabled() || this.isReadonly()) {
            return;
        }
        this.internalValue.set('');
        this.onChange('');
        this.valueChange.emit('');
        this.onTouched();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: STextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: STextareaComponent, isStandalone: true, selector: "s-textarea", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, rows: { classPropertyName: "rows", publicName: "rows", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => STextareaComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "prefixSlot", first: true, predicate: ["[sPrefix]"], descendants: true, isSignal: true }, { propertyName: "textareaElement", first: true, predicate: ["textareaElement"], descendants: true, isSignal: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"s-textarea\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <textarea\n    #textareaElement\n    matInput\n    [rows]=\"rows()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  ></textarea>\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-textarea{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}textarea[matInput]{resize:vertical}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4$1.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: STextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-textarea', imports: [MatFormFieldModule, MatIconModule, MatInputModule, MatButtonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => STextareaComponent),
                            multi: true,
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-form-field class=\"s-textarea\" [appearance]=\"appearance()\">\n  <mat-label>{{ label() }}</mat-label>\n\n  @if (showPrefixContainer()) {\n    <div class=\"s-prefix\" matPrefix>\n      @if (prefixIcon()) {\n        <mat-icon>{{ prefixIcon() }}</mat-icon>\n      }\n\n      <span class=\"s-prefix-slot\">\n        <ng-content select=\"[sPrefix]\" />\n      </span>\n    </div>\n  }\n\n  <textarea\n    #textareaElement\n    matInput\n    [rows]=\"rows()\"\n    [placeholder]=\"placeholder()\"\n    [readonly]=\"isReadonly()\"\n    [disabled]=\"isDisabled()\"\n    [value]=\"currentValue()\"\n    [errorStateMatcher]=\"errorStateMatcher\"\n    (input)=\"handleInput($event)\"\n    (keydown)=\"emitKeydownEvent($event)\"\n    (keydown.enter)=\"emitEnterEvent($event)\"\n    (blur)=\"handleBlur()\"\n  ></textarea>\n\n  <div class=\"s-suffix\" matSuffix>\n    <span class=\"s-suffix-slot\">\n      <ng-content select=\"[sSuffix]\" />\n    </span>\n\n    @if (showClearButton() && !isReadonly()) {\n      <button\n        type=\"button\"\n        mat-icon-button\n        aria-label=\"\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435\"\n        [disabled]=\"isDisabled() || !hasValue()\"\n        (click)=\"clearValue()\"\n      >\n        <mat-icon>close</mat-icon>\n      </button>\n    }\n\n    @if (suffixIcon()) {\n      <mat-icon>{{ suffixIcon() }}</mat-icon>\n    }\n  </div>\n\n  @if (hint()) {\n    <mat-hint>{{ hint() }}</mat-hint>\n  }\n\n  @if (control(); as currentControl) {\n    @if (currentControl.invalid && (currentControl.touched || currentControl.dirty)) {\n      <mat-error>{{ resolvedErrorText() }}</mat-error>\n    }\n  }\n</mat-form-field>\n", styles: [".s-textarea{width:100%}:host ::ng-deep .mat-mdc-form-field-icon-prefix,:host ::ng-deep .mat-mdc-form-field-icon-suffix,:host ::ng-deep .mat-mdc-form-field-text-prefix,:host ::ng-deep .mat-mdc-form-field-text-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}:host ::ng-deep .mat-mdc-form-field-icon-prefix>*,:host ::ng-deep .mat-mdc-form-field-icon-suffix>*,:host ::ng-deep .mat-mdc-form-field-text-prefix>*,:host ::ng-deep .mat-mdc-form-field-text-suffix>*{flex:0 0 auto}:host ::ng-deep .mat-mdc-form-field-infix{width:auto}.s-prefix-slot,.s-suffix-slot{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix-slot:empty,.s-suffix-slot:empty{display:none}.s-prefix,.s-suffix{display:inline-flex;align-items:center;flex-wrap:nowrap;white-space:nowrap}.s-prefix{padding-left:16px}.s-suffix{padding-right:16px}textarea[matInput]{resize:vertical}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], rows: [{ type: i0.Input, args: [{ isSignal: true, alias: "rows", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], prefixSlot: [{ type: i0.ViewChild, args: ['[sPrefix]', { isSignal: true }] }], textareaElement: [{ type: i0.ViewChild, args: ['textareaElement', { isSignal: true }] }] } });

class STreeMenuComponent {
    items = input([], /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    useRouterLink = input(true, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "useRouterLink" }] : /* istanbul ignore next */ []));
    itemClickEvent = output();
    childMenu;
    trackByItem(_index, item) {
        return item.route ?? item.displayName;
    }
    onItemClick(item) {
        this.itemClickEvent.emit(item);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: STreeMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.0", type: STreeMenuComponent, isStandalone: true, selector: "s-tree-menu", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, useRouterLink: { classPropertyName: "useRouterLink", publicName: "useRouterLink", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { itemClickEvent: "itemClickEvent" }, viewQueries: [{ propertyName: "childMenu", first: true, predicate: ["childMenu"], descendants: true, static: true }], ngImport: i0, template: "<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\">\n  @for (child of items(); track trackByItem($index, child)) {\n    @if (child.children && child.children.length > 0) {\n      <button mat-menu-item color=\"primary\" [matMenuTriggerFor]=\"menu.childMenu\">\n        {{ child.displayName }}\n      </button>\n      <s-tree-menu\n        #menu\n        [useRouterLink]=\"useRouterLink()\"\n        [items]=\"child.children\"\n        (itemClickEvent)=\"onItemClick($event)\"\n      ></s-tree-menu>\n    } @else {\n      @if (useRouterLink()) {\n        <a mat-menu-item [routerLink]=\"child.route\" [queryParams]=\"child.queryParams\">\n          <span\n            matBadgeOverlap=\"false\"\n            matBadgeSize=\"small\"\n            matBadgePosition=\"before\"\n            [class.menu-tree-badge]=\"child.badgeValue\"\n            [attr.style]=\"child.attrStyle\"\n            [matBadge]=\"child.badgeValue\"\n            [matBadgeColor]=\"child.badgeColor\"\n          >\n            {{ child.displayName }}\n          </span>\n        </a>\n      } @else {\n        <button mat-menu-item (click)=\"onItemClick(child)\">\n          <span\n            matBadgeOverlap=\"false\"\n            matBadgeSize=\"small\"\n            matBadgePosition=\"before\"\n            [class.menu-tree-badge]=\"child.badgeValue\"\n            [attr.style]=\"child.attrStyle\"\n            [matBadge]=\"child.badgeValue\"\n            [matBadgeColor]=\"child.badgeColor\"\n          >\n            {{ child.displayName }}\n          </span>\n        </button>\n      }\n    }\n  }\n</mat-menu>\n", styles: [".menu-tree-badge{margin-left:10px;padding-left:3px}\n"], dependencies: [{ kind: "component", type: STreeMenuComponent, selector: "s-tree-menu", inputs: ["items", "useRouterLink"], outputs: ["itemClickEvent"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$2.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i1$2.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i1$2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatBadgeModule }, { kind: "directive", type: i2$2.MatBadge, selector: "[matBadge]", inputs: ["matBadgeColor", "matBadgeOverlap", "matBadgeDisabled", "matBadgePosition", "matBadge", "matBadgeDescription", "matBadgeSize", "matBadgeHidden"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i3$2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "browserUrl", "routerLink"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.0", ngImport: i0, type: STreeMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 's-tree-menu', imports: [MatMenuModule, MatButtonModule, MatBadgeModule, RouterModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\">\n  @for (child of items(); track trackByItem($index, child)) {\n    @if (child.children && child.children.length > 0) {\n      <button mat-menu-item color=\"primary\" [matMenuTriggerFor]=\"menu.childMenu\">\n        {{ child.displayName }}\n      </button>\n      <s-tree-menu\n        #menu\n        [useRouterLink]=\"useRouterLink()\"\n        [items]=\"child.children\"\n        (itemClickEvent)=\"onItemClick($event)\"\n      ></s-tree-menu>\n    } @else {\n      @if (useRouterLink()) {\n        <a mat-menu-item [routerLink]=\"child.route\" [queryParams]=\"child.queryParams\">\n          <span\n            matBadgeOverlap=\"false\"\n            matBadgeSize=\"small\"\n            matBadgePosition=\"before\"\n            [class.menu-tree-badge]=\"child.badgeValue\"\n            [attr.style]=\"child.attrStyle\"\n            [matBadge]=\"child.badgeValue\"\n            [matBadgeColor]=\"child.badgeColor\"\n          >\n            {{ child.displayName }}\n          </span>\n        </a>\n      } @else {\n        <button mat-menu-item (click)=\"onItemClick(child)\">\n          <span\n            matBadgeOverlap=\"false\"\n            matBadgeSize=\"small\"\n            matBadgePosition=\"before\"\n            [class.menu-tree-badge]=\"child.badgeValue\"\n            [attr.style]=\"child.attrStyle\"\n            [matBadge]=\"child.badgeValue\"\n            [matBadgeColor]=\"child.badgeColor\"\n          >\n            {{ child.displayName }}\n          </span>\n        </button>\n      }\n    }\n  }\n</mat-menu>\n", styles: [".menu-tree-badge{margin-left:10px;padding-left:3px}\n"] }]
        }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], useRouterLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "useRouterLink", required: false }] }], itemClickEvent: [{ type: i0.Output, args: ["itemClickEvent"] }], childMenu: [{
                type: ViewChild,
                args: ['childMenu', { static: true }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ConfirmDialogComponent, DEF_SLIDE_PANEL_PARAMS, ModalDialogComponent, SCheckboxComponent, SColorPickerComponent, SConfirmAlignButtonsEnum, SDatepickerComponent, SDialogService, SInputComponent, SInputNumberComponent, SInputPasswordComponent, SNumericDirective, SSelectComponent, SSlidePanelComponent, SSlidePanelContainerComponent, SSlidePanelExtendClass, SSlidePanelService, STextareaComponent, SToastListComponent, SToastService, SToastTypeEnum, STreeMenuComponent, WaitDialogComponent };
//# sourceMappingURL=selax-ui.mjs.map
