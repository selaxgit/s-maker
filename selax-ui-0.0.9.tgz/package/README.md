# @selax/ui

Angular Material-based form field wrapper components with Reactive Forms support,
icon slots, typed validator-driven error messages, and an interactive showcase.

---

## Requirements

| Dependency            | Version   |
| --------------------- | --------- |
| `@angular/core`       | `^21.0.0` |
| `@angular/forms`      | `^21.0.0` |
| `@angular/material`   | `^21.0.0` |
| `@angular/animations` | `^21.0.0` |

---

## Installation

```bash
npm install @selax/ui
```

Make sure Angular Material is configured in your application:

```bash
ng add @angular/material
```

---

## Components

### `s-input` — `SInputComponent`

A wrapper around `mat-form-field` + `<input matInput>` with full `ControlValueAccessor` support.

#### Inputs

| Input                | Type                       | Default                        | Description                               |
| -------------------- | -------------------------- | ------------------------------ | ----------------------------------------- |
| `label` _(required)_ | `string`                   | —                              | Text for `<mat-label>`                    |
| `appearance`         | `'outline' \| 'fill'`      | `'outline'`                    | `mat-form-field` appearance               |
| `type`               | `string`                   | `'text'`                       | HTML input type                           |
| `placeholder`        | `string`                   | `''`                           | Input placeholder                         |
| `hint`               | `string`                   | `''`                           | Text for `<mat-hint>`                     |
| `prefixIcon`         | `string`                   | `''`                           | Material Icon name for `matPrefix`        |
| `suffixIcon`         | `string`                   | `''`                           | Material Icon name for `matSuffix`        |
| `readonly`           | `boolean`                  | `false`                        | Makes the input read-only                 |
| `value`              | `string \| number \| null` | `''`                           | Value when used **without** Angular Forms |
| `errorText`          | `string`                   | `'Поле заполнено некорректно'` | Fallback error message                    |
| `errorMessages`      | `ValidationMessageMap`     | `{}`                           | Per-validator error overrides             |

---

### `s-textarea` — `STextareaComponent`

Same API as `s-input` plus:

| Input  | Type     | Default | Description                     |
| ------ | -------- | ------- | ------------------------------- |
| `rows` | `number` | `4`     | Number of visible textarea rows |

---

### `ValidationMessageMap`

```ts
type ValidationMessageMap = Partial<
  Record<
    'required' | 'email' | 'minlength' | 'maxlength' | 'min' | 'max' | 'numericMin' | 'numericMax' | 'pattern',
    string
  >
>;
```

---

## Prefix/Suffix slots

In addition to `prefixIcon` / `suffixIcon`, components support content projection with `sPrefix` and `sSuffix`.
You can pass plain text, one button, or multiple buttons/icons.

### Text in suffix

```html
<s-input label="Цена">
  <span sSuffix>₽</span>
</s-input>
```

### One icon button in suffix

```html
<s-input label="Поиск">
  <button sSuffix type="button" mat-icon-button aria-label="Очистить">
    <mat-icon>close</mat-icon>
  </button>
</s-input>
```

### Multiple controls in suffix

```html
<s-input label="Количество">
  <button sSuffix type="button" mat-icon-button aria-label="Уменьшить">
    <mat-icon>remove</mat-icon>
  </button>
  <button sSuffix type="button" mat-icon-button aria-label="Увеличить">
    <mat-icon>add</mat-icon>
  </button>
</s-input>
```

---

## Usage

### With `formControl`

```ts
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { SInputComponent } from '@selax/ui';

@Component({
  imports: [ReactiveFormsModule, SInputComponent],
  template: `
    <s-input label="Email" prefixIcon="mail" [formControl]="emailControl" [errorMessages]="errorMessages" />
  `,
})
export class MyComponent {
  readonly emailControl = new FormControl('', {
    nonNullable: true,
    validators: [Validators.required, Validators.email],
  });

  readonly errorMessages = {
    required: 'Email обязателен',
    email: 'Введите корректный email',
  };
}
```

### With `formControlName`

```ts
import { inject } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { SInputComponent, STextareaComponent } from '@selax/ui';

@Component({
  imports: [ReactiveFormsModule, SInputComponent, STextareaComponent],
  template: `
    <form [formGroup]="form">
      <s-input
        label="Имя"
        formControlName="name"
        prefixIcon="person"
        [errorMessages]="{ required: 'Имя обязательно' }"
      />
      <s-textarea
        label="Комментарий"
        formControlName="comment"
        [rows]="5"
        [errorMessages]="{ required: 'Комментарий обязателен', minlength: 'Слишком коротко' }"
      />
    </form>
  `,
})
export class MyFormComponent {
  private readonly fb = inject(NonNullableFormBuilder);

  readonly form = this.fb.group({
    name: ['', Validators.required],
    comment: ['', [Validators.required, Validators.minLength(20)]],
  });
}
```

### Without forms (`value` binding)

```html
<s-input label="Город" value="Москва" suffixIcon="location_city" hint="Только для отображения" [readonly]="true" />

<s-textarea label="Описание" value="Текст по умолчанию" [rows]="6" />
```

---

## Built-in error messages

When `errorMessages` is not provided, messages are generated automatically:

| Validator   | Generated message                            |
| ----------- | -------------------------------------------- |
| `required`  | Поле обязательно для заполнения              |
| `email`     | Введите корректный email                     |
| `minlength` | Минимальная длина: _N_                       |
| `maxlength` | Максимальная длина: _N_                      |
| `min`       | Минимальное значение: _N_                    |
| `max`       | Максимальное значение: _N_                   |
| `pattern`   | Значение не соответствует требуемому формату |

---

## Demo app

Use `demo-app` for interactive examples of all library components. Each component has a dedicated route with:

- **Playground** — live controls for component inputs
- **States** — ready-made scenarios (default, disabled, readonly, invalid, etc.)

Available routes:

- `/input`
- `/input-password`
- `/input-number`
- `/textarea`
- `/datepicker`
- `/select`

---

## Local development

```bash
# Build the library
npm run build -- --project @selax/ui

# Start the interactive demo app (http://localhost:4200)
npm start

# Run library unit tests
npm run test:ui
```

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the library, run:

```bash
ng build ui
```

This command will compile your project, and the build artifacts will be placed in the `dist/` directory.

### Publishing the Library

Once the project is built, you can publish your library by following these steps:

1. Navigate to the `dist` directory:

   ```bash
   cd dist/ui
   ```

2. Run the `npm publish` command to publish your library to the npm registry:
   ```bash
   npm publish
   ```

## Running unit tests

To execute unit tests with the [Karma](https://karma-runner.github.io) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.
