import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable } from '@angular/core';
import { switchMap, of, map, forkJoin, Observable } from 'rxjs';

const SELAX_UTILS_PARAMS = new InjectionToken('SelaxUtilsParams');
const provideSelaxUtilsEmptySettings = () => {
    const config = {
        dbParams: {
            dbVersion: 1,
            dbName: 'selax-utils-db',
            dbTables: [],
        },
    };
    return {
        provide: SELAX_UTILS_PARAMS,
        useValue: config,
    };
};
/**
 * Предоставить конфигурацию для `@selax/utils`
 *
 * @param config - Конфигурация библиотеки
 * @returns Заданная конфигурация для токена `SELAX_UTILS_PARAMS`
 */
const provideSelaxUtilsSettings = (config) => ({
    provide: SELAX_UTILS_PARAMS,
    useValue: config,
});

class SUDBBase {
    dbParams = inject(SELAX_UTILS_PARAMS);
    dbVersion = this.dbParams.dbParams.dbVersion;
    dbName = this.dbParams.dbParams.dbName;
    dbTables = this.dbParams.dbParams.dbTables;
    removeByFilter(filter) {
        return this.getListByFilter(filter).pipe(switchMap((values) => {
            return this.batchRemove(values.map((item) => item.id)).pipe(switchMap(() => of(undefined)));
        }));
    }
    getListByFilter(filter) {
        return this.getList().pipe(map((response) => response.filter((item) => filter(item))));
    }
    getByFilter(filter) {
        return this.getList().pipe(map((response) => response.find((item) => filter(item)) ?? null));
    }
    batchUpdate(ids, data) {
        if (ids.length === 0) {
            return of(undefined);
        }
        const forks = [];
        ids.forEach((id) => {
            forks.push(this.update(id, data));
        });
        if (forks.length === 0) {
            return of(undefined);
        }
        return forkJoin(forks).pipe(switchMap(() => of(undefined)));
    }
    update(id, data) {
        return this.get(id).pipe(switchMap((response) => this.updateData({ ...response, ...data })), switchMap(() => this.get(id)));
    }
    get(id) {
        return new Observable((observer) => {
            this.openDB().subscribe({
                next: (db) => {
                    try {
                        const transaction = db.transaction(this.tableName, 'readwrite');
                        const objectStore = transaction.objectStore(this.tableName);
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        objectStore.get(Number(id)).onsuccess = (e) => {
                            db.close();
                            observer.next(e.target.result ?? null);
                            observer.complete();
                        };
                    }
                    catch (e) {
                        observer.error(e);
                    }
                },
                error: (e) => {
                    observer.error(e);
                },
            });
        });
    }
    batchRemove(ids) {
        if (ids.length === 0) {
            return of(undefined);
        }
        const forks = [];
        ids.forEach((id) => {
            forks.push(this.remove(id));
        });
        if (forks.length === 0) {
            return of(undefined);
        }
        return forkJoin(forks).pipe(switchMap(() => of(undefined)));
    }
    remove(id) {
        return new Observable((observer) => {
            this.openDB().subscribe({
                next: (db) => {
                    const transaction = db.transaction(this.tableName, 'readwrite');
                    const objectStore = transaction.objectStore(this.tableName);
                    transaction.oncomplete = () => {
                        observer.next();
                        observer.complete();
                    };
                    objectStore.delete(id).onsuccess = () => {
                        db.close();
                    };
                },
                error: (e) => {
                    observer.error(e);
                },
            });
        });
    }
    insert(data) {
        return this.openDB().pipe(switchMap((db) => this.insertDB(db, data)), switchMap((id) => this.get(id)));
    }
    getList() {
        return new Observable((observer) => {
            this.openDB().subscribe({
                next: (db) => {
                    const list = [];
                    const transaction = db.transaction(this.tableName);
                    const objectStore = transaction.objectStore(this.tableName);
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    transaction.onerror = (e) => observer.error(e);
                    transaction.oncomplete = () => {
                        observer.next(list);
                        observer.complete();
                    };
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    objectStore.getAll().onsuccess = (e) => {
                        if (e.target.result) {
                            list.push(...e.target.result);
                        }
                        db.close();
                    };
                },
                error: (e) => {
                    observer.error(e);
                },
            });
        });
    }
    openDB() {
        return new Observable((observer) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            request.onerror = (event) => {
                observer.error(event.target.message);
            };
            request.onblocked = () => observer.error('База заблокирована');
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                this.dbTables.forEach((table) => {
                    if (!db.objectStoreNames.contains(table)) {
                        db.createObjectStore(table, {
                            keyPath: 'id',
                            autoIncrement: true,
                        });
                    }
                });
            };
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            request.onsuccess = (event) => {
                const db = event.target.result;
                observer.next(db);
                observer.complete();
            };
        });
    }
    updateData(data) {
        return new Observable((observer) => {
            this.openDB().subscribe({
                next: (db) => {
                    const transaction = db.transaction([this.tableName], 'readwrite');
                    transaction.oncomplete = () => {
                        observer.next();
                        observer.complete();
                    };
                    const objectStore = transaction.objectStore(this.tableName);
                    objectStore.put(data);
                    db.close();
                },
                error: (e) => {
                    observer.error(e);
                },
            });
        });
    }
    insertDB(db, data) {
        return new Observable((observer) => {
            let newId = 0;
            const transaction = db.transaction([this.tableName], 'readwrite');
            transaction.oncomplete = () => {
                observer.next(newId);
                observer.complete();
            };
            const objectStore = transaction.objectStore(this.tableName);
            const objectStoreRequest = objectStore.add(data);
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            objectStoreRequest.onsuccess = (e) => {
                newId = e.target?.result;
            };
            db.close();
        });
    }
}

/* eslint-disable @typescript-eslint/no-magic-numbers */
/* eslint-disable max-len */
/**
 * Благодарность https://github.com/mapbox/pixelmatch
 */
const DEFAULT_OPTIONS = {
    threshold: 0.1, // matching threshold (0 to 1); smaller is more sensitive
    includeAA: false, // whether to skip anti-aliasing detection
    alpha: 0.1, // opacity of original image in diff output
    aaColor: [255, 255, 0], // color of anti-aliased pixels in diff output
    diffColor: [255, 0, 0], // color of different pixels in diff output
    diffColorAlt: null, // whether to detect dark on light differences between img1 and img2 and set an alternative color to differentiate between the two
    diffMask: false, // draw the diff over a transparent background (a mask)
};
class SUPixelmatch {
    data1;
    data2;
    width;
    height;
    constructor(data1, data2, width, height) {
        this.data1 = data1;
        this.data2 = data2;
        this.width = width;
        this.height = height;
    }
    compare() {
        const img1 = this.data1.data;
        const img2 = this.data2.data;
        const options = DEFAULT_OPTIONS;
        const len = this.width * this.height;
        const a32 = new Uint32Array(img1.buffer, img1.byteOffset, len);
        const b32 = new Uint32Array(img2.buffer, img2.byteOffset, len);
        let identical = true;
        for (let i = 0; i < len; i++) {
            if (a32[i] !== b32[i]) {
                identical = false;
                break;
            }
        }
        if (identical) {
            return 0;
        }
        // maximum acceptable square distance between two colors;
        // 35215 is the maximum possible value for the YIQ difference metric
        const maxDelta = 35215 * options.threshold * options.threshold;
        let diff = 0;
        // compare each pixel of one image against the other one
        for (let y = 0; y < this.height; y++) {
            for (let x = 0; x < this.width; x++) {
                const pos = (y * this.width + x) * 4;
                // squared YUV distance between colors at this pixel position, negative if the img2 pixel is darker
                const delta = this.colorDelta(img1, img2, pos, pos, false);
                // the color difference is above the threshold
                if (Math.abs(delta) > maxDelta) {
                    // check it's a real rendering difference or just anti-aliasing
                    if (!options.includeAA &&
                        (this.antialiased(img1, x, y, this.width, this.height, img2) ||
                            this.antialiased(img2, x, y, this.width, this.height, img1))) {
                        // one of the pixels is anti-aliasing; draw as yellow and do not count as difference
                        // note that we do not include such pixels in a mask
                    }
                    else {
                        // found substantial difference not caused by anti-aliasing; draw it as such
                        diff++;
                    }
                }
            }
        }
        // return the number of different pixels
        return diff;
    }
    antialiased(img, x1, y1, width, height, img2) {
        const x0 = Math.max(x1 - 1, 0);
        const y0 = Math.max(y1 - 1, 0);
        const x2 = Math.min(x1 + 1, width - 1);
        const y2 = Math.min(y1 + 1, height - 1);
        const pos = (y1 * width + x1) * 4;
        let zeroes = x1 === x0 || x1 === x2 || y1 === y0 || y1 === y2 ? 1 : 0;
        let min = 0;
        let max = 0;
        let minX = 0;
        let minY = 0;
        let maxX = 0;
        let maxY = 0;
        // go through 8 adjacent pixels
        for (let x = x0; x <= x2; x++) {
            for (let y = y0; y <= y2; y++) {
                if (x === x1 && y === y1)
                    continue;
                // brightness delta between the center pixel and adjacent one
                const delta = this.colorDelta(img, img, pos, (y * width + x) * 4, true);
                // count the number of equal, darker and brighter adjacent pixels
                if (delta === 0) {
                    zeroes++;
                    // if found more than 2 equal siblings, it's definitely not anti-aliasing
                    if (zeroes > 2)
                        return false;
                    // remember the darkest pixel
                }
                else if (delta < min) {
                    min = delta;
                    minX = x;
                    minY = y;
                    // remember the brightest pixel
                }
                else if (delta > max) {
                    max = delta;
                    maxX = x;
                    maxY = y;
                }
            }
        }
        // if there are no both darker and brighter pixels among siblings, it's not anti-aliasing
        if (min === 0 || max === 0)
            return false;
        // if either the darkest or the brightest pixel has 3+ equal siblings in both images
        // (definitely not anti-aliased), this pixel is anti-aliased
        return ((this.hasManySiblings(img, minX, minY, width, height) && this.hasManySiblings(img2, minX, minY, width, height)) ||
            (this.hasManySiblings(img, maxX, maxY, width, height) && this.hasManySiblings(img2, maxX, maxY, width, height)));
    }
    hasManySiblings(img, x1, y1, width, height) {
        const x0 = Math.max(x1 - 1, 0);
        const y0 = Math.max(y1 - 1, 0);
        const x2 = Math.min(x1 + 1, width - 1);
        const y2 = Math.min(y1 + 1, height - 1);
        const pos = (y1 * width + x1) * 4;
        let zeroes = x1 === x0 || x1 === x2 || y1 === y0 || y1 === y2 ? 1 : 0;
        // go through 8 adjacent pixels
        for (let x = x0; x <= x2; x++) {
            for (let y = y0; y <= y2; y++) {
                if (x === x1 && y === y1)
                    continue;
                const pos2 = (y * width + x) * 4;
                if (img[pos] === img[pos2] &&
                    img[pos + 1] === img[pos2 + 1] &&
                    img[pos + 2] === img[pos2 + 2] &&
                    img[pos + 3] === img[pos2 + 3])
                    zeroes++;
                if (zeroes > 2)
                    return true;
            }
        }
        return false;
    }
    colorDelta(img1, img2, k, m, yOnly) {
        let r1 = img1[k + 0];
        let g1 = img1[k + 1];
        let b1 = img1[k + 2];
        let a1 = img1[k + 3];
        let r2 = img2[m + 0];
        let g2 = img2[m + 1];
        let b2 = img2[m + 2];
        let a2 = img2[m + 3];
        if (a1 === a2 && r1 === r2 && g1 === g2 && b1 === b2)
            return 0;
        if (a1 < 255) {
            a1 /= 255;
            r1 = this.blend(r1, a1);
            g1 = this.blend(g1, a1);
            b1 = this.blend(b1, a1);
        }
        if (a2 < 255) {
            a2 /= 255;
            r2 = this.blend(r2, a2);
            g2 = this.blend(g2, a2);
            b2 = this.blend(b2, a2);
        }
        const y1 = this.rgb2y(r1, g1, b1);
        const y2 = this.rgb2y(r2, g2, b2);
        const y = y1 - y2;
        if (yOnly)
            return y; // brightness difference only
        const i = this.rgb2i(r1, g1, b1) - this.rgb2i(r2, g2, b2);
        const q = this.rgb2q(r1, g1, b1) - this.rgb2q(r2, g2, b2);
        const delta = 0.5053 * y * y + 0.299 * i * i + 0.1957 * q * q;
        // encode whether the pixel lightens or darkens in the sign
        return y1 > y2 ? -delta : delta;
    }
    rgb2y(r, g, b) {
        return r * 0.29889531 + g * 0.58662247 + b * 0.11448223;
    }
    rgb2i(r, g, b) {
        return r * 0.59597799 - g * 0.2741761 - b * 0.32180189;
    }
    rgb2q(r, g, b) {
        return r * 0.21147017 - g * 0.52261711 + b * 0.31114694;
    }
    // blend semi-transparent color with white
    blend(c, a) {
        return 255 + (c - 255) * a;
    }
}

/**
 * Packing Lightmaps
 * desc https://gamedev.ru/pages/coriolis/articles/Packing_Lightmaps
 * see https://github.com/jakesgordon/bin-packing
 */
const TEXTURE_PACKER_WIDTH = 6000;
const TEXTURE_PACKER_HEIGHT = 6000;
class SUTexturePacker {
    width;
    height;
    root;
    blocks = [];
    constructor(width, height) {
        this.width = width;
        this.height = height;
        this.root = { x: 0, y: 0, w: width, h: height };
    }
    fit(blocks) {
        let node;
        this.blocks = blocks;
        for (const block of blocks) {
            if ((node = this.findNode(this.root, block.w, block.h))) {
                block.fit = this.splitNode(node, block.w, block.h);
            }
        }
    }
    getDimesion() {
        let width = 0;
        let height = 0;
        for (const node of this.blocks) {
            const x = Number(node.fit?.x);
            const y = Number(node.fit?.y);
            const w = node.w;
            const h = node.h;
            width = Math.max(width, x + w);
            height = Math.max(height, y + h);
        }
        return { width, height };
    }
    findNode(root, w, h) {
        if (root.used) {
            if (root.right) {
                const node = this.findNode(root.right, w, h);
                if (node) {
                    return node;
                }
            }
            if (root.down) {
                const node = this.findNode(root.down, w, h);
                if (node) {
                    return node;
                }
            }
            return null;
        }
        if (w <= root.w && h <= root.h) {
            return root;
        }
        return null;
    }
    splitNode(node, w, h) {
        node.used = true;
        node.down = { x: node.x, y: (node.y || 0) + h, w: node.w, h: node.h - h };
        node.right = { x: (node.x || 0) + w, y: node.y, w: node.w - w, h: h };
        return node;
    }
}

class SUCanvasHelper {
    static async cropFileToFile(fileName, file, rect) {
        const canvas = await SUCanvasHelper.fileToCanvas(file);
        return SUCanvasHelper.cropCanvasToFile(fileName, canvas, rect);
    }
    static canvasFlipHorizontal(source) {
        const canvas = document.createElement('canvas');
        canvas.width = source.width;
        canvas.height = source.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
            ctx.save();
            ctx.scale(-1, 1);
            ctx.drawImage(source, -canvas.width, 0);
            ctx.restore();
        }
        return canvas;
    }
    static canvasFlipVertical(source) {
        const canvas = document.createElement('canvas');
        canvas.width = source.width;
        canvas.height = source.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
            ctx.save();
            ctx.scale(1, -1);
            ctx.drawImage(source, 0, -canvas.height);
            ctx.restore();
        }
        return canvas;
    }
    static async cropCanvasToFile(fileName, canvasSource, rect) {
        const canvasDest = document.createElement('canvas');
        canvasDest.width = rect.width;
        canvasDest.height = rect.height;
        const ctxDest = canvasDest.getContext('2d');
        const ctxSource = canvasSource.getContext('2d');
        if (!ctxDest || !ctxSource) {
            return null;
        }
        const imageData = ctxSource.getImageData(rect.x, rect.y, rect.width, rect.height);
        ctxDest.putImageData(imageData, 0, 0);
        const blob = await SUCanvasHelper.canvasToBlob(canvasDest);
        return new File([blob], `${fileName}.png`);
    }
    static async canvasToBlob(canvas) {
        return new Promise((resolve, reject) => {
            canvas.toBlob((blob) => {
                if (blob) {
                    resolve(blob);
                }
                else {
                    reject(new Error('Что-то пошло не так'));
                }
            });
        });
    }
    static objectURLToCanvas(objectURL) {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Что-то пошло не так'));
            }
            else {
                const imgElement = new Image();
                imgElement.src = objectURL;
                imgElement.onload = () => {
                    canvas.width = imgElement.width;
                    canvas.height = imgElement.height;
                    ctx.drawImage(imgElement, 0, 0);
                    resolve(canvas);
                };
            }
        });
    }
    static async fileToCanvas(file, width, height) {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Что-то пошло не так'));
            }
            else {
                const imgElement = new Image();
                imgElement.src = URL.createObjectURL(file);
                imgElement.onerror = () => {
                    reject(new Error('Что-то пошло не так'));
                };
                imgElement.onload = () => {
                    canvas.width = imgElement.width;
                    canvas.height = imgElement.height;
                    ctx.drawImage(imgElement, 0, 0);
                    URL.revokeObjectURL(imgElement.src);
                    if (width === undefined && height === undefined) {
                        resolve(canvas);
                    }
                    else {
                        const targetCanvas = document.createElement('canvas');
                        const targetCtx = targetCanvas.getContext('2d');
                        if (!targetCtx) {
                            reject(new Error('Что-то пошло не так'));
                        }
                        else {
                            const targetWidth = width ?? canvas.width;
                            const targetHeight = height ?? canvas.height;
                            targetCanvas.width = targetWidth;
                            targetCanvas.height = targetHeight;
                            const scaleImage = SUCanvasHelper.calcScaleImage(canvas.width, canvas.height, targetWidth, targetHeight);
                            targetCtx.drawImage(canvas, scaleImage.left, scaleImage.top, scaleImage.width, scaleImage.height);
                            resolve(targetCanvas);
                        }
                    }
                };
            }
        });
    }
    static async strechCanvas(sourceCanvas, width, height) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            throw new Error('SUCanvasHelper.strechCanvas - canvas has not ctx');
        }
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(sourceCanvas, 0, 0, width, height);
        return canvas;
    }
    static async scaleCanvas(sourceCanvas, width, height) {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            throw new Error('SUCanvasHelper.scaleCanvas - canvas has not ctx');
        }
        canvas.width = width || sourceCanvas.width;
        canvas.height = height || sourceCanvas.height;
        const scaleImage = SUCanvasHelper.calcScaleImage(sourceCanvas.width, sourceCanvas.height, canvas.width, canvas.height);
        ctx.drawImage(sourceCanvas, scaleImage.left, scaleImage.top, scaleImage.width, scaleImage.height);
        return canvas;
    }
    static calcScaleImage(srcWidth, srcHeight, targetWidth, targetHeight, mode = 'fitted') {
        const ret = {
            width: 0,
            height: 0,
            left: 0,
            top: 0,
            scaleTotargetWidth: true,
        };
        if (srcWidth <= 0 || srcHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) {
            return ret;
        }
        const scaleX1 = targetWidth;
        const scaleY1 = (srcHeight * targetWidth) / srcWidth;
        const scaleX2 = (srcWidth * targetHeight) / srcHeight;
        const scaleY2 = targetHeight;
        let fScaleOnWidth = scaleX2 > targetWidth;
        if (fScaleOnWidth) {
            fScaleOnWidth = mode === 'fitted';
        }
        else {
            fScaleOnWidth = mode === 'zoom';
        }
        if (fScaleOnWidth) {
            ret.width = Math.floor(scaleX1);
            ret.height = Math.floor(scaleY1);
            ret.scaleTotargetWidth = true;
        }
        else {
            ret.width = Math.floor(scaleX2);
            ret.height = Math.floor(scaleY2);
            ret.scaleTotargetWidth = false;
        }
        ret.left = Math.floor((targetWidth - ret.width) / 2);
        ret.top = Math.floor((targetHeight - ret.height) / 2);
        return ret;
    }
    static drawFileOnCanvas(canvas, x, y, width, height, file) {
        return new Promise((resolve, reject) => {
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Что-то пошло не так'));
            }
            else {
                const imgElement = new Image();
                imgElement.src = URL.createObjectURL(file);
                imgElement.onload = () => {
                    ctx.drawImage(imgElement, 0, 0, imgElement.width, imgElement.height, x, y, width, height);
                    URL.revokeObjectURL(imgElement.src);
                    resolve();
                };
            }
        });
    }
    static arrayBufferToCanvas(buffer) {
        return new Promise((resolve, reject) => {
            const blob = new Blob([buffer], { type: 'image/png' });
            const imgElement = new Image();
            imgElement.src = URL.createObjectURL(blob);
            imgElement.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    URL.revokeObjectURL(imgElement.src);
                    reject(new Error('Что-то пошло не так'));
                }
                else {
                    canvas.width = imgElement.width;
                    canvas.height = imgElement.height;
                    ctx.drawImage(imgElement, 0, 0);
                    URL.revokeObjectURL(imgElement.src);
                    resolve(canvas);
                }
            };
        });
    }
}

/* eslint-disable @typescript-eslint/no-magic-numbers */
class SUColorHelper {
    static rgb2hex(value) {
        const rgb = value.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
        return rgb && rgb.length === 4
            ? '#' +
                ('0' + parseInt(rgb[1], 10).toString(16)).slice(-2) +
                ('0' + parseInt(rgb[2], 10).toString(16)).slice(-2) +
                ('0' + parseInt(rgb[3], 10).toString(16)).slice(-2)
            : '';
    }
    static hex2hexadecimal(val) {
        try {
            return parseInt(val.split('#')[1], 16);
        }
        catch {
            return 0;
        }
    }
    static hex2rgba(val) {
        const bigint = parseInt(val.split('#')[1], 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        return `rgba(${r},${g},${b},1)`;
    }
}

class SUNumberHelper {
    static strToNumber(value, valueOnError = null) {
        if (value === null) {
            return null;
        }
        const num = Number(value);
        return isNaN(num) ? valueOnError : num;
    }
    static isNumber(n) {
        return !isNaN(parseFloat(String(n)));
    }
    static getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}

const DATE_SEPARATOR = '.';
class SUDateHelper {
    static correctMinMaxDate(date, minDate, maxDate) {
        let changed = false;
        if (minDate) {
            if (minDate.getTime() > date.getTime()) {
                date.setFullYear(minDate.getFullYear());
                date.setMonth(minDate.getMonth());
                date.setDate(minDate.getDate());
                date.setHours(0, 0, 0, 0);
                changed = true;
            }
        }
        if (maxDate) {
            if (maxDate.getTime() < date.getTime()) {
                date.setFullYear(maxDate.getFullYear());
                date.setMonth(maxDate.getMonth());
                date.setDate(maxDate.getDate());
                date.setHours(0, 0, 0, 0);
                changed = true;
            }
        }
        return changed;
    }
    static addDays(days, date = new Date()) {
        const cloneDate = new Date(date.valueOf());
        cloneDate.setDate(cloneDate.getDate() + days);
        return cloneDate;
    }
    static correctDate(value) {
        if (value instanceof Date) {
            return true;
        }
        if (typeof value === 'string') {
            const [d, m, y] = value.split(DATE_SEPARATOR);
            const date = new Date(+y, +m - 1, +d);
            return date instanceof Date && !isNaN(date.getTime());
        }
        return false;
    }
    static valueToDate(value) {
        if (value instanceof Date) {
            return value;
        }
        return SUDateHelper.normalizeStringToDate(value);
    }
    static dateToString(date) {
        const d = date.getDate();
        const m = date.getMonth() + 1;
        const day = d < 10 ? `0${d}` : d;
        const month = m < 10 ? `0${m}` : m;
        return `${day}${DATE_SEPARATOR}${month}${DATE_SEPARATOR}${date.getFullYear()}`;
    }
    static normalizeStringToDate(value) {
        if (!value) {
            return null;
        }
        const date = new Date();
        const [d, m, y] = value.split(DATE_SEPARATOR);
        const day = SUNumberHelper.strToNumber(d);
        const month = SUNumberHelper.strToNumber(m);
        const year = SUNumberHelper.strToNumber(y);
        if (day !== null) {
            date.setDate(day);
        }
        if (month !== null) {
            date.setMonth(month - 1);
        }
        if (year !== null) {
            date.setFullYear(year);
        }
        date.setHours(0, 0, 0, 0);
        return date;
    }
}

class SUFileHelper {
    static downloadJson(json, filename) {
        const link = document.createElement('a');
        link.setAttribute('href', 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(json, null, 2)));
        link.setAttribute('download', filename);
        link.click();
    }
    static downloadFile(filename, base64Bytes) {
        const link = document.createElement('a');
        link.setAttribute('href', 'data:application/octet-stream;base64,' + base64Bytes);
        link.setAttribute('download', filename);
        link.click();
    }
    static downloadBlob(filename, fileBlob) {
        const url = (window.URL || window.webkitURL).createObjectURL(fileBlob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.click();
    }
    static downloadByLink(filename, linkUrl) {
        const link = document.createElement('a');
        link.setAttribute('href', linkUrl);
        link.setAttribute('download', filename);
        link.click();
    }
    static openFile(base64Bytes, mimeType = 'application/pdf') {
        const URL = window.URL || window.webkitURL;
        const byteChars = atob(base64Bytes);
        const bytes = [];
        for (let i = 0; i < byteChars.length; i++) {
            bytes[i] = byteChars.charCodeAt(i);
        }
        const blob = new Blob([new Uint8Array(bytes)], { type: mimeType });
        const downloadUrl = URL.createObjectURL(blob);
        if (window.navigator && 'msSaveOrOpenBlob' in window.navigator) {
            window.navigator.msSaveOrOpenBlob(blob);
        }
        else {
            const newWin = window.open(downloadUrl, '_blank', 'scrollbars=yes,resizable=yes');
            newWin?.focus();
            URL.revokeObjectURL(downloadUrl);
        }
    }
    static uploadFile(accept, multiple) {
        return new Observable((observer) => {
            if (!accept) {
                accept = '*';
            }
            if (multiple === undefined) {
                multiple = false;
            }
            const inputElement = document.createElement('input');
            inputElement.setAttribute('type', 'file');
            inputElement.setAttribute('accept', accept);
            if (multiple) {
                inputElement.setAttribute('multiple', 'multiple');
            }
            inputElement.addEventListener('change', () => {
                if (inputElement && inputElement.files && inputElement.files.length > 0) {
                    if (multiple) {
                        observer.next(inputElement.files);
                        observer.complete();
                    }
                    else {
                        observer.next(inputElement.files[0]);
                        observer.complete();
                    }
                }
                else {
                    observer.error('Нет файлов');
                }
            }, { once: true });
            inputElement.click();
        });
    }
    static uploadJson() {
        return SUFileHelper.uploadJsonWithFilename().pipe(map((info) => info.json));
    }
    static uploadJsonWithFilename() {
        return new Observable((observer) => {
            const inputElement = document.createElement('input');
            inputElement.setAttribute('type', 'file');
            inputElement.setAttribute('accept', '.json');
            inputElement.addEventListener('change', () => {
                if (inputElement.files?.length === 1) {
                    const filename = inputElement.files[0].name;
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        try {
                            const json = JSON.parse(e.target?.result);
                            observer.next({ filename, json });
                        }
                        catch (error) {
                            observer.error(error);
                        }
                        finally {
                            observer.complete();
                        }
                    };
                    reader.readAsText(inputElement.files[0]);
                }
                else {
                    observer.error('Не больше одного файла за раз');
                    observer.complete();
                }
            }, { once: true });
            inputElement.click();
        });
    }
    static getImageFileExtension(file) {
        const mimeToExtension = {
            'image/jpeg': 'jpg',
            'image/png': 'png',
            'image/gif': 'gif',
            'image/bmp': 'bmp',
            'image/webp': 'webp',
            'image/svg+xml': 'svg',
        };
        const mimeType = file.type;
        if (mimeType in mimeToExtension) {
            return mimeToExtension[mimeType];
        }
        const nameParts = file.name.split('.');
        if (nameParts.length > 1) {
            return nameParts.pop()?.toLowerCase() ?? '';
        }
        return '';
    }
    static async scaleFile(file, width, height) {
        const canvas = await SUCanvasHelper.fileToCanvas(file, width, height);
        const blob = await SUCanvasHelper.canvasToBlob(canvas);
        return new File([blob], file.name);
    }
    static async cropFileToFile(fileName, file, rect) {
        const canvas = await SUCanvasHelper.fileToCanvas(file);
        return SUCanvasHelper.cropCanvasToFile(fileName, canvas, rect);
    }
    static fileToImageData(file) {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            if (!ctx) {
                reject(new Error('Что-то пошло не так'));
            }
            else {
                const imgElement = new Image();
                imgElement.src = URL.createObjectURL(file);
                imgElement.onload = () => {
                    canvas.width = imgElement.width;
                    canvas.height = imgElement.height;
                    ctx.drawImage(imgElement, 0, 0);
                    URL.revokeObjectURL(imgElement.src);
                    const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
                    resolve(data);
                };
            }
        });
    }
    static async compareFiles(file1, file2) {
        const data1 = await SUFileHelper.fileToImageData(file1);
        const data2 = await SUFileHelper.fileToImageData(file2);
        const pixelmatch = new SUPixelmatch(data1, data2, data1.width, data1.height);
        const pixels = pixelmatch.compare();
        return pixels < 10;
    }
    static blobToFile(blob, filename) {
        return new File([blob], filename, {
            lastModified: new Date().getTime(),
            type: blob.type,
        });
    }
    static getFileDimensions(file) {
        return new Promise((resolve) => {
            const imgElement = new Image();
            imgElement.src = URL.createObjectURL(file);
            imgElement.onload = () => {
                resolve({
                    width: imgElement.naturalWidth,
                    height: imgElement.naturalHeight,
                });
                URL.revokeObjectURL(imgElement.src);
            };
        });
    }
    static async flipFile(file, flipHorizontal, flipVertical) {
        let canvas = await SUCanvasHelper.fileToCanvas(file);
        if (flipHorizontal) {
            canvas = SUCanvasHelper.canvasFlipHorizontal(canvas);
        }
        if (flipVertical) {
            canvas = SUCanvasHelper.canvasFlipVertical(canvas);
        }
        const blob = await SUCanvasHelper.canvasToBlob(canvas);
        return new File([blob], file.name);
    }
    static async generateFrameFile(file, width, height, frameX, frameY, layerX, layerY, flipHorizontal, flipVertical) {
        let source = await SUCanvasHelper.fileToCanvas(file);
        if (flipHorizontal) {
            source = SUCanvasHelper.canvasFlipHorizontal(source);
            if (!source) {
                return null;
            }
        }
        if (flipVertical) {
            source = SUCanvasHelper.canvasFlipVertical(source);
            if (!source) {
                return null;
            }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            return null;
        }
        ctx.drawImage(source, layerX + frameX, layerY + frameY);
        const blob = await SUCanvasHelper.canvasToBlob(canvas);
        return new File([blob], file.name);
    }
}

class SUJsonHelper {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static clone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    static compareObjects(obj1, obj2) {
        if (obj1 === obj2) {
            return true;
        }
        try {
            return JSON.stringify(obj1) === JSON.stringify(obj2);
        }
        catch {
            return false;
        }
    }
}

class SUStringHelper {
    static uuidv4() {
        const FOUR = 4;
        const FIFTEEN = 15;
        const SIXTEEN = 16;
        return '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, (char) => {
            const charNumber = Number(char);
            return document.defaultView
                ? (charNumber ^
                    (document.defaultView.crypto.getRandomValues(new Uint8Array(1))[0] & (FIFTEEN >> (charNumber / FOUR)))).toString(SIXTEEN)
                : char;
        });
    }
    static string2number(value) {
        let id = null;
        if (value !== null) {
            id = parseInt(value, 10);
            if (isNaN(id)) {
                id = null;
            }
        }
        return id;
    }
    static base64ToUint8(base64str) {
        const binary = atob(base64str.replace(/\s/g, ''));
        const len = binary.length;
        const buffer = new ArrayBuffer(len);
        const view = new Uint8Array(buffer);
        for (let i = 0; i < len; i++) {
            view[i] = binary.charCodeAt(i);
        }
        return view;
    }
    static replaceHyphen(hyphen) {
        return hyphen
            .split('-')
            .map((i) => SUStringHelper.upperCaseFirstLetter(i))
            .join('');
    }
    static lowerCaseFirstLetter(str) {
        return str ? str[0].toLowerCase() + str.substring(1) : str;
    }
    static upperCaseFirstLetter(str) {
        return str ? str[0].toUpperCase() + str.substring(1) : str;
    }
    static calculateCRC(value) {
        let data;
        if (typeof value === 'string') {
            data = value;
        }
        else {
            data = JSON.stringify(value);
        }
        const FFF_NUM = 0xffffffff;
        const polynomial = 0xedb88320;
        let crc = FFF_NUM;
        for (let i = 0; i < data.length; i++) {
            crc ^= data.charCodeAt(i);
            // eslint-disable-next-line @typescript-eslint/no-magic-numbers
            for (let j = 0; j < 8; j++) {
                crc = (crc >>> 1) ^ (crc & 1 ? polynomial : 0);
            }
        }
        return crc ^ FFF_NUM;
    }
    static numberFormat(value, decimals = 0, decPoint = '.', thousandsSep = ' ') {
        let kd = '';
        let minus = '';
        if (value < 0) {
            minus = '-';
            value *= -1;
        }
        if (isNaN((decimals = Math.abs(decimals)))) {
            decimals = 2;
        }
        const d = SUStringHelper.num2string(value);
        const arrSplitted = d.split('.');
        const i = '' + arrSplitted[0];
        const kw = i.split(/(?=(?:\d{3})+$)/).join(thousandsSep);
        if (arrSplitted[1] !== undefined && decimals > 0) {
            kd = decPoint + arrSplitted[1].slice(0, decimals);
        }
        return minus + kw + kd;
    }
    static num2string(num) {
        const data = String(num).split(/[eE]/);
        if (data.length == 1) {
            return String(data[0]);
        }
        let z = '';
        const sign = num < 0 ? '-' : '';
        const str = data[0].replace('.', '');
        let mag = Number(data[1]) + 1;
        if (mag < 0) {
            z = sign + '0.';
            while (mag++) {
                z += '0';
            }
            return z + str.replace(/^-/, '');
        }
        mag -= str.length;
        while (mag--) {
            z += '0';
        }
        return str + z;
    }
    /**
     * Склонение числительных окончаний
     * @param string[] titles Список правильных слов с окончаниями для [1, 2, 5]
     * @param number amount Кол-во
     * Пример, (["Яблоко","Яблока","Яблок"], 0); -> Яблок
     */
    static declinationOfNumerals(titles, amount) {
        const cases = [2, 0, 1, 1, 1, 2];
        amount = Math.abs(amount);
        // eslint-disable-next-line @typescript-eslint/no-magic-numbers
        if (amount % 100 > 4 && amount % 100 < 20) {
            return titles[2];
        }
        else if (amount % 10 < 5) {
            return titles[cases[amount % 10]];
        }
        return titles[2];
    }
}

class SUValidatorsHelper {
    static notEmptyValue(control) {
        const value = control.value;
        if ([undefined, null].includes(value) || String(value).trim() === '') {
            return { emptyValue: true };
        }
        return null;
    }
}

/**
  Класс-хелпер для работы с семантическими версиями (SemVer)
  Поддерживает формат major.minor.patch

  Примеры использования:

  // Основные методы
  console.log(SUVersionHelper.isValid("1.0.0")); // true
  console.log(SUVersionHelper.isValid("invalid")); // false

  const parsed = SUVersionHelper.parse("2.5.1");
  console.log(parsed); // { major: 2, minor: 5, patch: 1, original: "2.5.1" }

  console.log(SUVersionHelper.compare("1.0.0", "2.0.0")); // -1
  console.log(SUVersionHelper.satisfies("1.2.3", "^1.0.0")); // true

  // Утилитарные методы
  console.log(SUVersionHelper.nextPatch("1.2.3")); // "1.2.4"
  console.log(SUVersionHelper.nextMinor("1.2.3")); // "1.3.0"
  console.log(SUVersionHelper.nextMajor("1.2.3")); // "2.0.0"

  console.log(SUVersionHelper.format(1, 2, 3)); // "1.2.3"

  const versions = ["1.0.0", "2.0.0", "1.5.0", "1.0.1"];
  console.log(SUVersionHelper.sort(versions)); // ["1.0.0", "1.0.1", "1.5.0", "2.0.0"]
  console.log(SUVersionHelper.max(versions)); // "2.0.0"
  console.log(SUVersionHelper.min(versions)); // "1.0.0"

  console.log(SUVersionHelper.filterByRange(versions, ">=1.0.1")); // ["1.5.0", "2.0.0", "1.0.1"]

  // Проверки диапазонов
  console.log(SUVersionHelper.isAtLeast("1.2.3", "1.0.0")); // true
  console.log(SUVersionHelper.isAtMost("1.2.3", "2.0.0")); // true
  console.log(SUVersionHelper.isInRange("1.2.3", "1.0.0", "2.0.0")); // true
**/
class SUVersionHelper {
    static VERSION_REGEX = /^(\d+)\.(\d+)\.(\d+)$/;
    static MAX_VERSION_VALUE = 9999;
    static SIMPLE_OPERATOR_REGEX = /^(>=|<=|>|<|=)?\s*(\d+\.\d+\.\d+)$/;
    static RANGE_REGEX = /^(\d+\.\d+\.\d+)\s*-\s*(\d+\.\d+\.\d+)$/;
    /**
     * Проверяет строку версии на соответствие формату major.minor.patch
     * и допустимость значений компонентов
     */
    static isValid(version) {
        // Проверяем базовую структуру строки
        if (typeof version !== 'string' || version.trim() === '') {
            return false;
        }
        const trimmedVersion = version.trim();
        // Проверяем соответствие формату major.minor.patch
        const match = trimmedVersion.match(SUVersionHelper.VERSION_REGEX);
        if (!match) {
            return false;
        }
        // Извлекаем компоненты версии
        const major = parseInt(match[1], 10);
        const minor = parseInt(match[2], 10);
        const patch = parseInt(match[3], 10);
        // Проверяем, что все компоненты являются числами
        if (isNaN(major) || isNaN(minor) || isNaN(patch)) {
            return false;
        }
        // Проверяем допустимость значений
        // Major, minor, patch должны быть неотрицательными целыми числами
        if (major < 0 || minor < 0 || patch < 0) {
            return false;
        }
        // Проверяем, что числа не начинаются с нуля (кроме нуля самого по себе)
        if ((match[1].length > 1 && match[1].startsWith('0')) ||
            (match[2].length > 1 && match[2].startsWith('0')) ||
            (match[3].length > 1 && match[3].startsWith('0'))) {
            return false;
        }
        // Проверяем, что значения не превышают разумные пределы
        if (major > SUVersionHelper.MAX_VERSION_VALUE ||
            minor > SUVersionHelper.MAX_VERSION_VALUE ||
            patch > SUVersionHelper.MAX_VERSION_VALUE) {
            return false;
        }
        return true;
    }
    /**
     * Проверяет строку версии и возвращает разобранные компоненты
     * @throws {VersionError} Если версия невалидна
     */
    static parse(version) {
        if (!SUVersionHelper.isValid(version)) {
            throw new VersionError(`Invalid version format: "${version}". Expected format: major.minor.patch`);
        }
        const trimmedVersion = version.trim();
        const [major, minor, patch] = trimmedVersion.split('.').map(Number);
        return {
            major,
            minor,
            patch,
            original: trimmedVersion,
        };
    }
    /**
     * Сравнивает две версии
     * @returns -1 если version1 < version2, 0 если равны, 1 если version1 > version2
     * @throws {VersionError} Если любая из версий невалидна
     */
    static compare(version1, version2) {
        const v1 = SUVersionHelper.parse(version1);
        const v2 = SUVersionHelper.parse(version2);
        if (v1.major !== v2.major) {
            return v1.major > v2.major ? 1 : -1;
        }
        if (v1.minor !== v2.minor) {
            return v1.minor > v2.minor ? 1 : -1;
        }
        if (v1.patch !== v2.patch) {
            return v1.patch > v2.patch ? 1 : -1;
        }
        return 0;
    }
    /**
     * Проверяет, удовлетворяет ли версия заданному диапазону
     * Поддерживает операторы: >, >=, <, <=, =, ~, ^
     */
    static satisfies(version, range) {
        const parsedVersion = SUVersionHelper.parse(version);
        // Убираем пробелы
        const trimmedRange = range.trim();
        // Простые операторы сравнения
        const simpleMatch = trimmedRange.match(SUVersionHelper.SIMPLE_OPERATOR_REGEX);
        if (simpleMatch) {
            const operator = simpleMatch[1] || '=';
            const rangeVersion = simpleMatch[2];
            const comparison = SUVersionHelper.compare(version, rangeVersion);
            switch (operator) {
                case '>':
                    return comparison > 0;
                case '>=':
                    return comparison >= 0;
                case '<':
                    return comparison < 0;
                case '<=':
                    return comparison <= 0;
                case '=':
                    return comparison === 0;
                default:
                    return false;
            }
        }
        // Тильда-диапазон (~): позволяет изменения patch-версии
        if (trimmedRange.startsWith('~')) {
            const rangeVersion = trimmedRange.substring(1).trim();
            const parsedRangeVersion = SUVersionHelper.parse(rangeVersion);
            return (parsedVersion.major === parsedRangeVersion.major &&
                parsedVersion.minor === parsedRangeVersion.minor &&
                parsedVersion.patch >= parsedRangeVersion.patch);
        }
        // Карет-диапазон (^): позволяет изменения minor и patch версий
        if (trimmedRange.startsWith('^')) {
            const rangeVersion = trimmedRange.substring(1).trim();
            const parsedRangeVersion = SUVersionHelper.parse(rangeVersion);
            return SUVersionHelper.satisfiesCaretRange(parsedVersion, parsedRangeVersion);
        }
        // Диапазон версий (например, "1.0.0 - 2.0.0")
        const rangeMatch = trimmedRange.match(SUVersionHelper.RANGE_REGEX);
        if (rangeMatch) {
            const minVersion = rangeMatch[1];
            const maxVersion = rangeMatch[2];
            return SUVersionHelper.compare(version, minVersion) >= 0 && SUVersionHelper.compare(version, maxVersion) <= 0;
        }
        throw new VersionError(`Unsupported range format: "${range}"`);
    }
    /**
     * Проверяет, является ли версия больше или равна минимальной
     */
    static isAtLeast(version, minVersion) {
        return SUVersionHelper.compare(version, minVersion) >= 0;
    }
    /**
     * Проверяет, является ли версия меньше или равна максимальной
     */
    static isAtMost(version, maxVersion) {
        return SUVersionHelper.compare(version, maxVersion) <= 0;
    }
    /**
     * Проверяет, находится ли версия в диапазоне (включительно)
     */
    static isInRange(version, minVersion, maxVersion) {
        return SUVersionHelper.isAtLeast(version, minVersion) && SUVersionHelper.isAtMost(version, maxVersion);
    }
    /**
     * Возвращает следующую major версию
     */
    static nextMajor(version) {
        const parsed = SUVersionHelper.parse(version);
        return `${parsed.major + 1}.0.0`;
    }
    /**
     * Возвращает следующую minor версию
     */
    static nextMinor(version) {
        const parsed = SUVersionHelper.parse(version);
        return `${parsed.major}.${parsed.minor + 1}.0`;
    }
    /**
     * Возвращает следующую patch версию
     */
    static nextPatch(version) {
        const parsed = SUVersionHelper.parse(version);
        return `${parsed.major}.${parsed.minor}.${parsed.patch + 1}`;
    }
    /**
     * Форматирует компоненты версии в строку
     */
    static format(major, minor, patch) {
        if (major < 0 ||
            minor < 0 ||
            patch < 0 ||
            !Number.isInteger(major) ||
            !Number.isInteger(minor) ||
            !Number.isInteger(patch)) {
            throw new VersionError(`Invalid version components: major=${major}, minor=${minor}, patch=${patch}. ` +
                `All components must be non-negative integers.`);
        }
        return `${major}.${minor}.${patch}`;
    }
    /**
     * Сортирует массив версий по возрастанию
     */
    static sort(versions) {
        return [...versions].sort((a, b) => SUVersionHelper.compare(a, b));
    }
    /**
     * Сортирует массив версий по убыванию
     */
    static sortDesc(versions) {
        return [...versions].sort((a, b) => SUVersionHelper.compare(b, a));
    }
    /**
     * Возвращает максимальную версию из массива
     */
    static max(versions) {
        if (versions.length === 0)
            return null;
        return versions.reduce((maxVersion, currentVersion) => {
            return SUVersionHelper.compare(currentVersion, maxVersion) > 0 ? currentVersion : maxVersion;
        }, versions[0]);
    }
    /**
     * Возвращает минимальную версию из массива
     */
    static min(versions) {
        if (versions.length === 0)
            return null;
        return versions.reduce((minVersion, currentVersion) => {
            return SUVersionHelper.compare(currentVersion, minVersion) < 0 ? currentVersion : minVersion;
        }, versions[0]);
    }
    /**
     * Фильтрует версии, удовлетворяющие заданному диапазону
     */
    static filterByRange(versions, range) {
        return versions.filter((version) => SUVersionHelper.satisfies(version, range));
    }
    /**
     * Проверяет карет-диапазон (^)
     * @private
     */
    static satisfiesCaretRange(version, range) {
        if (range.major > 0) {
            return version.major === range.major && version.minor >= range.minor;
        }
        else if (range.minor > 0) {
            return version.major === 0 && version.minor === range.minor && version.patch >= range.patch;
        }
        else {
            return version.major === 0 && version.minor === 0 && version.patch >= range.patch;
        }
    }
    /**
     * Валидирует и нормализует версию (убирает пробелы)
     */
    static normalize(version) {
        if (!SUVersionHelper.isValid(version)) {
            throw new VersionError(`Cannot normalize invalid version: "${version}"`);
        }
        return version.trim();
    }
    /**
     * Проверяет, является ли версия релизной (не pre-release)
     * В текущей реализации все версии считаются релизными
     * Можно расширить для поддержки pre-release версий
     */
    static isRelease(version) {
        return SUVersionHelper.isValid(version);
    }
}
/**
 * Кастомная ошибка для работы с версиями
 */
class VersionError extends Error {
    constructor(message) {
        super(message);
        this.name = 'VersionError';
    }
}

class SUStorageService {
    storage;
    constructor(storage) {
        this.storage = storage;
    }
    get(key) {
        const value = this.storage.getItem(key);
        return value ? this.getValue(value) : null;
    }
    set(key, value) {
        this.storage.setItem(key, this.normalizeValue(value));
    }
    remove(key) {
        this.storage.removeItem(key);
    }
    clear() {
        this.storage.clear();
    }
    getValue(value) {
        try {
            return JSON.parse(value);
        }
        catch {
            return value;
        }
    }
    normalizeValue(value) {
        return typeof value === 'string' ? value : JSON.stringify(value);
    }
}
class SULocalStorageService extends SUStorageService {
    constructor() {
        super(localStorage);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SULocalStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SULocalStorageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SULocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
class SUSessionStorageService extends SUStorageService {
    constructor() {
        super(sessionStorage);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SUSessionStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SUSessionStorageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.5", ngImport: i0, type: SUSessionStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { DATE_SEPARATOR, SELAX_UTILS_PARAMS, SUCanvasHelper, SUColorHelper, SUDBBase, SUDateHelper, SUFileHelper, SUJsonHelper, SULocalStorageService, SUNumberHelper, SUPixelmatch, SUSessionStorageService, SUStorageService, SUStringHelper, SUTexturePacker, SUValidatorsHelper, SUVersionHelper, TEXTURE_PACKER_HEIGHT, TEXTURE_PACKER_WIDTH, VersionError, provideSelaxUtilsEmptySettings, provideSelaxUtilsSettings };
//# sourceMappingURL=selax-utils.mjs.map
